# Karhl Aircon & Refrigeration Services

Desktop business-management system for Karhl Aircon & Refrigeration Services.

This repository contains:

- Editable Java Swing source code (`src/`)
- The current business database (`data/karhl_aircon_refrigeration.db`)
- A ready-to-run desktop application JAR (`target/hvac-business-manager.jar`)
- Maven configuration (`pom.xml`)

## Open the app immediately

1. Clone the repository or download it as ZIP.
2. Keep the folder structure unchanged.
3. Double-click **Run Karhl Aircon Services.cmd**.

Java 17 or newer must be installed. Antigravity does **not** need to be open to use the app.

## Develop in Antigravity or VS Code

1. Open the cloned folder in Antigravity or VS Code.
2. Trust the folder if prompted.
3. Import/open the Maven project from `pom.xml`.
4. Open `src/main/java/com/familyhvac/Main.java`.
5. Run the `main` method.

For a fresh JAR after changing code, run:

```text
mvn clean package
```

The new application file will be in `target/hvac-business-manager.jar`.

## Shared database rules

- `data/karhl_aircon_refrigeration.db` is the current working database included with this release.
- The app stores new changes in this same file when it is launched from this project folder.
- Before anyone makes risky database changes, make a backup from the app’s Settings screen or copy the `.db` file.
- Do not commit `data/*.db-wal` or `data/*.db-shm`; they are temporary SQLite files and are already ignored.

## Current data verified

This bundle uses the updated database with:

- 7 clients
- 15 jobs
- 9 payment records
- 35 expense records
- 4 technicians
- 36 technician payout records

## Team workflow

Use GitHub branches and pull requests for code changes. Coordinate before editing the shared database: Git cannot safely merge two different SQLite database files. For data testing, make a personal copy of the database first.
