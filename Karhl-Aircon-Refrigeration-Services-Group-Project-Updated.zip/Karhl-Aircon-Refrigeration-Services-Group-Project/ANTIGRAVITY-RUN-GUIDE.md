# Run in Antigravity

This folder is the editable source project for **Karhl Aircon & Refrigeration Services**. It already includes the current database in `data/`.

1. Extract the ZIP file.
2. In Antigravity, choose **Open Folder** and select the extracted `Karhl-Aircon-Refrigeration-Services-Source-Code` folder.
3. When asked, allow Antigravity to trust the folder and import the Maven project from `pom.xml`.
4. Open `src/main/java/com/familyhvac/Main.java`.
5. Run the `main` method (use the Run button beside it, or choose Run).

Antigravity will use the Java Development Kit you installed and download the project libraries through Maven on its first build. Keep the `data` folder beside `pom.xml`; it contains your business records.

To build a new app file later, use Antigravity's terminal in this folder and run:

```text
mvn clean package
```

The new app file will be created at:

```text
target/hvac-business-manager.jar
```
