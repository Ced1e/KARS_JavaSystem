@echo off
setlocal
cd /d "%~dp0"

where javaw >nul 2>nul
if %errorlevel%==0 (
  start "Karhl Aircon & Refrigeration Services" /D "%~dp0" javaw -jar "%~dp0target\hvac-business-manager.jar"
  exit /b 0
)

where java >nul 2>nul
if %errorlevel%==0 (
  start "Karhl Aircon & Refrigeration Services" /D "%~dp0" java -jar "%~dp0target\hvac-business-manager.jar"
  exit /b 0
)

echo Java was not found. Install Java 17 or newer, then run this file again.
pause
