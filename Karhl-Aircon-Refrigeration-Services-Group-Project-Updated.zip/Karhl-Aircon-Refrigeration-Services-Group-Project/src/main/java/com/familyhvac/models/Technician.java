package com.familyhvac.models;

/**
 * Represents a technician who performs jobs. Kept deliberately minimal per
 * the approved design - no fixed salary, no daily wage, no employee ID,
 * no hire date. Technicians are paid per job, negotiated after each job
 * (see technician_payouts, built alongside the future Jobs module).
 */
public class Technician {

    private int id;
    private String name;
    private String phoneNumber;
    private String notes;
    private boolean active;
    private String createdAt;
    private String updatedAt;

    public Technician() {
        this.active = true;
    }

    /**
     * Display-only identifier, e.g. "TCH-00001". Deliberately NOT stored in
     * the database - derived from the primary key purely for display, same
     * pattern as {@link Client#getClientCode()}.
     */
    public String getTechnicianCode() {
        return String.format("TCH-%05d", id);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return name;
    }
}
