package com.familyhvac.models;
/** Editable lookup category for expenses. */
public class ExpenseCategory {private int id;private String name;private boolean active;public int getId(){return id;}public void setId(int v){id=v;}public String getName(){return name;}public void setName(String v){name=v;}public boolean isActive(){return active;}public void setActive(boolean v){active=v;}@Override public String toString(){return name;}}
