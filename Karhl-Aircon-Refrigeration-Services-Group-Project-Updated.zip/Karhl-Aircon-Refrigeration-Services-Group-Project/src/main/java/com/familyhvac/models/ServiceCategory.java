package com.familyhvac.models;

/**
 * A service classification (e.g. "Cleaning", "Installation") used to
 * categorize jobs for reporting/filtering. Deliberately carries no price
 * - service categories are descriptive classifications only, never a
 * pricing rule. Actual prices always come from a job's line items.
 */
public class ServiceCategory {

    private int id;
    private String name;
    private boolean active;

    public ServiceCategory() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return name;
    }
}
