package com.familyhvac.models;

/** One append-only payment made against a technician payout. */
public class TechnicianPayoutDisbursement {
    public enum DisbursementType { ADVANCE("Advance"), SETTLEMENT("Settlement"); private final String label; DisbursementType(String label){this.label=label;} @Override public String toString(){return label;} }
    public enum PaymentMethod { CASH("Cash"), CHECK("Check"), BANK_TRANSFER("Bank Transfer"), GCASH("GCash"), OTHERS("Others"); private final String label; PaymentMethod(String label){this.label=label;} @Override public String toString(){return label;} }
    private int id, technicianPayoutId;
    private double amount;
    private DisbursementType disbursementType;
    private PaymentMethod paymentMethod;
    private String disbursementDate, referenceNumber, remarks, createdAt;
    public int getId(){return id;} public void setId(int v){id=v;} public int getTechnicianPayoutId(){return technicianPayoutId;} public void setTechnicianPayoutId(int v){technicianPayoutId=v;}
    public double getAmount(){return amount;} public void setAmount(double v){amount=v;} public DisbursementType getDisbursementType(){return disbursementType;} public void setDisbursementType(DisbursementType v){disbursementType=v;}
    public PaymentMethod getPaymentMethod(){return paymentMethod;} public void setPaymentMethod(PaymentMethod v){paymentMethod=v;} public String getDisbursementDate(){return disbursementDate;} public void setDisbursementDate(String v){disbursementDate=v;}
    public String getReferenceNumber(){return referenceNumber;} public void setReferenceNumber(String v){referenceNumber=v;} public String getRemarks(){return remarks;} public void setRemarks(String v){remarks=v;} public String getCreatedAt(){return createdAt;} public void setCreatedAt(String v){createdAt=v;}
}
