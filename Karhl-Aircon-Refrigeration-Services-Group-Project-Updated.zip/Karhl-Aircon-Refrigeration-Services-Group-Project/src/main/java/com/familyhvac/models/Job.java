package com.familyhvac.models;

/**
 * Represents a single service job - the central entity the whole
 * application is organized around (Client -> Job -> line items /
 * payments / technician payouts / cash advances / expenses).
 */
public class Job {

    /**
     * Workflow state. Deliberately does NOT include a payment-related
     * value (e.g. "PAID") - payment status is a separate, fully derived
     * concept (see the design notes in schema.sql) and must never be
     * conflated with where the job itself stands operationally.
     */
    public enum JobStatus {
        SCHEDULED,
        IN_PROGRESS,
        COMPLETED,
        CANCELLED
    }

    private int id;
    private int clientId;
    private Integer serviceCategoryId;
    private String jobDate;
    private String location;
    private String description;
    private String poNumber;
    private JobStatus jobStatus;
    private String completedAt;
    private String billedAt;
    private String paymentDueDate;
    private double taxReductionPercent;
    private String notes;
    private String createdAt;
    private String updatedAt;

    public Job() {
        this.jobStatus = JobStatus.SCHEDULED;
    }

    /**
     * Display-only identifier, e.g. "JOB-00001". Deliberately NOT stored in
     * the database - derived from the primary key purely for display, same
     * pattern as {@link Client#getClientCode()} and
     * {@link Technician#getTechnicianCode()}.
     */
    public String getJobCode() {
        return String.format("JOB-%05d", id);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public Integer getServiceCategoryId() {
        return serviceCategoryId;
    }

    public void setServiceCategoryId(Integer serviceCategoryId) {
        this.serviceCategoryId = serviceCategoryId;
    }

    public String getJobDate() {
        return jobDate;
    }

    public void setJobDate(String jobDate) {
        this.jobDate = jobDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    /** Optional client purchase-order reference for this job. */
    public String getPoNumber() { return poNumber; }

    public void setPoNumber(String poNumber) { this.poNumber = poNumber; }

    public JobStatus getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(JobStatus jobStatus) {
        this.jobStatus = jobStatus;
    }

    /**
     * When the job was actually completed. Managed automatically by
     * {@code JobService.updateJobStatus} - never set directly from a form.
     */
    public String getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(String completedAt) {
        this.completedAt = completedAt;
    }

    public String getBilledAt() {
        return billedAt;
    }

    public void setBilledAt(String billedAt) {
        this.billedAt = billedAt;
    }

    public String getPaymentDueDate() {
        return paymentDueDate;
    }

    public void setPaymentDueDate(String paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    public double getTaxReductionPercent() { return taxReductionPercent; }

    public void setTaxReductionPercent(double taxReductionPercent) { this.taxReductionPercent = taxReductionPercent; }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return getJobCode();
    }
}
