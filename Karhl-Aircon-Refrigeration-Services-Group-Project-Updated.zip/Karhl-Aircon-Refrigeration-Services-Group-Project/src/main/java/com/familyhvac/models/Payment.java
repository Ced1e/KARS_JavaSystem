package com.familyhvac.models;

/**
 * A single payment received from a client against a job. A job may have
 * many payments (partial or full, across any number of dates) - the
 * amount owed and remaining balance are never stored anywhere; they are
 * always computed from the job's line items and this table.
 */
public class Payment {

    /** Matches the existing payments.payment_type text values exactly. */
    public enum PaymentType {
        CASH("Cash"),
        DOWN_PAYMENT("Down Payment"),
        PARTIAL_PAYMENT("Partial Payment"),
        CHECK("Check"),
        BANK_TRANSFER("Bank Transfer"),
        GCASH("GCash"),
        OTHERS("Others");

        private final String displayLabel;

        PaymentType(String displayLabel) {
            this.displayLabel = displayLabel;
        }

        public String getDisplayLabel() {
            return displayLabel;
        }

        @Override
        public String toString() {
            return displayLabel;
        }
    }

    private int id;
    private int jobId;
    private String paymentDate;
    private double amount;
    private PaymentType paymentType;
    private String referenceNumber;
    private String remarks;
    private String createdAt;

    public Payment() {
        this.paymentType = PaymentType.CASH;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(PaymentType paymentType) {
        this.paymentType = paymentType;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
