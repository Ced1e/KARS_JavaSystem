package com.familyhvac.models;

/**
 * Represents a client (customer) of the business. A client may have many
 * jobs (one-to-many, enforced by jobs.client_id) - the client is the top
 * of the Client -> Job -> (line items / payments / payouts / expenses)
 * hierarchy the whole application is organized around.
 */
public class Client {

    /**
     * How long the client has to pay after billing. A fixed, small set of
     * business rules rather than an open-ended editable list, so it's
     * modeled as an enum rather than a lookup table.
     */
    public enum PaymentTerms {
        COD("COD"),
        NET_15("15 Days"),
        NET_30("30 Days"),
        NET_45("45 Days"),
        NET_60("60 Days");

        private final String displayLabel;

        PaymentTerms(String displayLabel) {
            this.displayLabel = displayLabel;
        }

        public String getDisplayLabel() {
            return displayLabel;
        }

        @Override
        public String toString() {
            return displayLabel;
        }
    }

    /** How the client prefers to pay. Also a fixed set, modeled as an enum. */
    public enum PreferredPaymentMethod {
        CASH("Cash"),
        CHECK("Check"),
        BANK_TRANSFER("Bank Transfer");

        private final String displayLabel;

        PreferredPaymentMethod(String displayLabel) {
            this.displayLabel = displayLabel;
        }

        public String getDisplayLabel() {
            return displayLabel;
        }

        @Override
        public String toString() {
            return displayLabel;
        }
    }

    private int id;
    private String clientName;
    private String contactPerson;
    private String phoneNumber;
    private String email;
    private String tin;
    private String address;
    private PaymentTerms paymentTerms;
    private PreferredPaymentMethod preferredPaymentMethod;
    private String notes;
    private boolean active;
    private String createdAt;
    private String updatedAt;

    public Client() {
        this.paymentTerms = PaymentTerms.COD;
        this.preferredPaymentMethod = PreferredPaymentMethod.CASH;
        this.active = true;
    }

    /**
     * Display-only identifier, e.g. "CLI-00001". Deliberately NOT stored in
     * the database - it's derived from the primary key purely for display,
     * per the field design (see schema.sql comment on the clients table).
     */
    public String getClientCode() {
        return String.format("CLI-%05d", id);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public PaymentTerms getPaymentTerms() {
        return paymentTerms;
    }

    public void setPaymentTerms(PaymentTerms paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    public PreferredPaymentMethod getPreferredPaymentMethod() {
        return preferredPaymentMethod;
    }

    public void setPreferredPaymentMethod(PreferredPaymentMethod preferredPaymentMethod) {
        this.preferredPaymentMethod = preferredPaymentMethod;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return clientName;
    }
}
