package com.familyhvac.models;

/** A technician's assignment and manually agreed labor payout for one job. */
public class TechnicianPayout {
    public enum PayoutMethod { PERCENTAGE("Percentage"), FIXED_AMOUNT("Fixed amount");
        private final String label; PayoutMethod(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }
    private int id, jobId, technicianId;
    private String technicianName, negotiatedAt, remarks, createdAt, updatedAt;
    private boolean lead;
    private PayoutMethod payoutMethod;
    private Double percentageValue, approvedAmount;
    public int getId() { return id; } public void setId(int v) { id=v; }
    public int getJobId() { return jobId; } public void setJobId(int v) { jobId=v; }
    public int getTechnicianId() { return technicianId; } public void setTechnicianId(int v) { technicianId=v; }
    public String getTechnicianName() { return technicianName; } public void setTechnicianName(String v) { technicianName=v; }
    public boolean isLead() { return lead; } public void setLead(boolean v) { lead=v; }
    public PayoutMethod getPayoutMethod() { return payoutMethod; } public void setPayoutMethod(PayoutMethod v) { payoutMethod=v; }
    public Double getPercentageValue() { return percentageValue; } public void setPercentageValue(Double v) { percentageValue=v; }
    public Double getApprovedAmount() { return approvedAmount; } public void setApprovedAmount(Double v) { approvedAmount=v; }
    public String getNegotiatedAt() { return negotiatedAt; } public void setNegotiatedAt(String v) { negotiatedAt=v; }
    public String getRemarks() { return remarks; } public void setRemarks(String v) { remarks=v; }
    public String getCreatedAt() { return createdAt; } public void setCreatedAt(String v) { createdAt=v; }
    public String getUpdatedAt() { return updatedAt; } public void setUpdatedAt(String v) { updatedAt=v; }
}
