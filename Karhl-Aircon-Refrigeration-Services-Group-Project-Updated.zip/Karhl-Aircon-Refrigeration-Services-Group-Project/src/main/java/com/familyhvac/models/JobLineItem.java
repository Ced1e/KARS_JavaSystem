package com.familyhvac.models;

/**
 * A single priced line on a job (e.g. "Wall Mounted Cleaning" x5 @
 * 900.00). A job's total is the sum of its line items' subtotals -
 * there is no other authoritative total anywhere.
 */
public class JobLineItem {

    private int id;
    private int jobId;
    private String description;
    private double quantity;
    private double unitPrice;
    private int sortOrder;
    private String createdAt;
    private String updatedAt;

    public JobLineItem() {
        this.quantity = 1;
        this.unitPrice = 0;
    }

    /**
     * quantity * unitPrice. Deliberately NOT stored in the database - a
     * single-row calculation computed fresh every time, so it can never
     * drift from the quantity/unitPrice that back it.
     */
    public double getSubtotal() {
        return quantity * unitPrice;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getJobId() {
        return jobId;
    }

    public void setJobId(int jobId) {
        this.jobId = jobId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(int sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return description;
    }
}
