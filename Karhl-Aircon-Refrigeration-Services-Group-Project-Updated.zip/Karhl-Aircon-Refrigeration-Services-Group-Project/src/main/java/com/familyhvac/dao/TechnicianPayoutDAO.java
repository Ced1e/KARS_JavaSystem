package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.models.TechnicianPayout;
import java.sql.*;
import java.util.*;

/** SQL access for job technician assignments and their negotiated payouts. */
public class TechnicianPayoutDAO implements GenericDAO<TechnicianPayout, Integer> {
    private final DatabaseManager databaseManager = DatabaseManager.getInstance();
    @Override public TechnicianPayout insert(TechnicianPayout p) {
        String sql="INSERT INTO technician_payouts (job_id,technician_id,is_lead,payout_method,percentage_value,approved_amount,negotiated_at,remarks) VALUES (?,?,?,?,?,?,?,?)";
        try(Connection c=databaseManager.getConnection(); PreparedStatement s=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){ bind(s,p,false); s.executeUpdate(); try(ResultSet k=s.getGeneratedKeys()){if(k.next())p.setId(k.getInt(1));} return p;}catch(SQLException e){throw new RuntimeException("Failed to add technician payout: "+e.getMessage(),e);}
    }
    @Override public boolean update(TechnicianPayout p) {
        String sql="UPDATE technician_payouts SET technician_id=?,is_lead=?,payout_method=?,percentage_value=?,approved_amount=?,negotiated_at=?,remarks=?,updated_at=datetime('now') WHERE id=?";
        try(Connection c=databaseManager.getConnection(); PreparedStatement s=c.prepareStatement(sql)){bind(s,p,true);return s.executeUpdate()>0;}catch(SQLException e){throw new RuntimeException("Failed to update technician payout: "+e.getMessage(),e);}
    }
    @Override public boolean deleteById(Integer id){try(Connection c=databaseManager.getConnection();PreparedStatement s=c.prepareStatement("DELETE FROM technician_payouts WHERE id=?")){s.setInt(1,id);return s.executeUpdate()>0;}catch(SQLException e){throw new RuntimeException("Failed to remove technician payout: "+e.getMessage(),e);}}
    @Override public Optional<TechnicianPayout> findById(Integer id){return queryOne("SELECT tp.*,t.name technician_name FROM technician_payouts tp JOIN technicians t ON t.id=tp.technician_id WHERE tp.id=?",id);}
    @Override public List<TechnicianPayout> findAll(){return queryList("SELECT tp.*,t.name technician_name FROM technician_payouts tp JOIN technicians t ON t.id=tp.technician_id ORDER BY tp.id DESC",null);}
    public List<TechnicianPayout> findByJobId(int jobId){return queryList("SELECT tp.*,t.name technician_name FROM technician_payouts tp JOIN technicians t ON t.id=tp.technician_id WHERE tp.job_id=? ORDER BY tp.is_lead DESC,t.name COLLATE NOCASE",jobId);}
    public double calculateDisbursed(int payoutId){try(Connection c=databaseManager.getConnection();PreparedStatement s=c.prepareStatement("SELECT COALESCE(SUM(amount),0) total FROM technician_payout_disbursements WHERE technician_payout_id=?")){s.setInt(1,payoutId);try(ResultSet r=s.executeQuery()){return r.next()?r.getDouble("total"):0;}}catch(SQLException e){throw new RuntimeException("Failed to calculate technician disbursements: "+e.getMessage(),e);}}
    /** Current approved payout obligations less actual recorded disbursements, grouped by technician. */
    public Map<Integer,Double> calculateOutstandingByTechnician(Collection<Integer> technicianIds){
        Map<Integer,Double> totals=new HashMap<>(); if(technicianIds==null||technicianIds.isEmpty())return totals;
        String placeholders=String.join(",",Collections.nCopies(technicianIds.size(),"?"));
        String sql="SELECT tp.technician_id, COALESCE(SUM(CASE WHEN tp.approved_amount > COALESCE((SELECT SUM(d.amount) FROM technician_payout_disbursements d WHERE d.technician_payout_id=tp.id),0) THEN tp.approved_amount-COALESCE((SELECT SUM(d.amount) FROM technician_payout_disbursements d WHERE d.technician_payout_id=tp.id),0) ELSE 0 END),0) outstanding FROM technician_payouts tp WHERE tp.technician_id IN ("+placeholders+") GROUP BY tp.technician_id";
        try(Connection c=databaseManager.getConnection();PreparedStatement s=c.prepareStatement(sql)){int i=1;for(Integer id:technicianIds)s.setInt(i++,id);try(ResultSet r=s.executeQuery()){while(r.next())totals.put(r.getInt("technician_id"),r.getDouble("outstanding"));}}
        catch(SQLException e){throw new RuntimeException("Failed to calculate outstanding technician payouts: "+e.getMessage(),e);} return totals;
    }
    /** Actual payout disbursements grouped by job; approved but unreleased amounts are excluded. */
    public Map<Integer,Double> releasedPayoutTotalsByJob(Collection<Integer> jobIds){
        Map<Integer,Double> totals=new HashMap<>(); if(jobIds==null||jobIds.isEmpty())return totals;
        String placeholders=String.join(",",Collections.nCopies(jobIds.size(),"?"));
        String sql="SELECT tp.job_id,COALESCE(SUM(d.amount),0) total FROM technician_payouts tp JOIN technician_payout_disbursements d ON d.technician_payout_id=tp.id WHERE tp.job_id IN ("+placeholders+") GROUP BY tp.job_id";
        try(Connection c=databaseManager.getConnection();PreparedStatement s=c.prepareStatement(sql)){int i=1;for(Integer id:jobIds)s.setInt(i++,id);try(ResultSet r=s.executeQuery()){while(r.next())totals.put(r.getInt("job_id"),r.getDouble("total"));}}
        catch(SQLException e){throw new RuntimeException("Failed to calculate released job payouts: "+e.getMessage(),e);} return totals;
    }
    /** Approved technician shares grouped by job, including shares not yet released. */
    public Map<Integer,Double> approvedPayoutTotalsByJob(Collection<Integer> jobIds){
        Map<Integer,Double> totals=new HashMap<>(); if(jobIds==null||jobIds.isEmpty())return totals;
        String placeholders=String.join(",",Collections.nCopies(jobIds.size(),"?"));
        String sql="SELECT job_id,COALESCE(SUM(approved_amount),0) total FROM technician_payouts WHERE job_id IN ("+placeholders+") GROUP BY job_id";
        try(Connection c=databaseManager.getConnection();PreparedStatement s=c.prepareStatement(sql)){int i=1;for(Integer id:jobIds)s.setInt(i++,id);try(ResultSet r=s.executeQuery()){while(r.next())totals.put(r.getInt("job_id"),r.getDouble("total"));}}
        catch(SQLException e){throw new RuntimeException("Failed to calculate approved job payouts: "+e.getMessage(),e);} return totals;
    }
    private void bind(PreparedStatement s,TechnicianPayout p,boolean update)throws SQLException {int i=1;if(!update)s.setInt(i++,p.getJobId());s.setInt(i++,p.getTechnicianId());s.setInt(i++,p.isLead()?1:0);if(p.getPayoutMethod()==null)s.setNull(i++,Types.VARCHAR);else s.setString(i++,p.getPayoutMethod().name());if(p.getPercentageValue()==null)s.setNull(i++,Types.REAL);else s.setDouble(i++,p.getPercentageValue());if(p.getApprovedAmount()==null)s.setNull(i++,Types.REAL);else s.setDouble(i++,p.getApprovedAmount());s.setString(i++,p.getNegotiatedAt());s.setString(i++,p.getRemarks());if(update)s.setInt(i,p.getId());}
    private Optional<TechnicianPayout> queryOne(String sql,int id){try(Connection c=databaseManager.getConnection();PreparedStatement s=c.prepareStatement(sql)){s.setInt(1,id);try(ResultSet r=s.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}}catch(SQLException e){throw new RuntimeException("Failed to find technician payout: "+e.getMessage(),e);}}
    private List<TechnicianPayout> queryList(String sql,Integer id){List<TechnicianPayout> list=new ArrayList<>();try(Connection c=databaseManager.getConnection();PreparedStatement s=c.prepareStatement(sql)){if(id!=null)s.setInt(1,id);try(ResultSet r=s.executeQuery()){while(r.next())list.add(map(r));}}catch(SQLException e){throw new RuntimeException("Failed to list technician payouts: "+e.getMessage(),e);}return list;}
    private TechnicianPayout map(ResultSet r)throws SQLException{TechnicianPayout p=new TechnicianPayout();p.setId(r.getInt("id"));p.setJobId(r.getInt("job_id"));p.setTechnicianId(r.getInt("technician_id"));p.setTechnicianName(r.getString("technician_name"));p.setLead(r.getInt("is_lead")==1);String method=r.getString("payout_method");if(method!=null)p.setPayoutMethod(TechnicianPayout.PayoutMethod.valueOf(method));double percentage=r.getDouble("percentage_value");if(!r.wasNull())p.setPercentageValue(percentage);double amount=r.getDouble("approved_amount");if(!r.wasNull())p.setApprovedAmount(amount);p.setNegotiatedAt(r.getString("negotiated_at"));p.setRemarks(r.getString("remarks"));p.setCreatedAt(r.getString("created_at"));p.setUpdatedAt(r.getString("updated_at"));return p;}
}
