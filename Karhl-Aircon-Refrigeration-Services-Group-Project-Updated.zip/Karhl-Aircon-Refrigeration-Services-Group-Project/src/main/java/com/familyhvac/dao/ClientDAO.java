package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.models.Client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for the {@code clients} table.
 *
 * Delete is a SOFT delete (archive): {@link #deleteById(Integer)} sets
 * is_active = 0 rather than removing the row, since clients are
 * referenced by jobs and historical records must never disappear.
 * {@link #findAll()} therefore only returns active clients by default;
 * use {@link #findAllIncludingInactive()} when archived clients need to
 * be visible too.
 */
public class ClientDAO implements GenericDAO<Client, Integer> {

    private final DatabaseManager databaseManager;

    public ClientDAO() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    @Override
    public Client insert(Client client) {
        String sql = "INSERT INTO clients (client_name, contact_person, phone_number, email, tin, " +
                "address, payment_terms, preferred_payment_method, notes, is_active) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            bindClientFields(statement, client);
            statement.setInt(10, client.isActive() ? 1 : 0);

            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    client.setId(generatedKeys.getInt(1));
                }
            }
            return client;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert client '" + client.getClientName() + "': " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Client client) {
        String sql = "UPDATE clients SET client_name = ?, contact_person = ?, phone_number = ?, email = ?, " +
                "tin = ?, address = ?, payment_terms = ?, preferred_payment_method = ?, notes = ?, " +
                "updated_at = datetime('now') WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            bindClientFields(statement, client);
            statement.setInt(10, client.getId());

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update client id=" + client.getId() + ": " + e.getMessage(), e);
        }
    }

    /**
     * Soft delete (archive): marks the client inactive rather than removing
     * the row, so historical jobs linked to this client never break.
     */
    @Override
    public boolean deleteById(Integer id) {
        String sql = "UPDATE clients SET is_active = 0, updated_at = datetime('now') WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to archive client id=" + id + ": " + e.getMessage(), e);
        }
    }

    /** Reverses an archive, marking the client active again. */
    public boolean restoreById(Integer id) {
        String sql = "UPDATE clients SET is_active = 1, updated_at = datetime('now') WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to restore client id=" + id + ": " + e.getMessage(), e);
        }
    }

    @Override
    public Optional<Client> findById(Integer id) {
        String sql = "SELECT * FROM clients WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(mapRow(resultSet));
                }
            }
            return Optional.empty();

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find client id=" + id + ": " + e.getMessage(), e);
        }
    }

    /** Active clients only, alphabetical by name - the default list everywhere in the app. */
    @Override
    public List<Client> findAll() {
        return queryList("SELECT * FROM clients WHERE is_active = 1 ORDER BY id ASC");
    }

    /** Every client regardless of status, for a "show archived" toggle. */
    public List<Client> findAllIncludingInactive() {
        return queryList("SELECT * FROM clients ORDER BY id ASC");
    }

    /**
     * Searches clients by name, contact person, phone, or address
     * (case-insensitive, partial match), per the required search fields.
     */
    public List<Client> search(String query, boolean includeInactive) {
        String sql = "SELECT * FROM clients WHERE " +
                (includeInactive ? "1 = 1" : "is_active = 1") +
                " AND (client_name LIKE ? COLLATE NOCASE " +
                "OR contact_person LIKE ? COLLATE NOCASE " +
                "OR phone_number LIKE ? " +
                "OR address LIKE ? COLLATE NOCASE) " +
                "ORDER BY id ASC";

        List<Client> clients = new ArrayList<>();
        String likePattern = "%" + query + "%";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, likePattern);
            statement.setString(2, likePattern);
            statement.setString(3, likePattern);
            statement.setString(4, likePattern);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    clients.add(mapRow(resultSet));
                }
            }
            return clients;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to search clients for '" + query + "': " + e.getMessage(), e);
        }
    }

    /**
     * Finds active clients with a name similar to the given name
     * (case-insensitive partial match). This is used purely to power a
     * non-blocking "a similar client may already exist" warning - it never
     * prevents saving. When {@code excludeId} is non-null, that client's
     * own row is excluded (needed when checking an edit to an existing
     * client against everyone else).
     */
    public List<Client> findSimilarByName(String name, Integer excludeId) {
        StringBuilder sql = new StringBuilder(
                "SELECT * FROM clients WHERE is_active = 1 AND client_name LIKE ? COLLATE NOCASE"
        );
        if (excludeId != null) {
            sql.append(" AND id != ?");
        }
        sql.append(" ORDER BY client_name COLLATE NOCASE");

        List<Client> clients = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            statement.setString(1, "%" + name + "%");
            if (excludeId != null) {
                statement.setInt(2, excludeId);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    clients.add(mapRow(resultSet));
                }
            }
            return clients;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to search for similar client names: " + e.getMessage(), e);
        }
    }

    private List<Client> queryList(String sql) {
        List<Client> clients = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                clients.add(mapRow(resultSet));
            }
            return clients;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch clients: " + e.getMessage(), e);
        }
    }

    private void bindClientFields(PreparedStatement statement, Client client) throws SQLException {
        statement.setString(1, client.getClientName());
        statement.setString(2, client.getContactPerson());
        statement.setString(3, client.getPhoneNumber());
        statement.setString(4, client.getEmail());
        statement.setString(5, client.getTin());
        statement.setString(6, client.getAddress());
        statement.setString(7, client.getPaymentTerms().name());
        statement.setString(8, client.getPreferredPaymentMethod().name());
        statement.setString(9, client.getNotes());
    }

    private Client mapRow(ResultSet resultSet) throws SQLException {
        Client client = new Client();
        client.setId(resultSet.getInt("id"));
        client.setClientName(resultSet.getString("client_name"));
        client.setContactPerson(resultSet.getString("contact_person"));
        client.setPhoneNumber(resultSet.getString("phone_number"));
        client.setEmail(resultSet.getString("email"));
        client.setTin(resultSet.getString("tin"));
        client.setAddress(resultSet.getString("address"));
        client.setPaymentTerms(Client.PaymentTerms.valueOf(resultSet.getString("payment_terms")));
        client.setPreferredPaymentMethod(Client.PreferredPaymentMethod.valueOf(resultSet.getString("preferred_payment_method")));
        client.setNotes(resultSet.getString("notes"));
        client.setActive(resultSet.getInt("is_active") == 1);
        client.setCreatedAt(resultSet.getString("created_at"));
        client.setUpdatedAt(resultSet.getString("updated_at"));
        return client;
    }
}
