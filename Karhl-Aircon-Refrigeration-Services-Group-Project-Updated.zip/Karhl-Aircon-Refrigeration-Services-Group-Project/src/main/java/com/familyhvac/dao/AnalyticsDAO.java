package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;
import java.sql.*;
import java.time.LocalDate;
import java.time.DayOfWeek;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

/** Read-only aggregate queries. Every figure is derived directly from transactional rows. */
public class AnalyticsDAO {
    private final DatabaseManager db = DatabaseManager.getInstance();
    public static class DashboardData {
        public double totalBusinessEarnings, totalReceivable, cleanReceivable, pendingPayoutAmount;
        public int unpaidJobs, pendingPayouts, upcomingJobs;
    }
    private static final String ACTIVE_JOB_BALANCES =
            "SELECT j.id, " +
            "COALESCE((SELECT SUM(li.quantity * li.unit_price) FROM job_line_items li WHERE li.job_id = j.id), 0) " +
            "* (1 - COALESCE(j.tax_reduction_percent, 0) / 100.0) AS expected_net, " +
            "COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.job_id = j.id), 0) AS paid " +
            "FROM jobs j WHERE j.job_status != 'CANCELLED'";
    /** Dashboard grouping options for a readable, business-focused activity trend. */
    public enum ActivityRange { MONTHLY, WEEKLY, YEARLY }
    /** One plotted activity period, based on scheduled jobs and their expected net value. */
    public record ActivityPoint(LocalDate periodStart, String label, int scheduledJobs, double expectedEarnings) { }
    /**
     * One job row for Work Reports.  Expense figures are derived from the
     * expense records linked to that job; they are never stored on the job.
     */
    public record JobReportRow(int jobId, String jobCode, String jobDate, String clientName, String category, String status,
                               double grossTotal, double taxPercent, double taxAmount, double netTotal,
                               double expenseTotal, String expenseDetails) { }
    /** A bookkeeper-friendly, item-by-item operating expense row. */
    public record ExpenseReportRow(String expenseDate, String jobCode, String clientName,
                                   String expenseCategory, String description, double amount) { }
    public record ExpenseCategoryTotal(String category, double amount) { }
    public record ReportSummary(int jobCount, double grossRevenue, double operatingExpenses, double technicianPayouts,
                                double totalEwtWithheld, double netEarnings, List<ExpenseCategoryTotal> expenseBreakdown) { }

    /** Detailed job activity for a selected date range, with derived gross/tax/net amounts. */
    public List<JobReportRow> jobLog(LocalDate from, LocalDate to) {
        String sql = "SELECT j.id, j.job_date, c.client_name, COALESCE(sc.name, 'Uncategorized'), j.job_status, " +
                "COALESCE(j.tax_reduction_percent, 0), COALESCE(SUM(li.quantity * li.unit_price), 0), " +
                "COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.related_job_id = j.id), 0), " +
                "COALESCE((SELECT GROUP_CONCAT(COALESCE(ec.name, 'Uncategorized') || " +
                "CASE WHEN TRIM(COALESCE(e.description, '')) <> '' THEN ' - ' || e.description ELSE '' END || " +
                "': PHP ' || printf('%.2f', e.amount), '; ') FROM expenses e " +
                "LEFT JOIN expense_categories ec ON ec.id = e.category_id WHERE e.related_job_id = j.id), '—') " +
                "FROM jobs j JOIN clients c ON c.id = j.client_id LEFT JOIN service_categories sc ON sc.id = j.service_category_id " +
                "LEFT JOIN job_line_items li ON li.job_id = j.id WHERE j.job_date BETWEEN ? AND ? " +
                "GROUP BY j.id, j.job_date, c.client_name, sc.name, j.job_status, j.tax_reduction_percent " +
                "ORDER BY j.job_date DESC, j.id DESC";
        List<JobReportRow> rows = new ArrayList<>();
        try (Connection connection = db.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, from.toString()); statement.setString(2, to.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    double gross = result.getDouble(7), percent = result.getDouble(6), tax = gross * percent / 100.0;
                    rows.add(new JobReportRow(result.getInt(1), String.format("JOB-%05d", result.getInt(1)), result.getString(2),
                            result.getString(3), result.getString(4), result.getString(5), gross, percent, tax, gross - tax,
                            result.getDouble(8), result.getString(9)));
                }
            }
        } catch (SQLException error) { throw new RuntimeException("Failed to load job report: " + error.getMessage(), error); }
        return rows;
    }
    /** Accrual-style reporting summary: gross jobs less operating expenses and released technician payouts. */
    public ReportSummary reportSummary(LocalDate from, LocalDate to) {
        List<JobReportRow> jobs = jobLog(from, to);
        double gross = jobs.stream().mapToDouble(JobReportRow::grossTotal).sum();
        double ewt = jobs.stream().mapToDouble(JobReportRow::taxAmount).sum();
        double expenses = expenseTotal(from, to);
        double payouts = scalar("SELECT COALESCE(SUM(amount),0) FROM technician_payout_disbursements WHERE disbursement_date BETWEEN ? AND ?", from.toString(), to.toString());
        return new ReportSummary(jobs.size(), gross, expenses, payouts, ewt, gross - expenses - payouts, expenseBreakdown(from, to));
    }
    public List<ExpenseCategoryTotal> expenseBreakdown(LocalDate from, LocalDate to) {
        List<ExpenseCategoryTotal> values = new ArrayList<>();
        String sql = "SELECT COALESCE(ec.name,'Uncategorized'), COALESCE(SUM(e.amount),0) FROM expenses e LEFT JOIN expense_categories ec ON ec.id=e.category_id WHERE e.expense_date BETWEEN ? AND ? GROUP BY ec.id,ec.name ORDER BY 2 DESC";
        try (Connection c=db.getConnection(); PreparedStatement s=c.prepareStatement(sql)) { s.setString(1,from.toString()); s.setString(2,to.toString()); try(ResultSet r=s.executeQuery()){while(r.next()) values.add(new ExpenseCategoryTotal(r.getString(1),r.getDouble(2)));} }
        catch(SQLException e){throw new RuntimeException("Failed to load expense breakdown: "+e.getMessage(),e);} return values;
    }

    /**
     * Every operating expense in the selected period, including general
     * expenses not tied to a particular job.  This powers the detailed
     * export schedule used by the bookkeeper.
     */
    public List<ExpenseReportRow> expenseLog(LocalDate from, LocalDate to) {
        List<ExpenseReportRow> values = new ArrayList<>();
        String sql = "SELECT e.expense_date, " +
                "CASE WHEN e.related_job_id IS NULL THEN 'General' ELSE printf('JOB-%05d', e.related_job_id) END, " +
                "COALESCE(c.client_name, 'General business expense'), COALESCE(ec.name, 'Uncategorized'), " +
                "COALESCE(e.description, ''), e.amount " +
                "FROM expenses e LEFT JOIN expense_categories ec ON ec.id = e.category_id " +
                "LEFT JOIN jobs j ON j.id = e.related_job_id LEFT JOIN clients c ON c.id = j.client_id " +
                "WHERE e.expense_date BETWEEN ? AND ? ORDER BY e.expense_date DESC, e.id DESC";
        try (Connection connection = db.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, from.toString()); statement.setString(2, to.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) values.add(new ExpenseReportRow(result.getString(1), result.getString(2),
                        result.getString(3), result.getString(4), result.getString(5), result.getDouble(6)));
            }
        } catch (SQLException error) { throw new RuntimeException("Failed to load expense details: " + error.getMessage(), error); }
        return values;
    }
    public void updateEwt2307Status(int jobId, String status) {
        if (!"RECEIVED".equals(status) && !"NOT_YET".equals(status)) throw new IllegalArgumentException("Invalid 2307 status.");
        try (Connection c=db.getConnection(); PreparedStatement s=c.prepareStatement("UPDATE jobs SET ewt_2307_status=?, updated_at=datetime('now') WHERE id=?")) { s.setString(1,status); s.setInt(2,jobId); s.executeUpdate(); }
        catch(SQLException e){throw new RuntimeException("Failed to update 2307 status: "+e.getMessage(),e);}
    }

    public DashboardData loadDashboard() {
        DashboardData data = new DashboardData();
        data.totalBusinessEarnings = realizedBusinessEarnings();
        data.totalReceivable = scalar("SELECT COALESCE(SUM(MAX(0, expected_net - paid)), 0) FROM (" + ACTIVE_JOB_BALANCES + ")");
        data.cleanReceivable = cleanReceivable();
        data.unpaidJobs = count("SELECT COUNT(*) FROM (" + ACTIVE_JOB_BALANCES + ") WHERE expected_net > paid");
        data.pendingPayouts = count("SELECT COUNT(*) FROM technician_payouts tp WHERE approved_amount IS NOT NULL AND approved_amount > COALESCE((SELECT SUM(amount) FROM technician_payout_disbursements d WHERE d.technician_payout_id=tp.id),0)");
        data.pendingPayoutAmount = scalar("SELECT COALESCE(SUM(tp.approved_amount - COALESCE((SELECT SUM(d.amount) FROM technician_payout_disbursements d WHERE d.technician_payout_id=tp.id),0)),0) FROM technician_payouts tp WHERE tp.approved_amount IS NOT NULL AND tp.approved_amount > COALESCE((SELECT SUM(d.amount) FROM technician_payout_disbursements d WHERE d.technician_payout_id=tp.id),0)");
        data.upcomingJobs = count("SELECT COUNT(*) FROM jobs WHERE job_date > date('now') AND job_status = 'SCHEDULED'");
        return data;
    }

    /**
     * Money still expected from clients, less every recorded job expense and
     * technician share for those same unpaid or partially paid jobs.
     */
    private double cleanReceivable() {
        String sql = "SELECT COALESCE(SUM(MAX(0, b.expected_net - b.paid) " +
                "- COALESCE((SELECT SUM(e.amount) FROM expenses e WHERE e.related_job_id = b.id), 0) " +
                "- COALESCE((SELECT SUM(tp.approved_amount) FROM technician_payouts tp WHERE tp.job_id = b.id), 0)), 0) " +
                "FROM (" + ACTIVE_JOB_BALANCES + ") b WHERE b.expected_net > b.paid";
        return scalar(sql);
    }

    /**
     * Realized business earnings only.  A job contributes after its expected
     * net amount has been fully paid: its actual recorded client payments,
     * less that same job's recorded expenses and agreed technician shares.
     */
    private double realizedBusinessEarnings() {
        String paidJobs = "SELECT id FROM (" + ACTIVE_JOB_BALANCES + ") " +
                "WHERE expected_net > 0 AND paid >= expected_net";
        double received = scalar("SELECT COALESCE(SUM(amount), 0) FROM payments " +
                "WHERE job_id IN (" + paidJobs + ")");
        double expenses = scalar("SELECT COALESCE(SUM(amount), 0) FROM expenses " +
                "WHERE related_job_id IN (" + paidJobs + ")");
        double payouts = scalar("SELECT COALESCE(SUM(approved_amount), 0) FROM technician_payouts " +
                "WHERE approved_amount IS NOT NULL AND job_id IN (" + paidJobs + ")");
        return received - expenses - payouts;
    }

    /**
     * Forward-looking business earnings: every non-cancelled job's expected
     * net amount, less all recorded operating expenses and every approved
     * technician share. A payout is counted once whether already released or
     * still pending, so it can never be subtracted twice.
     */
    public double projectedCleanEarnings() {
        double expectedRevenue = scalar("SELECT COALESCE(SUM(COALESCE((SELECT SUM(quantity*unit_price) FROM job_line_items li WHERE li.job_id=j.id),0) * (1-COALESCE(j.tax_reduction_percent,0)/100.0)),0) FROM jobs j WHERE j.job_status != 'CANCELLED'");
        double expenses = scalar("SELECT COALESCE(SUM(amount),0) FROM expenses");
        double technicianObligations = scalar("SELECT COALESCE(SUM(approved_amount),0) FROM technician_payouts WHERE approved_amount IS NOT NULL");
        return expectedRevenue - expenses - technicianObligations;
    }

    /**
     * Readable workload and revenue series from the first recorded job through
     * today (and any later scheduled work). Empty periods are retained so quiet
     * periods remain visible instead of making the chart disappear.
     */
    public List<ActivityPoint> activityTrend(ActivityRange range) {
        LocalDate first; LocalDate last;
        try (Connection connection = db.getConnection(); Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("SELECT MIN(job_date), MAX(job_date) FROM jobs WHERE job_status != 'CANCELLED'")) {
            if (!result.next() || result.getString(1) == null) return List.of();
            first = LocalDate.parse(result.getString(1));
            last = LocalDate.parse(result.getString(2));
        } catch (SQLException error) { throw new RuntimeException("Failed to find activity dates: " + error.getMessage(), error); }
        LocalDate today = LocalDate.now();
        if (today.isAfter(last)) last = today;
        Map<LocalDate, double[]> values = new LinkedHashMap<>();
        for (LocalDate period = periodStart(first, range), lastPeriod = periodStart(last, range);
             !period.isAfter(lastPeriod); period = nextPeriod(period, range)) {
            values.put(period, new double[2]);
        }
        String sql = "SELECT j.job_date, COALESCE(j.tax_reduction_percent,0), COALESCE(SUM(li.quantity * li.unit_price),0) " +
                "FROM jobs j LEFT JOIN job_line_items li ON li.job_id=j.id WHERE j.job_status != 'CANCELLED' " +
                "AND j.job_date BETWEEN ? AND ? GROUP BY j.id,j.job_date,j.tax_reduction_percent";
        try (Connection connection = db.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, first.toString()); statement.setString(2, last.toString());
            try (ResultSet result = statement.executeQuery()) { while (result.next()) { LocalDate date = LocalDate.parse(result.getString(1)); double[] bucket = values.get(periodStart(date, range)); if (bucket != null) { bucket[0]++; bucket[1] += result.getDouble(3) * (1 - result.getDouble(2) / 100.0); } } }
        } catch (SQLException error) { throw new RuntimeException("Failed to load daily activity: " + error.getMessage(), error); }
        List<ActivityPoint> trend = new ArrayList<>();
        for (Map.Entry<LocalDate, double[]> entry : values.entrySet()) trend.add(new ActivityPoint(entry.getKey(), periodLabel(entry.getKey(), range), (int) entry.getValue()[0], entry.getValue()[1]));
        return trend;
    }

    private LocalDate periodStart(LocalDate date, ActivityRange range) {
        return switch (range) {
            case WEEKLY -> date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
            case MONTHLY -> YearMonth.from(date).atDay(1);
            case YEARLY -> date.withDayOfYear(1);
        };
    }
    private LocalDate nextPeriod(LocalDate period, ActivityRange range) {
        return switch (range) { case WEEKLY -> period.plusWeeks(1); case MONTHLY -> period.plusMonths(1); case YEARLY -> period.plusYears(1); };
    }
    private String periodLabel(LocalDate period, ActivityRange range) {
        return switch (range) {
            case WEEKLY -> period.format(DateTimeFormatter.ofPattern("dd MMM"));
            case MONTHLY -> period.format(DateTimeFormatter.ofPattern("MMM yy"));
            case YEARLY -> String.valueOf(period.getYear());
        };
    }
    /**
     * Cash-based net income: collected client payments less expense entries,
     * released technician payouts. EWT is excluded because payments record net cash actually received. Passing no
     * range returns the all-time figure; all scoped figures use the same logic.
     */
    public double netIncome(LocalDate from, LocalDate to) {
        String paymentRange = from == null ? "" : " WHERE payment_date BETWEEN ? AND ?";
        String expenseRange = from == null ? "" : " WHERE expense_date BETWEEN ? AND ?";
        String payoutRange = from == null ? "" : " WHERE disbursement_date BETWEEN ? AND ?";
        String[] dates = from == null ? new String[0] : new String[]{from.toString(), to.toString()};
        double collected = scalar("SELECT COALESCE(SUM(amount),0) FROM payments" + paymentRange, dates);
        double expenses = scalar("SELECT COALESCE(SUM(amount),0) FROM expenses" + expenseRange, dates);
        double payouts = scalar("SELECT COALESCE(SUM(amount),0) FROM technician_payout_disbursements" + payoutRange, dates);
        return collected - expenses - payouts;
    }
    public double expenseTotal(LocalDate from, LocalDate to) { return scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE expense_date BETWEEN ? AND ?", from.toString(), to.toString()); }
    private double netJobRevenue(String from, String to) { return scalar("SELECT COALESCE(SUM(COALESCE((SELECT SUM(quantity*unit_price) FROM job_line_items li WHERE li.job_id=j.id),0)*(1-COALESCE(j.tax_reduction_percent,0)/100.0)),0) FROM jobs j WHERE j.job_date BETWEEN ? AND ?", from, to); }
    public List<String> revenueByCategory() { return rows("SELECT COALESCE(sc.name,'Uncategorized'), COALESCE(SUM(li.quantity*li.unit_price),0) FROM jobs j LEFT JOIN service_categories sc ON sc.id=j.service_category_id LEFT JOIN job_line_items li ON li.job_id=j.id WHERE j.job_status!='CANCELLED' GROUP BY sc.id,sc.name ORDER BY 2 DESC", "₱"); }
    public List<String> jobsByClient() { return rows("SELECT c.client_name, COUNT(j.id) FROM clients c LEFT JOIN jobs j ON j.client_id=c.id GROUP BY c.id,c.client_name ORDER BY 2 DESC,c.client_name", ""); }
    public List<String> technicianPayouts() { return rows("SELECT t.name, COALESCE(SUM(tp.approved_amount),0) FROM technicians t LEFT JOIN technician_payouts tp ON tp.technician_id=t.id GROUP BY t.id,t.name ORDER BY 2 DESC", "₱"); }
    public List<String> expensesByCategory() { return rows("SELECT ec.name, COALESCE(SUM(e.amount),0) FROM expense_categories ec LEFT JOIN expenses e ON e.category_id=ec.id GROUP BY ec.id,ec.name ORDER BY 2 DESC", "₱"); }
    public List<String> jobProfitability() { String q="SELECT printf('JOB-%05d',j.id), COALESCE((SELECT SUM(quantity*unit_price) FROM job_line_items WHERE job_id=j.id),0), COALESCE((SELECT SUM(approved_amount) FROM technician_payouts WHERE job_id=j.id),0), COALESCE((SELECT SUM(amount) FROM expenses WHERE related_job_id=j.id),0) FROM jobs j WHERE j.job_status!='CANCELLED' ORDER BY j.job_date DESC";List<String> out=new ArrayList<>();try(Connection c=db.getConnection();PreparedStatement s=c.prepareStatement(q);ResultSet r=s.executeQuery()){while(r.next()){double revenue=r.getDouble(2),payout=r.getDouble(3),expense=r.getDouble(4);out.add(r.getString(1)+" — Revenue ₱"+money(revenue)+" | Technician Cost ₱"+money(payout)+" | Expenses ₱"+money(expense)+" | Profit ₱"+money(revenue-payout-expense));}}catch(SQLException e){throw new RuntimeException("Failed to run profitability report: "+e.getMessage(),e);}return out; }
    /** Date-scoped reports. Each report uses the date of its underlying business event. */
    public List<String> report(String name, LocalDate from, LocalDate to) {
        String f=from.toString(), t=to.toString();
        return switch(name) {
            case "Revenue by Category" -> dateRows("SELECT COALESCE(sc.name,'Uncategorized'),COALESCE(SUM(li.quantity*li.unit_price),0) FROM jobs j LEFT JOIN service_categories sc ON sc.id=j.service_category_id LEFT JOIN job_line_items li ON li.job_id=j.id WHERE j.job_status!='CANCELLED' AND j.job_date BETWEEN ? AND ? GROUP BY sc.id,sc.name ORDER BY 2 DESC",f,t,"₱");
            case "Jobs by Client" -> dateRows("SELECT c.client_name,COUNT(j.id) FROM clients c LEFT JOIN jobs j ON j.client_id=c.id AND j.job_date BETWEEN ? AND ? GROUP BY c.id,c.client_name ORDER BY 2 DESC",f,t,"");
            case "Technician Payouts" -> dateRows("SELECT t.name,COALESCE(SUM(tp.approved_amount),0) FROM technicians t LEFT JOIN technician_payouts tp ON tp.technician_id=t.id LEFT JOIN jobs j ON j.id=tp.job_id AND j.job_date BETWEEN ? AND ? GROUP BY t.id,t.name ORDER BY 2 DESC",f,t,"₱");
            case "Expenses by Category" -> dateRows("SELECT ec.name,COALESCE(SUM(e.amount),0) FROM expense_categories ec LEFT JOIN expenses e ON e.category_id=ec.id AND e.expense_date BETWEEN ? AND ? GROUP BY ec.id,ec.name ORDER BY 2 DESC",f,t,"₱");
            default -> jobProfitabilityBetween(f,t);
        };
    }
    private List<String> dateRows(String q,String from,String to,String currency){List<String> out=new ArrayList<>();try(Connection c=db.getConnection();PreparedStatement s=c.prepareStatement(q)){s.setString(1,from);s.setString(2,to);try(ResultSet r=s.executeQuery()){while(r.next())out.add(r.getString(1)+" — "+currency+(currency.isEmpty()?r.getInt(2):money(r.getDouble(2))));}}catch(SQLException e){throw new RuntimeException("Failed to run report: "+e.getMessage(),e);}return out;}
    private List<String> jobProfitabilityBetween(String from,String to){String q="SELECT printf('JOB-%05d',j.id),COALESCE((SELECT SUM(quantity*unit_price) FROM job_line_items WHERE job_id=j.id),0),COALESCE((SELECT SUM(approved_amount) FROM technician_payouts WHERE job_id=j.id),0),COALESCE((SELECT SUM(amount) FROM expenses WHERE related_job_id=j.id),0) FROM jobs j WHERE j.job_status!='CANCELLED' AND j.job_date BETWEEN ? AND ? ORDER BY j.job_date DESC";List<String> out=new ArrayList<>();try(Connection c=db.getConnection();PreparedStatement s=c.prepareStatement(q)){s.setString(1,from);s.setString(2,to);try(ResultSet r=s.executeQuery()){while(r.next()){double a=r.getDouble(2),b=r.getDouble(3),d=r.getDouble(4);out.add(r.getString(1)+" — Revenue ₱"+money(a)+" | Technician Cost ₱"+money(b)+" | Expenses ₱"+money(d)+" | Profit ₱"+money(a-b-d));}}}catch(SQLException e){throw new RuntimeException("Failed to run profitability report: "+e.getMessage(),e);}return out;}
    private double scalar(String sql,String... values){try(Connection c=db.getConnection();PreparedStatement s=c.prepareStatement(sql)){for(int i=0;i<values.length;i++)s.setString(i+1,values[i]);try(ResultSet r=s.executeQuery()){return r.next()?r.getDouble(1):0;}}catch(SQLException e){throw new RuntimeException("Failed to load analytics: "+e.getMessage(),e);}}
    private int count(String sql){try(Connection c=db.getConnection();PreparedStatement s=c.prepareStatement(sql);ResultSet r=s.executeQuery()){return r.next()?r.getInt(1):0;}catch(SQLException e){throw new RuntimeException("Failed to load analytics: "+e.getMessage(),e);}}
    private List<String> rows(String sql,String currency){List<String> out=new ArrayList<>();try(Connection c=db.getConnection();PreparedStatement s=c.prepareStatement(sql);ResultSet r=s.executeQuery()){while(r.next())out.add(r.getString(1)+" — "+currency+(currency.isEmpty()?r.getInt(2):money(r.getDouble(2))));}catch(SQLException e){throw new RuntimeException("Failed to run report: "+e.getMessage(),e);}return out;}
    private String money(double amount){return String.format("%,.2f",amount);}
}
