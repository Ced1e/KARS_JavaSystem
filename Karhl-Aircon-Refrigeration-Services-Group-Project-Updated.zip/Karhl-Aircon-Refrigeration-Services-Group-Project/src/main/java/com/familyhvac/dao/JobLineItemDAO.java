package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.models.JobLineItem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for the {@code job_line_items} table.
 */
public class JobLineItemDAO implements GenericDAO<JobLineItem, Integer> {

    private final DatabaseManager databaseManager;

    public JobLineItemDAO() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    @Override
    public JobLineItem insert(JobLineItem lineItem) {
        String sql = "INSERT INTO job_line_items (job_id, description, quantity, unit_price, sort_order) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            statement.setInt(1, lineItem.getJobId());
            statement.setString(2, lineItem.getDescription());
            statement.setDouble(3, lineItem.getQuantity());
            statement.setDouble(4, lineItem.getUnitPrice());
            statement.setInt(5, lineItem.getSortOrder());

            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    lineItem.setId(generatedKeys.getInt(1));
                }
            }
            return lineItem;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert line item for job_id=" + lineItem.getJobId() + ": " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(JobLineItem lineItem) {
        // job_id is intentionally not updatable here - a line item doesn't move
        // between jobs; correcting that would be a delete + re-add on the correct job.
        String sql = "UPDATE job_line_items SET description = ?, quantity = ?, unit_price = ?, sort_order = ?, " +
                "updated_at = datetime('now') WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, lineItem.getDescription());
            statement.setDouble(2, lineItem.getQuantity());
            statement.setDouble(3, lineItem.getUnitPrice());
            statement.setInt(4, lineItem.getSortOrder());
            statement.setInt(5, lineItem.getId());

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update line item id=" + lineItem.getId() + ": " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deleteById(Integer id) {
        String sql = "DELETE FROM job_line_items WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete line item id=" + id + ": " + e.getMessage(), e);
        }
    }

    @Override
    public Optional<JobLineItem> findById(Integer id) {
        String sql = "SELECT * FROM job_line_items WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(mapRow(resultSet));
                }
            }
            return Optional.empty();

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find line item id=" + id + ": " + e.getMessage(), e);
        }
    }

    /** Every line item across every job. Rarely useful directly - see {@link #findByJobId(int)}. */
    @Override
    public List<JobLineItem> findAll() {
        return queryList("SELECT * FROM job_line_items ORDER BY job_id, sort_order, id");
    }

    /** A job's line items in display order - the list a Job Details screen actually wants. */
    public List<JobLineItem> findByJobId(int jobId) {
        String sql = "SELECT * FROM job_line_items WHERE job_id = ? ORDER BY sort_order, id";
        List<JobLineItem> lineItems = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, jobId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    lineItems.add(mapRow(resultSet));
                }
            }
            return lineItems;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find line items for job_id=" + jobId + ": " + e.getMessage(), e);
        }
    }

    /**
     * The job's total, computed in SQL as SUM(quantity * unit_price) - never
     * stored anywhere, per the project's derived-values principle. Returns
     * 0 for a job with no line items yet.
     */
    public double calculateJobTotal(int jobId) {
        String sql = "SELECT COALESCE(SUM(quantity * unit_price), 0) AS job_total FROM job_line_items WHERE job_id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, jobId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getDouble("job_total") : 0.0;
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to calculate total for job_id=" + jobId + ": " + e.getMessage(), e);
        }
    }

    private List<JobLineItem> queryList(String sql) {
        List<JobLineItem> lineItems = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                lineItems.add(mapRow(resultSet));
            }
            return lineItems;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch line items: " + e.getMessage(), e);
        }
    }

    private JobLineItem mapRow(ResultSet resultSet) throws SQLException {
        JobLineItem lineItem = new JobLineItem();
        lineItem.setId(resultSet.getInt("id"));
        lineItem.setJobId(resultSet.getInt("job_id"));
        lineItem.setDescription(resultSet.getString("description"));
        lineItem.setQuantity(resultSet.getDouble("quantity"));
        lineItem.setUnitPrice(resultSet.getDouble("unit_price"));
        lineItem.setSortOrder(resultSet.getInt("sort_order"));
        lineItem.setCreatedAt(resultSet.getString("created_at"));
        lineItem.setUpdatedAt(resultSet.getString("updated_at"));
        return lineItem;
    }
}
