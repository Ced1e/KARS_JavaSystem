package com.familyhvac.dao;

import java.util.List;
import java.util.Optional;

/**
 * Standard contract for all Data Access Objects in the application.
 * Every future DAO (ClientDAO, JobDAO, PaymentDAO, ExpenseDAO,
 * TechnicianDAO, ...) implements this so controllers/services can rely on
 * a consistent, predictable API regardless of which table they're touching.
 *
 * @param <T>  the model type (e.g. User, Client, Job)
 * @param <ID> the primary key type (Integer for every table in this schema)
 */
public interface GenericDAO<T, ID> {

    T insert(T entity);

    boolean update(T entity);

    boolean deleteById(ID id);

    Optional<T> findById(ID id);

    List<T> findAll();
}
