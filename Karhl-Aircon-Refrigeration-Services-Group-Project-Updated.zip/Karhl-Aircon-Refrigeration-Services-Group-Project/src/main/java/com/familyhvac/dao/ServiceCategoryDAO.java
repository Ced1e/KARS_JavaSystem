package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.models.ServiceCategory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Read-only data access for the {@code service_categories} lookup table.
 * Deliberately does NOT implement {@link GenericDAO} - this phase only
 * needs to read categories (to populate a dropdown and resolve names for
 * display), not create/edit/archive them. Managing the category list
 * itself belongs to a future Settings module.
 */
public class ServiceCategoryDAO {

    private final DatabaseManager databaseManager;

    public ServiceCategoryDAO() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    /** Active categories only, for populating a selection dropdown. */
    public List<ServiceCategory> findAllActive() {
        return queryList("SELECT * FROM service_categories WHERE is_active = 1 ORDER BY name COLLATE NOCASE");
    }

    /**
     * Every category regardless of status, for resolving a job's category
     * name for display even if that category is later deactivated.
     */
    public List<ServiceCategory> findAll() {
        return queryList("SELECT * FROM service_categories ORDER BY name COLLATE NOCASE");
    }

    public Optional<ServiceCategory> findById(int id) {
        String sql = "SELECT * FROM service_categories WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(mapRow(resultSet));
                }
            }
            return Optional.empty();

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find service category id=" + id + ": " + e.getMessage(), e);
        }
    }

    private List<ServiceCategory> queryList(String sql) {
        List<ServiceCategory> categories = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                categories.add(mapRow(resultSet));
            }
            return categories;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch service categories: " + e.getMessage(), e);
        }
    }

    private ServiceCategory mapRow(ResultSet resultSet) throws SQLException {
        ServiceCategory category = new ServiceCategory();
        category.setId(resultSet.getInt("id"));
        category.setName(resultSet.getString("name"));
        category.setActive(resultSet.getInt("is_active") == 1);
        return category;
    }
}
