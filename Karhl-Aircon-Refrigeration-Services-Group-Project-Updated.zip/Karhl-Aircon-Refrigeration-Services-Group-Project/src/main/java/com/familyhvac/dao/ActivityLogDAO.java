package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * Write-side DAO for the {@code activity_logs} audit trail. Every future
 * module (Clients, Jobs, Payments, Expenses, ...) calls
 * {@link #log(Integer, String, String, Integer, String)} whenever it
 * creates/updates/deletes a record, so the business always has a history
 * of who did what.
 */
public class ActivityLogDAO {

    private final DatabaseManager databaseManager;

    public ActivityLogDAO() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    /**
     * Records one audit trail entry.
     *
     * @param userId     id of the user who performed the action, or null if unknown/system
     * @param action     short verb describing what happened, e.g. "LOGIN", "CREATE_JOB"
     * @param entityType the type of record affected, e.g. "JOB", "CLIENT" (nullable)
     * @param entityId   the id of the affected record (nullable)
     * @param details    free-text detail, e.g. "Logged in successfully" (nullable)
     */
    public void log(Integer userId, String action, String entityType, Integer entityId, String details) {
        String sql = "INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            if (userId != null) {
                statement.setInt(1, userId);
            } else {
                statement.setNull(1, java.sql.Types.INTEGER);
            }
            statement.setString(2, action);
            statement.setString(3, entityType);
            if (entityId != null) {
                statement.setInt(4, entityId);
            } else {
                statement.setNull(4, java.sql.Types.INTEGER);
            }
            statement.setString(5, details);

            statement.executeUpdate();

        } catch (SQLException e) {
            // Activity logging must never crash the application - log to stderr and continue.
            System.err.println("Failed to write activity log: " + e.getMessage());
        }
    }

    /** Read-only audit trail for a single entity, newest first. */
    public List<String> findEntries(String entityType, int entityId) {
        List<String> entries = new ArrayList<>();
        String sql = "SELECT created_at, action, details FROM activity_logs WHERE entity_type = ? AND entity_id = ? ORDER BY id DESC";
        try (Connection connection = databaseManager.getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, entityType); statement.setInt(2, entityId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) entries.add(resultSet.getString("created_at") + " — " + resultSet.getString("action") + " — " + resultSet.getString("details"));
            }
        } catch (SQLException e) { throw new RuntimeException("Failed to load activity: " + e.getMessage(), e); }
        return entries;
    }
}
