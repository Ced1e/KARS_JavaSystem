package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.models.Job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for the {@code jobs} table.
 *
 * Jobs have no soft-delete/archive concept, unlike clients and
 * technicians - a job either happened, is happening, or was cancelled,
 * and {@link Job.JobStatus#CANCELLED} already serves as the "this didn't
 * go through" marker. The explicit duplicate-job removal path deletes all
 * related financial and operational rows together in one transaction.
 */
public class JobDAO implements GenericDAO<Job, Integer> {

    private final DatabaseManager databaseManager;

    public JobDAO() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    @Override
    public Job insert(Job job) {
        String sql = "INSERT INTO jobs (client_id, service_category_id, job_date, location, description, po_number, " +
                "job_status, completed_at, billed_at, payment_due_date, tax_reduction_percent, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            bindJobFields(statement, job);

            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    job.setId(generatedKeys.getInt(1));
                }
            }
            return job;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert job for client_id=" + job.getClientId() + ": " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Job job) {
        String sql = "UPDATE jobs SET client_id = ?, service_category_id = ?, job_date = ?, location = ?, " +
                "description = ?, po_number = ?, job_status = ?, completed_at = ?, billed_at = ?, payment_due_date = ?, " +
                "tax_reduction_percent = ?, notes = ?, updated_at = datetime('now') WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            bindJobFields(statement, job);
            statement.setInt(13, job.getId());

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update job id=" + job.getId() + ": " + e.getMessage(), e);
        }
    }

    @Override
    public boolean deleteById(Integer id) {
        return deleteWithRelatedRecords(id);
    }

    /**
     * Permanently removes a job and every record that belongs to it. Expenses
     * are explicitly deleted rather than merely unlinked, since they are part
     * of the duplicate job the user chose to remove. The transaction prevents
     * a half-deleted job if any statement fails.
     */
    public boolean deleteWithRelatedRecords(int jobId) {
        try (Connection connection = databaseManager.getConnection()) {
            boolean originalAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                executeForJob(connection, "DELETE FROM technician_payout_disbursements WHERE technician_payout_id IN (SELECT id FROM technician_payouts WHERE job_id = ?)", jobId);
                executeForJob(connection, "DELETE FROM technician_payouts WHERE job_id = ?", jobId);
                executeForJob(connection, "DELETE FROM payments WHERE job_id = ?", jobId);
                executeForJob(connection, "DELETE FROM job_cash_advance_transactions WHERE job_id = ?", jobId);
                executeForJob(connection, "DELETE FROM job_line_items WHERE job_id = ?", jobId);
                executeForJob(connection, "DELETE FROM expenses WHERE related_job_id = ?", jobId);
                int deleted = executeForJob(connection, "DELETE FROM jobs WHERE id = ?", jobId);
                connection.commit();
                return deleted > 0;
            } catch (SQLException error) {
                connection.rollback();
                throw error;
            } finally {
                connection.setAutoCommit(originalAutoCommit);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete job id=" + jobId + " and its related records: " + e.getMessage(), e);
        }
    }

    private int executeForJob(Connection connection, String sql, int jobId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, jobId);
            return statement.executeUpdate();
        }
    }

    @Override
    public Optional<Job> findById(Integer id) {
        String sql = "SELECT * FROM jobs WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(mapRow(resultSet));
                }
            }
            return Optional.empty();

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find job id=" + id + ": " + e.getMessage(), e);
        }
    }

    /** Every job in stable job-number (database id) order. */
    @Override
    public List<Job> findAll() {
        return queryList("SELECT * FROM jobs ORDER BY job_date DESC, id DESC");
    }

    /** Every job for a given client, most recent first - the core Client -> Jobs relationship. */
    public List<Job> findByClientId(int clientId) {
        String sql = "SELECT * FROM jobs WHERE client_id = ? ORDER BY job_date DESC, id DESC";
        List<Job> jobs = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, clientId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    jobs.add(mapRow(resultSet));
                }
            }
            return jobs;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find jobs for client_id=" + clientId + ": " + e.getMessage(), e);
        }
    }

    /**
     * Searches jobs by Job Code, client name, location, or description
     * (case-insensitive, partial match), with an optional status filter.
     * Job Code isn't a stored column - it's matched via SQLite's built-in
     * {@code printf()} function reproducing the same "JOB-%05d" format
     * used by {@link Job#getJobCode()}, so the search stays entirely
     * server-side rather than fetching every row into Java to filter.
     * A null/blank query and a null statusFilter both mean "no filter" on
     * that dimension.
     */
    public List<Job> search(String query, Job.JobStatus statusFilter) {
        return search(query, statusFilter, null, null, null);
    }

    /** Server-side job filtering by text, status, category, and an optional inclusive date range. */
    public List<Job> search(String query, Job.JobStatus statusFilter, Integer categoryId,
                            java.time.LocalDate fromDate, java.time.LocalDate toDate) {
        boolean hasQuery = query != null && !query.isBlank();

        StringBuilder sql = new StringBuilder(
                "SELECT j.* FROM jobs j LEFT JOIN clients c ON j.client_id = c.id WHERE 1 = 1"
        );
        List<String> params = new ArrayList<>();

        if (statusFilter != null) {
            sql.append(" AND j.job_status = ?");
            params.add(statusFilter.name());
        }

        if (categoryId != null) {
            sql.append(" AND j.service_category_id = ?");
            params.add(String.valueOf(categoryId));
        }

        if (fromDate != null && toDate != null) {
            sql.append(" AND j.job_date BETWEEN ? AND ?");
            params.add(fromDate.toString());
            params.add(toDate.toString());
        }

        if (hasQuery) {
            sql.append(" AND (printf('JOB-%05d', j.id) LIKE ? COLLATE NOCASE " +
                    "OR c.client_name LIKE ? COLLATE NOCASE " +
                    "OR j.location LIKE ? COLLATE NOCASE " +
                    "OR j.description LIKE ? COLLATE NOCASE)");
            String likePattern = "%" + query.trim() + "%";
            params.add(likePattern);
            params.add(likePattern);
            params.add(likePattern);
            params.add(likePattern);
        }

        sql.append(" ORDER BY j.job_date DESC, j.id DESC");

        List<Job> jobs = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                statement.setString(i + 1, params.get(i));
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    jobs.add(mapRow(resultSet));
                }
            }
            return jobs;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to search jobs for '" + query + "': " + e.getMessage(), e);
        }
    }

    private List<Job> queryList(String sql) {
        List<Job> jobs = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                jobs.add(mapRow(resultSet));
            }
            return jobs;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch jobs: " + e.getMessage(), e);
        }
    }

    private void bindJobFields(PreparedStatement statement, Job job) throws SQLException {
        statement.setInt(1, job.getClientId());

        if (job.getServiceCategoryId() != null) {
            statement.setInt(2, job.getServiceCategoryId());
        } else {
            statement.setNull(2, Types.INTEGER);
        }

        statement.setString(3, job.getJobDate());
        statement.setString(4, job.getLocation());
        statement.setString(5, job.getDescription());
        statement.setString(6, job.getPoNumber());
        statement.setString(7, job.getJobStatus().name());
        statement.setString(8, job.getCompletedAt());
        statement.setString(9, job.getBilledAt());
        statement.setString(10, job.getPaymentDueDate());
        statement.setDouble(11, job.getTaxReductionPercent());
        statement.setString(12, job.getNotes());
    }

    private Job mapRow(ResultSet resultSet) throws SQLException {
        Job job = new Job();
        job.setId(resultSet.getInt("id"));
        job.setClientId(resultSet.getInt("client_id"));

        int rawCategoryId = resultSet.getInt("service_category_id");
        job.setServiceCategoryId(resultSet.wasNull() ? null : rawCategoryId);

        job.setJobDate(resultSet.getString("job_date"));
        job.setLocation(resultSet.getString("location"));
        job.setDescription(resultSet.getString("description"));
        job.setPoNumber(resultSet.getString("po_number"));
        job.setJobStatus(Job.JobStatus.valueOf(resultSet.getString("job_status")));
        job.setCompletedAt(resultSet.getString("completed_at"));
        job.setBilledAt(resultSet.getString("billed_at"));
        job.setPaymentDueDate(resultSet.getString("payment_due_date"));
        job.setTaxReductionPercent(resultSet.getDouble("tax_reduction_percent"));
        job.setNotes(resultSet.getString("notes"));
        job.setCreatedAt(resultSet.getString("created_at"));
        job.setUpdatedAt(resultSet.getString("updated_at"));
        return job;
    }
}
