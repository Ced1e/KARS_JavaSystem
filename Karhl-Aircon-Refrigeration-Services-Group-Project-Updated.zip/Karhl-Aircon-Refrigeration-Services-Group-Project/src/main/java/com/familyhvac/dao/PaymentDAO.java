package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.models.Payment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for the {@code payments} table (client payments
 * received against a job - not to be confused with technician payouts,
 * which are a separate table and a separate money flow, built in a
 * later phase).
 */
public class PaymentDAO implements GenericDAO<Payment, Integer> {

    private final DatabaseManager databaseManager;

    public PaymentDAO() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    @Override
    public Payment insert(Payment payment) {
        String sql = "INSERT INTO payments (job_id, payment_date, amount, payment_type, reference_number, remarks) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            statement.setInt(1, payment.getJobId());
            statement.setString(2, payment.getPaymentDate());
            statement.setDouble(3, payment.getAmount());
            statement.setString(4, payment.getPaymentType().name());
            statement.setString(5, payment.getReferenceNumber());
            statement.setString(6, payment.getRemarks());

            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    payment.setId(generatedKeys.getInt(1));
                }
            }
            return payment;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert payment for job_id=" + payment.getJobId() + ": " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Payment payment) {
        // job_id is intentionally not updatable - a payment doesn't move between
        // jobs; correcting that would be a delete + re-add against the right job.
        String sql = "UPDATE payments SET payment_date = ?, amount = ?, payment_type = ?, " +
                "reference_number = ?, remarks = ? WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, payment.getPaymentDate());
            statement.setDouble(2, payment.getAmount());
            statement.setString(3, payment.getPaymentType().name());
            statement.setString(4, payment.getReferenceNumber());
            statement.setString(5, payment.getRemarks());
            statement.setInt(6, payment.getId());

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update payment id=" + payment.getId() + ": " + e.getMessage(), e);
        }
    }

    /**
     * Not called by PaymentService or the UI in this phase - implemented
     * only to satisfy {@link GenericDAO}, same as {@code JobDAO.deleteById}.
     */
    @Override
    public boolean deleteById(Integer id) {
        String sql = "DELETE FROM payments WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete payment id=" + id + ": " + e.getMessage(), e);
        }
    }

    @Override
    public Optional<Payment> findById(Integer id) {
        String sql = "SELECT * FROM payments WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(mapRow(resultSet));
                }
            }
            return Optional.empty();

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find payment id=" + id + ": " + e.getMessage(), e);
        }
    }

    /** Every payment across every job. Rarely useful directly - see {@link #findByJobId(int)}. */
    @Override
    public List<Payment> findAll() {
        return queryList("SELECT * FROM payments ORDER BY payment_date DESC, id DESC");
    }

    /** A job's payments, most recent first - the list a Job payments section actually wants. */
    public List<Payment> findByJobId(int jobId) {
        String sql = "SELECT * FROM payments WHERE job_id = ? ORDER BY payment_date DESC, id DESC";
        List<Payment> payments = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, jobId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    payments.add(mapRow(resultSet));
                }
            }
            return payments;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find payments for job_id=" + jobId + ": " + e.getMessage(), e);
        }
    }

    /**
     * The total paid on a job, computed in SQL as SUM(amount) - never
     * stored anywhere, per the project's derived-values principle. Returns
     * 0 for a job with no payments yet.
     */
    public double calculateTotalPaid(int jobId) {
        String sql = "SELECT COALESCE(SUM(amount), 0) AS total_paid FROM payments WHERE job_id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, jobId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getDouble("total_paid") : 0.0;
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to calculate total paid for job_id=" + jobId + ": " + e.getMessage(), e);
        }
    }

    private List<Payment> queryList(String sql) {
        List<Payment> payments = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                payments.add(mapRow(resultSet));
            }
            return payments;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch payments: " + e.getMessage(), e);
        }
    }

    private Payment mapRow(ResultSet resultSet) throws SQLException {
        Payment payment = new Payment();
        payment.setId(resultSet.getInt("id"));
        payment.setJobId(resultSet.getInt("job_id"));
        payment.setPaymentDate(resultSet.getString("payment_date"));
        payment.setAmount(resultSet.getDouble("amount"));
        payment.setPaymentType(Payment.PaymentType.valueOf(resultSet.getString("payment_type")));
        payment.setReferenceNumber(resultSet.getString("reference_number"));
        payment.setRemarks(resultSet.getString("remarks"));
        payment.setCreatedAt(resultSet.getString("created_at"));
        return payment;
    }
}
