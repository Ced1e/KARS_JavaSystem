package com.familyhvac.dao;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.models.Technician;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Data access object for the {@code technicians} table.
 *
 * Delete is a SOFT delete (archive): {@link #deleteById(Integer)} sets
 * is_active = 0 rather than removing the row, since technicians are
 * referenced by jobs and technician_payouts, and historical records must
 * never disappear. {@link #findAll()} therefore only returns active
 * technicians by default; use {@link #findAllIncludingInactive()} when
 * archived technicians need to be visible too.
 */
public class TechnicianDAO implements GenericDAO<Technician, Integer> {

    private final DatabaseManager databaseManager;

    public TechnicianDAO() {
        this.databaseManager = DatabaseManager.getInstance();
    }

    @Override
    public Technician insert(Technician technician) {
        String sql = "INSERT INTO technicians (name, phone_number, notes, is_active) VALUES (?, ?, ?, ?)";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            bindTechnicianFields(statement, technician);
            statement.setInt(4, technician.isActive() ? 1 : 0);

            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    technician.setId(generatedKeys.getInt(1));
                }
            }
            return technician;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to insert technician '" + technician.getName() + "': " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Technician technician) {
        String sql = "UPDATE technicians SET name = ?, phone_number = ?, notes = ?, " +
                "updated_at = datetime('now') WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            bindTechnicianFields(statement, technician);
            statement.setInt(4, technician.getId());

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to update technician id=" + technician.getId() + ": " + e.getMessage(), e);
        }
    }

    /**
     * Soft delete (archive): marks the technician inactive rather than
     * removing the row, so historical jobs and payouts linked to this
     * technician never break.
     */
    @Override
    public boolean deleteById(Integer id) {
        String sql = "UPDATE technicians SET is_active = 0, updated_at = datetime('now') WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to archive technician id=" + id + ": " + e.getMessage(), e);
        }
    }

    /** Reverses an archive, marking the technician active again. */
    public boolean restoreById(Integer id) {
        String sql = "UPDATE technicians SET is_active = 1, updated_at = datetime('now') WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to restore technician id=" + id + ": " + e.getMessage(), e);
        }
    }

    @Override
    public Optional<Technician> findById(Integer id) {
        String sql = "SELECT * FROM technicians WHERE id = ?";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(mapRow(resultSet));
                }
            }
            return Optional.empty();

        } catch (SQLException e) {
            throw new RuntimeException("Failed to find technician id=" + id + ": " + e.getMessage(), e);
        }
    }

    /** Active technicians only, alphabetical by name - the default list everywhere in the app. */
    @Override
    public List<Technician> findAll() {
        return queryList("SELECT * FROM technicians WHERE is_active = 1 ORDER BY id ASC");
    }

    /** Every technician regardless of status, for a "show archived" toggle. */
    public List<Technician> findAllIncludingInactive() {
        return queryList("SELECT * FROM technicians ORDER BY id ASC");
    }

    /**
     * Searches technicians by name or phone number (case-insensitive,
     * partial match) - the only two searchable free-text fields on this
     * minimal entity.
     */
    public List<Technician> search(String query, boolean includeInactive) {
        String sql = "SELECT * FROM technicians WHERE " +
                (includeInactive ? "1 = 1" : "is_active = 1") +
                " AND (name LIKE ? COLLATE NOCASE OR phone_number LIKE ?) " +
                "ORDER BY id ASC";

        List<Technician> technicians = new ArrayList<>();
        String likePattern = "%" + query + "%";

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, likePattern);
            statement.setString(2, likePattern);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    technicians.add(mapRow(resultSet));
                }
            }
            return technicians;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to search technicians for '" + query + "': " + e.getMessage(), e);
        }
    }

    /**
     * Finds active technicians with a name similar to the given name
     * (case-insensitive partial match). Used purely to power a
     * non-blocking "a similar technician may already exist" warning -
     * never prevents saving. When {@code excludeId} is non-null, that
     * technician's own row is excluded (needed when checking an edit
     * against everyone else).
     */
    public List<Technician> findSimilarByName(String name, Integer excludeId) {
        StringBuilder sql = new StringBuilder(
                "SELECT * FROM technicians WHERE is_active = 1 AND name LIKE ? COLLATE NOCASE"
        );
        if (excludeId != null) {
            sql.append(" AND id != ?");
        }
        sql.append(" ORDER BY id ASC");

        List<Technician> technicians = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {

            statement.setString(1, "%" + name + "%");
            if (excludeId != null) {
                statement.setInt(2, excludeId);
            }

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    technicians.add(mapRow(resultSet));
                }
            }
            return technicians;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to search for similar technician names: " + e.getMessage(), e);
        }
    }

    private List<Technician> queryList(String sql) {
        List<Technician> technicians = new ArrayList<>();

        try (Connection connection = databaseManager.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                technicians.add(mapRow(resultSet));
            }
            return technicians;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to fetch technicians: " + e.getMessage(), e);
        }
    }

    private void bindTechnicianFields(PreparedStatement statement, Technician technician) throws SQLException {
        statement.setString(1, technician.getName());
        statement.setString(2, technician.getPhoneNumber());
        statement.setString(3, technician.getNotes());
    }

    private Technician mapRow(ResultSet resultSet) throws SQLException {
        Technician technician = new Technician();
        technician.setId(resultSet.getInt("id"));
        technician.setName(resultSet.getString("name"));
        technician.setPhoneNumber(resultSet.getString("phone_number"));
        technician.setNotes(resultSet.getString("notes"));
        technician.setActive(resultSet.getInt("is_active") == 1);
        technician.setCreatedAt(resultSet.getString("created_at"));
        technician.setUpdatedAt(resultSet.getString("updated_at"));
        return technician;
    }
}
