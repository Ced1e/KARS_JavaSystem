package com.familyhvac;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.database.SchemaInitializer;
import com.familyhvac.services.AuthService;
import com.familyhvac.utils.AppConstants;
import com.familyhvac.utils.UITheme;
import com.familyhvac.views.LoginView;

import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.Image;

/**
 * Application entry point.
 *
 * Startup sequence:
 *   1. Initialize the SQLite database file and create the schema if needed.
 *   2. If no users exist yet (first run), seed a default administrator account.
 *   3. Launch the login window.
 */
public final class Main {

    private static final String DEFAULT_ADMIN_USERNAME = "admin";
    private static final String DEFAULT_ADMIN_PASSWORD = "admin123";

    public static void main(String[] args) {
        setLookAndFeel();
        UITheme.applyGlobalDefaults();
        initializeDatabase();
        seedDefaultAdminIfNeeded();

        SwingUtilities.invokeLater(() -> {
            LoginView login = new LoginView();
            try (var logo = Main.class.getResourceAsStream("/karhl-logo.png")) {
                Image image = ImageIO.read(logo);
                if (image != null) login.setIconImage(image);
            } catch (Exception ignored) { }
            login.setVisible(true);
        });
    }

    private static void setLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Fall back to the default cross-platform look and feel silently.
            System.err.println("Could not set system look and feel: " + e.getMessage());
        }
    }

    private static void initializeDatabase() {
        DatabaseManager databaseManager = DatabaseManager.getInstance();
        new SchemaInitializer(databaseManager).initialize();
    }

    private static void seedDefaultAdminIfNeeded() {
        AuthService authService = new AuthService();
        if (!authService.hasAnyUsers()) {
            authService.createInitialAdmin(DEFAULT_ADMIN_USERNAME, DEFAULT_ADMIN_PASSWORD, "Administrator");
            System.out.println("======================================================");
            System.out.println(" " + AppConstants.APP_NAME);
            System.out.println(" First run detected - a default admin account was created:");
            System.out.println("   Username: " + DEFAULT_ADMIN_USERNAME);
            System.out.println("   Password: " + DEFAULT_ADMIN_PASSWORD);
            System.out.println(" Please log in and change this password as soon as possible.");
            System.out.println("======================================================");
        }
    }
}
