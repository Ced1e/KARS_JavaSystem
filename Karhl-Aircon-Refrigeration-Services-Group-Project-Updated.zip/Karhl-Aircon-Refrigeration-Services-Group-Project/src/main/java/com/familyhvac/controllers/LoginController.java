package com.familyhvac.controllers;

import com.familyhvac.services.AuthService;
import com.familyhvac.views.LoginView;
import com.familyhvac.views.MainFrame;

import javax.swing.*;

/**
 * Handles the login screen's button actions. The view knows nothing about
 * AuthService or the database - it only calls back into this controller,
 * keeping the JFrame free of business logic.
 */
public class LoginController {

    private final LoginView view;
    private final AuthService authService;

    public LoginController(LoginView view) {
        this.view = view;
        this.authService = new AuthService();
        attachListeners();
    }

    private void attachListeners() {
        view.getLoginButton().addActionListener(e -> handleLogin());
        view.getPasswordField().addActionListener(e -> handleLogin()); // Enter key submits
    }

    private void handleLogin() {
        String username = view.getUsername();
        String password = view.getPassword();

        view.setLoading(true);

        // Run the login off the Event Dispatch Thread so the UI never freezes,
        // even though bcrypt verification is fast, this keeps the pattern
        // consistent for future services that hit the database on login-sized paths.
        SwingWorker<AuthService.LoginResult, Void> worker = new SwingWorker<>() {
            @Override
            protected AuthService.LoginResult doInBackground() {
                return authService.login(username, password);
            }

            @Override
            protected void done() {
                view.setLoading(false);
                try {
                    AuthService.LoginResult result = get();
                    if (result.isSuccess()) {
                        onLoginSuccess();
                    } else {
                        view.showError(result.getMessage());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void onLoginSuccess() {
        MainFrame mainFrame = new MainFrame();
        mainFrame.setVisible(true);
        view.dispose();
    }
}
