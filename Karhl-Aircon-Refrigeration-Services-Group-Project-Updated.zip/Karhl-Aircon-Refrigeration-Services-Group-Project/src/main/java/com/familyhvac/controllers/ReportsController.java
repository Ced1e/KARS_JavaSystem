package com.familyhvac.controllers;

import com.familyhvac.dao.AnalyticsDAO;
import com.familyhvac.services.AnalyticsService;
import com.familyhvac.services.ReportExportService;
import com.familyhvac.views.ReportsPanel;

import javax.swing.*;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

/** Coordinates the date-scoped detailed job-log report and its exports. */
public class ReportsController {
    private final ReportsPanel view;
    private final AnalyticsService service = new AnalyticsService();
    private final ReportExportService exports = new ReportExportService();

    public ReportsController(ReportsPanel view) {
        this.view = view;
        view.getRunButton().addActionListener(event -> run());
        view.getPdfButton().addActionListener(event -> export(false));
        view.getDocxButton().addActionListener(event -> export(true));
        view.getPrintButton().addActionListener(event -> view.printResults());
        run();
    }

    private void run() {
        LocalDate[] range = range();
        new SwingWorker<java.util.Map.Entry<List<AnalyticsDAO.JobReportRow>, AnalyticsDAO.ReportSummary>, Void>() {
            @Override protected java.util.Map.Entry<List<AnalyticsDAO.JobReportRow>, AnalyticsDAO.ReportSummary> doInBackground() { return new java.util.AbstractMap.SimpleEntry<>(service.jobLog(range[0], range[1]), service.reportSummary(range[0], range[1])); }
            @Override protected void done() { try { var data=get(); view.setJobLog(data.getKey()); view.setSummary(data.getValue()); } catch (Exception error) { view.showError("Unable to load report: " + error.getMessage()); } }
        }.execute();
    }

    private LocalDate[] range() {
        LocalDate selected = view.getDate();
        LocalDate first = switch (view.getPeriod()) {
            case "Week" -> selected.minusDays(selected.getDayOfWeek().getValue() - 1);
            case "Month" -> selected.withDayOfMonth(1);
            case "Quarter" -> selected.withMonth(((selected.getMonthValue()-1)/3)*3+1).withDayOfMonth(1);
            case "Year" -> selected.withDayOfYear(1);
            default -> selected;
        };
        LocalDate last = switch (view.getPeriod()) {
            case "Week" -> first.plusDays(6); case "Month" -> first.plusMonths(1).minusDays(1);
            case "Quarter" -> first.plusMonths(3).minusDays(1); case "Year" -> first.plusYears(1).minusDays(1); default -> selected;
        };
        return new LocalDate[]{first, last};
    }
    private void export(boolean word) {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new java.io.File("Job_Activity_Log" + (word ? ".docx" : ".pdf")));
        if (chooser.showSaveDialog(view) != JFileChooser.APPROVE_OPTION) return;
        Path file = chooser.getSelectedFile().toPath(); LocalDate[] range = range();
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                AnalyticsDAO.ReportSummary s=view.getSummary(); String summary="Gross Revenue: PHP "+String.format("%,.2f",s.grossRevenue())+" | Operating Expenses: PHP "+String.format("%,.2f",s.operatingExpenses())+" | Technician Payouts: PHP "+String.format("%,.2f",s.technicianPayouts())+" | EWT Withheld: PHP "+String.format("%,.2f",s.totalEwtWithheld())+" | Net Earnings: PHP "+String.format("%,.2f",s.netEarnings());
                List<AnalyticsDAO.ExpenseReportRow> expenseRows = service.expenseLog(range[0], range[1]);
                if (word) exports.exportDocx(file, "Job Activity Log", "Period: " + range[0] + " to " + range[1], summary, view.getReportRows(), expenseRows);
                else exports.exportPdf(file, "Job Activity Log", "Period: " + range[0] + " to " + range[1], summary, view.getReportRows(), expenseRows);
                return null;
            }
            @Override protected void done() { try { get(); JOptionPane.showMessageDialog(view, "Report exported to " + file); } catch (Exception error) { view.showError("Export failed: " + error.getMessage()); } }
        }.execute();
    }
}
