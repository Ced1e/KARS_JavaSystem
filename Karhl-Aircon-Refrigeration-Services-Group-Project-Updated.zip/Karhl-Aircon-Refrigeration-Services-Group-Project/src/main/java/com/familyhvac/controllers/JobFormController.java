package com.familyhvac.controllers;

import com.familyhvac.models.Client;
import com.familyhvac.models.Job;
import com.familyhvac.models.JobLineItem;
import com.familyhvac.models.Payment;
import com.familyhvac.models.ServiceCategory;
import com.familyhvac.models.TechnicianPayout;
import com.familyhvac.models.TechnicianPayoutDisbursement;
import com.familyhvac.models.JobCashAdvanceTransaction;
import com.familyhvac.models.Expense;
import com.familyhvac.services.ClientService;
import com.familyhvac.services.JobLineItemService;
import com.familyhvac.services.JobService;
import com.familyhvac.services.PaymentService;
import com.familyhvac.services.ServiceCategoryService;
import com.familyhvac.services.ServiceResult;
import com.familyhvac.services.TechnicianPayoutService;
import com.familyhvac.services.JobCashAdvanceService;
import com.familyhvac.services.ExpenseService;
import com.familyhvac.views.JobFormDialog;
import com.familyhvac.views.LineItemFormDialog;
import com.familyhvac.views.PaymentFormDialog;
import com.familyhvac.views.TechnicianPayoutFormDialog;
import com.familyhvac.views.PayoutDisbursementFormDialog;
import com.familyhvac.views.JobCashAdvanceFormDialog;
import com.familyhvac.views.ExpenseFormDialog;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Handles {@link JobFormDialog}: populating the client/category dropdowns
 * (a View never calls a Service directly, so this fetch happens here),
 * and saving.
 *
 * Save is deliberately two-step when editing: header fields always go
 * through {@link JobService#updateJob}, which protects job_status/
 * completed_at/billed_at from being overwritten by an unrelated edit. If
 * the status dropdown was actually changed, a SEPARATE call to
 * {@link JobService#updateJobStatus} applies that transition - the only
 * path that manages completed_at automatically. This form never sets
 * completed_at directly.
 */
public class JobFormController {

    private final JobFormDialog view;
    private final JobService jobService;
    private final ClientService clientService;
    private final ServiceCategoryService serviceCategoryService;
    private final JobLineItemService jobLineItemService;
    private final PaymentService paymentService;
    private final TechnicianPayoutService technicianPayoutService;
    private final JobCashAdvanceService cashAdvanceService;
    private final ExpenseService expenseService;
    private final Job existingJob;

    public JobFormController(JobFormDialog view, Job existingJob) {
        this.view = view;
        this.jobService = new JobService();
        this.clientService = new ClientService();
        this.serviceCategoryService = new ServiceCategoryService();
        this.jobLineItemService = new JobLineItemService();
        this.paymentService = new PaymentService();
        this.technicianPayoutService = new TechnicianPayoutService();
        this.cashAdvanceService = new JobCashAdvanceService();
        this.expenseService = new ExpenseService();
        this.existingJob = existingJob;
        attachListeners();
        loadDropdownOptions();

        // Line items and payments both require a real job_id, so this only applies
        // in Edit mode - in Add mode, JobFormDialog never creates their table/buttons at all.
        if (existingJob != null) {
            attachLineItemListeners();
            attachPayoutListeners();
            attachCashAdvanceListeners();
            attachJobExpenseListeners();
            refreshFinancials();
            refreshPayouts();
            refreshCashAdvances();
            refreshJobExpenseTotal();
        }
    }

    private void attachListeners() {
        view.getSaveButton().addActionListener(e -> handleSave());
    }

    private static final class DropdownOptions {
        final List<Client> clients;
        final List<ServiceCategory> categories;

        DropdownOptions(List<Client> clients, List<ServiceCategory> categories) {
            this.clients = clients;
            this.categories = categories;
        }
    }

    private void loadDropdownOptions() {
        view.getSaveButton().setEnabled(false);

        SwingWorker<DropdownOptions, Void> worker = new SwingWorker<>() {
            @Override
            protected DropdownOptions doInBackground() {
                return new DropdownOptions(
                        clientService.listActiveClients(),
                        serviceCategoryService.listActiveCategories()
                );
            }

            @Override
            protected void done() {
                view.getSaveButton().setEnabled(true);
                try {
                    DropdownOptions options = get();
                    view.setClientOptions(options.clients);
                    view.setServiceCategoryOptions(options.categories);

                    if (existingJob != null) {
                        view.selectClientById(existingJob.getClientId());
                        view.selectServiceCategoryById(existingJob.getServiceCategoryId());
                    }
                } catch (Exception ex) {
                    view.showError("Failed to load clients/categories: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private static final java.util.regex.Pattern ISO_DATE_PATTERN = java.util.regex.Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");

    private void handleSave() {
        Client selectedClient = view.getSelectedClient();
        if (selectedClient == null) {
            view.showError("A client is required.");
            return;
        }

        java.time.LocalDate selectedJobDate;
        try { selectedJobDate = view.getJobDate(); }
        catch (Exception error) { view.markFieldInvalid(view.getJobDateField()); view.showError("Job date must be in DD-MM-YYYY format."); return; }
        if (selectedJobDate == null) {
            view.markFieldInvalid(view.getJobDateField());
            view.showError("Job date is required.");
            return;
        }
        String jobDate = DateSupport.toStorage(selectedJobDate);

        double taxReductionPercent;
        try {
            taxReductionPercent = Double.parseDouble(view.getTaxReductionPercentInput().trim());
        } catch (NumberFormatException ex) {
            view.markFieldInvalid(view.getTaxReductionPercentField());
            view.showError("Tax reduction must be a number from 0 to 100.");
            return;
        }
        if (taxReductionPercent < 0 || taxReductionPercent > 100) {
            view.markFieldInvalid(view.getTaxReductionPercentField());
            view.showError("Tax reduction must be between 0 and 100 percent.");
            return;
        }

        Job job = existingJob != null ? existingJob : new Job();
        job.setClientId(selectedClient.getId());

        ServiceCategory selectedCategory = view.getSelectedServiceCategory();
        job.setServiceCategoryId(selectedCategory != null ? selectedCategory.getId() : null);

        job.setJobDate(jobDate);
        job.setLocation(trimToNull(view.getLocationInput()));
        job.setDescription(trimToNull(view.getDescriptionInput()));
        job.setPoNumber(trimToNull(view.getPoNumberInput()));
        job.setPaymentDueDate(null);
        job.setTaxReductionPercent(taxReductionPercent);
        job.setNotes(trimToNull(view.getNotesInput()));

        Job.JobStatus selectedStatus = view.getSelectedStatus();
        boolean statusChanged = existingJob != null && selectedStatus != existingJob.getJobStatus();
        java.time.LocalDate actualCompletionDate = null;
        if (existingJob != null && selectedStatus == Job.JobStatus.COMPLETED) {
            try { actualCompletionDate = view.getActualCompletionDate(); }
            catch (Exception error) { view.showError("Actual completion date must be in DD-MM-YYYY format."); return; }
            if (actualCompletionDate == null) { view.showError("An actual completion date is required for a completed job."); return; }
        }
        final java.time.LocalDate finalCompletionDate = actualCompletionDate;

        view.getSaveButton().setEnabled(false);

        SwingWorker<ServiceResult<Job>, Void> worker = new SwingWorker<>() {
            @Override
            protected ServiceResult<Job> doInBackground() {
                ServiceResult<Job> result = existingJob != null
                        ? jobService.updateJob(job)
                        : jobService.createJob(job);

                if (result.isSuccess() && (statusChanged || (existingJob != null && selectedStatus == Job.JobStatus.COMPLETED))) {
                    result = jobService.updateJobStatus(job.getId(), selectedStatus, finalCompletionDate);
                }
                return result;
            }

            @Override
            protected void done() {
                view.getSaveButton().setEnabled(true);
                try {
                    ServiceResult<Job> result = get();
                    if (result.isSuccess()) {
                        view.closeDialog();
                    } else {
                        view.showError(result.getMessage());
                        highlightFieldForError(result.getMessage());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    /**
     * Maps a validation failure message from the service back to the field
     * it concerns, so the field gets a red border instead of leaving the
     * user to guess which one needs fixing. The service message stays the
     * single source of truth for the actual rule - this only decides where
     * to point.
     */
    private void highlightFieldForError(String message) {
        view.clearFieldValidation(view.getJobDateField());
        view.clearFieldValidation(view.getTaxReductionPercentField());

        if (message == null) {
            return;
        }
        String lowerMessage = message.toLowerCase();
        if (lowerMessage.contains("tax reduction")) {
            view.markFieldInvalid(view.getTaxReductionPercentField());
        } else if (lowerMessage.contains("job date")) {
            view.markFieldInvalid(view.getJobDateField());
        }
    }

    private void attachLineItemListeners() {
        view.getAddLineItemButton().addActionListener(e -> openAddLineItemDialog());
        view.getEditLineItemButton().addActionListener(e -> openEditLineItemDialogForSelection());
        view.getRemoveLineItemButton().addActionListener(e -> removeSelectedLineItem());

        view.getLineItemTable().getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updateLineItemButtonStates();
            }
        });

        view.getLineItemTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2) {
                    openEditLineItemDialogForSelection();
                }
            }
        });
    }

    private void updateLineItemButtonStates() {
        boolean hasSelection = view.getLineItemTable().getSelectedRow() != -1;
        view.getEditLineItemButton().setEnabled(hasSelection);
        view.getRemoveLineItemButton().setEnabled(hasSelection);
    }

    /**
     * Result bundle for the background fetch - line items, Job Total,
     * payments, and Total Paid, all fetched together so the displayed
     * Remaining Balance is always computed from one consistent snapshot
     * rather than two independently-timed fetches.
     */
    private static final class FinancialsData {
        final List<JobLineItem> lineItems;
        final double jobTotal;
        final List<Payment> payments;
        final double totalPaid;

        FinancialsData(List<JobLineItem> lineItems, double jobTotal, List<Payment> payments, double totalPaid) {
            this.lineItems = lineItems;
            this.jobTotal = jobTotal;
            this.payments = payments;
            this.totalPaid = totalPaid;
        }
    }

    /**
     * Reloads the line-item table, Job Total, payment table, Total Paid,
     * and Remaining Balance from the database. Job Total and Total Paid
     * are never assembled by summing a table client-side - they come
     * straight from {@link JobLineItemService#calculateJobTotal(int)} and
     * {@link PaymentService#calculateTotalPaid(int)}, which compute their
     * sums in SQL, so nothing displayed here can drift from what the DAOs
     * consider authoritative. Remaining Balance = Job Total - Total Paid,
     * computed here and never stored.
     */
    private void refreshFinancials() {
        int jobId = existingJob.getId();

        SwingWorker<FinancialsData, Void> worker = new SwingWorker<>() {
            @Override
            protected FinancialsData doInBackground() {
                List<JobLineItem> lineItems = jobLineItemService.listLineItemsForJob(jobId);
                double jobTotal = jobLineItemService.calculateJobTotal(jobId);
                List<Payment> payments = paymentService.listPaymentsForJob(jobId);
                double totalPaid = paymentService.calculateTotalPaid(jobId);
                return new FinancialsData(lineItems, jobTotal, payments, totalPaid);
            }

            @Override
            protected void done() {
                try {
                    FinancialsData data = get();
                    view.setLineItems(data.lineItems);
                    view.setJobTotal(data.jobTotal);
                    updateLineItemButtonStates();
                } catch (Exception ex) {
                    view.showError("Failed to load job financials: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void openAddLineItemDialog() {
        LineItemFormDialog dialog = new LineItemFormDialog(view, existingJob.getId(), null);
        dialog.setVisible(true);
        refreshFinancials(); // refresh after the dialog closes, whether saved or cancelled
    }

    private void openEditLineItemDialogForSelection() {
        JobLineItem selected = getSelectedLineItem();
        if (selected == null) {
            return;
        }
        LineItemFormDialog dialog = new LineItemFormDialog(view, existingJob.getId(), selected);
        dialog.setVisible(true);
        refreshFinancials();
    }

    private void removeSelectedLineItem() {
        JobLineItem selected = getSelectedLineItem();
        if (selected == null) {
            return;
        }

        boolean confirmed = view.confirm(
                "Remove \"" + selected.getDescription() + "\" from this job?",
                "Remove Line Item");
        if (!confirmed) {
            return;
        }

        SwingWorker<ServiceResult<Void>, Void> worker = new SwingWorker<>() {
            @Override
            protected ServiceResult<Void> doInBackground() {
                return jobLineItemService.removeLineItem(selected.getId());
            }

            @Override
            protected void done() {
                try {
                    ServiceResult<Void> result = get();
                    if (result.isSuccess()) {
                        refreshFinancials();
                    } else {
                        view.showError(result.getMessage());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private JobLineItem getSelectedLineItem() {
        int selectedViewRow = view.getLineItemTable().getSelectedRow();
        if (selectedViewRow == -1) {
            return null;
        }
        int modelRow = view.getLineItemTable().convertRowIndexToModel(selectedViewRow);
        return view.getLineItemTableModel().getLineItemAt(modelRow);
    }

    private void attachPaymentListeners() {
        view.getAddPaymentButton().addActionListener(e -> openAddPaymentDialog());
        view.getEditPaymentButton().addActionListener(e -> openEditPaymentDialogForSelection());

        view.getPaymentTable().getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updatePaymentButtonStates();
            }
        });

        view.getPaymentTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2) {
                    openEditPaymentDialogForSelection();
                }
            }
        });
    }

    private void updatePaymentButtonStates() {
        boolean hasSelection = view.getPaymentTable().getSelectedRow() != -1;
        view.getEditPaymentButton().setEnabled(hasSelection);
    }

    private void openAddPaymentDialog() {
        PaymentFormDialog dialog = new PaymentFormDialog(view, existingJob.getId(), null);
        dialog.setVisible(true);
        refreshFinancials(); // refresh after the dialog closes, whether saved or cancelled
    }

    private void openEditPaymentDialogForSelection() {
        Payment selected = getSelectedPayment();
        if (selected == null) {
            return;
        }
        PaymentFormDialog dialog = new PaymentFormDialog(view, existingJob.getId(), selected);
        dialog.setVisible(true);
        refreshFinancials();
    }

    private Payment getSelectedPayment() {
        int selectedViewRow = view.getPaymentTable().getSelectedRow();
        if (selectedViewRow == -1) {
            return null;
        }
        int modelRow = view.getPaymentTable().convertRowIndexToModel(selectedViewRow);
        return view.getPaymentTableModel().getPaymentAt(modelRow);
    }

    private void attachPayoutListeners() {
        view.getAddPayoutButton().addActionListener(e -> openPayoutDialog(null));
        view.getEditPayoutButton().addActionListener(e -> openPayoutDialog(getSelectedPayout()));
        view.getRemovePayoutButton().addActionListener(e -> removeSelectedPayout());
        view.getAddDisbursementButton().addActionListener(e -> openDisbursementDialog());
        view.getPayoutTable().getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) { updatePayoutButtons(); refreshSelectedPayoutLedger(); } });
        view.getPayoutTable().addMouseListener(new MouseAdapter() { @Override public void mouseClicked(MouseEvent e) { if (e.getClickCount() == 2) openPayoutDialog(getSelectedPayout()); } });
    }

    private void refreshPayouts() {
        int jobId = existingJob.getId();
        new SwingWorker<java.util.AbstractMap.SimpleEntry<List<TechnicianPayout>, java.util.Map<Integer, Double>>, Void>() {
            @Override protected java.util.AbstractMap.SimpleEntry<List<TechnicianPayout>, java.util.Map<Integer, Double>> doInBackground() {
                List<TechnicianPayout> payouts = technicianPayoutService.listPayoutsForJob(jobId);
                java.util.Map<Integer, Double> totals = new java.util.HashMap<>();
                for (TechnicianPayout payout : payouts) totals.put(payout.getId(), technicianPayoutService.calculateDisbursed(payout.getId()));
                return new java.util.AbstractMap.SimpleEntry<>(payouts, totals);
            }
            @Override protected void done() { try { var data=get(); view.setPayouts(data.getKey(), data.getValue()); updatePayoutButtons(); refreshSelectedPayoutLedger(); } catch(Exception ex) { view.showError("Failed to load technician payouts: " + ex.getMessage()); } }
        }.execute();
    }

    private void refreshSelectedPayoutLedger() {
        TechnicianPayout payout = getSelectedPayout();
        if (payout == null) { view.setDisbursements(List.of()); view.setPayoutSummary(null, 0); return; }
        new SwingWorker<java.util.AbstractMap.SimpleEntry<List<TechnicianPayoutDisbursement>, Double>, Void>() {
            @Override protected java.util.AbstractMap.SimpleEntry<List<TechnicianPayoutDisbursement>, Double> doInBackground() { return new java.util.AbstractMap.SimpleEntry<>(technicianPayoutService.listDisbursements(payout.getId()), technicianPayoutService.calculateDisbursed(payout.getId())); }
            @Override protected void done() { try { var data=get(); view.setDisbursements(data.getKey()); view.setPayoutSummary(payout.getApprovedAmount(), data.getValue()); } catch(Exception ex) { view.showError("Failed to load payout ledger: " + ex.getMessage()); } }
        }.execute();
    }

    private void updatePayoutButtons() { boolean selected=getSelectedPayout()!=null; view.getEditPayoutButton().setEnabled(selected); view.getRemovePayoutButton().setEnabled(selected); view.getAddDisbursementButton().setEnabled(selected); }
    private TechnicianPayout getSelectedPayout() { int row=view.getPayoutTable().getSelectedRow(); return row<0?null:view.getPayoutTableModel().getPayoutAt(view.getPayoutTable().convertRowIndexToModel(row)); }
    private void openPayoutDialog(TechnicianPayout payout) { if (payout == null && view.getPayoutTable().getSelectedRow()!=-1) { /* explicit Add is still a new assignment */ } TechnicianPayoutFormDialog dialog=new TechnicianPayoutFormDialog(view, existingJob.getId(), payout); dialog.setVisible(true); refreshPayouts(); }
    private void removeSelectedPayout() { TechnicianPayout payout=getSelectedPayout(); if(payout==null||!view.confirm("Remove " + payout.getTechnicianName() + " from this job? Any payout disbursements recorded for this assignment will also be removed.", "Remove Technician")) return; new SwingWorker<ServiceResult<Void>,Void>() { @Override protected ServiceResult<Void> doInBackground(){return technicianPayoutService.removePayout(payout.getId());} @Override protected void done(){try{ServiceResult<Void> result=get();if(result.isSuccess())refreshPayouts();else view.showError(result.getMessage());}catch(Exception ex){view.showError("Unexpected error: "+ex.getMessage());}} }.execute(); }
    private void openDisbursementDialog() { TechnicianPayout payout=getSelectedPayout(); if(payout==null)return; PayoutDisbursementFormDialog dialog=new PayoutDisbursementFormDialog(view,payout.getId()); dialog.setVisible(true); refreshPayouts(); }

    private void attachCashAdvanceListeners() { view.getAddCashAdvanceButton().addActionListener(e -> openCashAdvanceDialog()); }
    private void openCashAdvanceDialog() { JobCashAdvanceFormDialog dialog=new JobCashAdvanceFormDialog(view,existingJob.getId()); dialog.setVisible(true); refreshCashAdvances(); }
    private void refreshCashAdvances() { int jobId=existingJob.getId(); new SwingWorker<java.util.AbstractMap.SimpleEntry<List<JobCashAdvanceTransaction>,Double>,Void>() { @Override protected java.util.AbstractMap.SimpleEntry<List<JobCashAdvanceTransaction>,Double> doInBackground(){return new java.util.AbstractMap.SimpleEntry<>(cashAdvanceService.listForJob(jobId),cashAdvanceService.calculateBalance(jobId));} @Override protected void done(){try{var data=get();view.setCashAdvanceTransactions(data.getKey());view.setCashAdvanceBalance(data.getValue());}catch(Exception ex){view.showError("Failed to load cash advances: "+ex.getMessage());}} }.execute(); }
    private void attachJobExpenseListeners() {
        view.getAddJobExpenseButton().addActionListener(e -> openJobExpenseDialog(null));
        view.getEditJobExpenseButton().addActionListener(e -> openJobExpenseDialog(getSelectedJobExpense()));
        view.getRemoveJobExpenseButton().addActionListener(e -> removeSelectedJobExpense());
        view.getJobExpenseTable().getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) updateJobExpenseButtonStates(); });
        view.getJobExpenseTable().addMouseListener(new MouseAdapter() { @Override public void mouseClicked(MouseEvent event) { if (event.getClickCount() == 2) openJobExpenseDialog(getSelectedJobExpense()); } });
    }
    private void updateJobExpenseButtonStates() { boolean selected = getSelectedJobExpense() != null; view.getEditJobExpenseButton().setEnabled(selected); view.getRemoveJobExpenseButton().setEnabled(selected); }
    private Expense getSelectedJobExpense() { int row=view.getJobExpenseTable().getSelectedRow(); return row<0?null:view.getJobExpenseTableModel().getExpenseAt(view.getJobExpenseTable().convertRowIndexToModel(row)); }
    private void openJobExpenseDialog(Expense expense) { if (expense == null && view.getJobExpenseTable().getSelectedRow() != -1) return; ExpenseFormDialog dialog=new ExpenseFormDialog(null,expense,existingJob.getId()); dialog.setVisible(true); refreshJobExpenseTotal(); }
    private void removeSelectedJobExpense() { Expense expense=getSelectedJobExpense(); if (expense==null || !view.confirm("Remove this job expense? This cannot be undone.", "Remove Job Expense")) return; new SwingWorker<ServiceResult<Void>,Void>() { @Override protected ServiceResult<Void> doInBackground(){return expenseService.removeExpense(expense.getId());} @Override protected void done(){try{ServiceResult<Void> result=get();if(result.isSuccess())refreshJobExpenseTotal();else view.showError(result.getMessage());}catch(Exception ex){view.showError("Unexpected error: "+ex.getMessage());}} }.execute(); }
    private void refreshJobExpenseTotal() { int jobId=existingJob.getId(); new SwingWorker<java.util.AbstractMap.SimpleEntry<List<Expense>,Double>,Void>() { @Override protected java.util.AbstractMap.SimpleEntry<List<Expense>,Double> doInBackground(){return new java.util.AbstractMap.SimpleEntry<>(expenseService.listForJob(jobId),expenseService.calculateJobExpenses(jobId));}@Override protected void done(){try{var data=get();view.setJobExpenses(data.getKey(),data.getValue());updateJobExpenseButtonStates();}catch(Exception ex){view.showError("Failed to load job expenses: "+ex.getMessage());}} }.execute(); }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
