package com.familyhvac.controllers;

import com.familyhvac.models.Client;
import com.familyhvac.services.ClientService;
import com.familyhvac.services.ServiceResult;
import com.familyhvac.views.ClientFormDialog;
import com.familyhvac.views.ClientPanel;
import com.familyhvac.views.ClientHistoryDialog;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Handles the client list screen's search/filter/table/button events. The
 * view knows nothing about ClientService or the database - it only calls
 * back into this controller, keeping the panel free of business logic.
 */
public class ClientListController {

    private static final int SEARCH_DEBOUNCE_MS = 250;

    private final ClientPanel view;
    private final ClientService clientService;
    private final Timer searchDebounceTimer;

    public ClientListController(ClientPanel view) {
        this.view = view;
        this.clientService = new ClientService();
        this.searchDebounceTimer = new Timer(SEARCH_DEBOUNCE_MS, e -> refresh());
        this.searchDebounceTimer.setRepeats(false);
        attachListeners();
        refresh();
    }

    private void attachListeners() {
        view.getAddButton().addActionListener(e -> openAddDialog());
        view.getEditButton().addActionListener(e -> openEditDialogForSelection());
        view.getRefreshButton().addActionListener(e -> refresh());
        view.getHistoryButton().addActionListener(e -> openHistoryForSelection());
        view.getArchiveButton().addActionListener(e -> handleArchiveOrRestoreSelection());

        view.getShowArchivedCheckBox().addActionListener(e -> refresh());

        view.getSearchField().getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }
        });

        view.getClientTable().getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updateSelectionDependentButtons();
            }
        });

        view.getClientTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2) {
                    openEditDialogForSelection();
                }
            }
        });
    }

    private void updateSelectionDependentButtons() {
        Client selected = getSelectedClient();
        view.getEditButton().setEnabled(selected != null);
        view.getHistoryButton().setEnabled(selected != null);

        if (selected == null) {
            view.getArchiveButton().setEnabled(false);
            view.getArchiveButton().setText("Archive");
        } else {
            view.getArchiveButton().setEnabled(true);
            view.getArchiveButton().setText(selected.isActive() ? "Archive" : "Restore");
        }
    }

    /**
     * Reloads the table using the current search text and "show archived"
     * state. This is the single entry point for every reason the list
     * might need to change: initial load, search-as-you-type, the
     * show-archived toggle, the Refresh button, and after Add/Edit/Archive/
     * Restore complete.
     */
    public void refresh() {
        String query = view.getSearchField().getText();
        boolean includeInactive = view.getShowArchivedCheckBox().isSelected();

        SwingWorker<List<Client>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Client> doInBackground() {
                return clientService.searchClients(query, includeInactive);
            }

            @Override
            protected void done() {
                try {
                    view.getTableModel().setClients(get());
                    updateSelectionDependentButtons();
                } catch (Exception ex) {
                    view.showError("Failed to load clients: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void openAddDialog() {
        ClientFormDialog dialog = new ClientFormDialog(resolveOwnerFrame(), null);
        dialog.setVisible(true);
        refresh(); // refresh after the dialog closes, whether saved or cancelled
    }

    private void openEditDialogForSelection() {
        Client selectedClient = getSelectedClient();
        if (selectedClient == null) {
            return;
        }
        ClientFormDialog dialog = new ClientFormDialog(resolveOwnerFrame(), selectedClient);
        dialog.setVisible(true);
        refresh();
    }

    private void openHistoryForSelection() {
        Client selected = getSelectedClient();
        if (selected != null) new ClientHistoryDialog(resolveOwnerFrame(), selected).setVisible(true);
    }

    private void handleArchiveOrRestoreSelection() {
        Client selected = getSelectedClient();
        if (selected == null) {
            return;
        }

        if (selected.isActive()) {
            boolean confirmed = view.confirm(
                    "Archive \"" + selected.getClientName() + "\"? " +
                            "This client will be hidden from the active list, but their job history is preserved " +
                            "and this can be undone later.",
                    "Archive Client");
            if (!confirmed) {
                return;
            }
            runArchiveAction(clientService::archiveClient, selected.getId());
        } else {
            runArchiveAction(clientService::restoreClient, selected.getId());
        }
    }

    private void runArchiveAction(java.util.function.IntFunction<ServiceResult<Void>> action, int clientId) {
        SwingWorker<ServiceResult<Void>, Void> worker = new SwingWorker<>() {
            @Override
            protected ServiceResult<Void> doInBackground() {
                return action.apply(clientId);
            }

            @Override
            protected void done() {
                try {
                    ServiceResult<Void> result = get();
                    if (result.isSuccess()) {
                        refresh();
                    } else {
                        view.showError(result.getMessage());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private Client getSelectedClient() {
        int selectedViewRow = view.getClientTable().getSelectedRow();
        if (selectedViewRow == -1) {
            return null;
        }
        int modelRow = view.getClientTable().convertRowIndexToModel(selectedViewRow);
        return view.getTableModel().getClientAt(modelRow);
    }

    private Frame resolveOwnerFrame() {
        Window owner = SwingUtilities.getWindowAncestor(view);
        return owner instanceof Frame ? (Frame) owner : null;
    }
}
