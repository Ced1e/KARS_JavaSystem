package com.familyhvac.controllers;

import com.familyhvac.models.Technician;
import com.familyhvac.services.ServiceResult;
import com.familyhvac.services.TechnicianService;
import com.familyhvac.services.TechnicianPayoutService;
import com.familyhvac.views.TechnicianFormDialog;
import com.familyhvac.views.TechnicianPanel;
import com.familyhvac.views.TechnicianProfileDialog;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Handles the technician list screen's search/filter/table/button events.
 * The view knows nothing about TechnicianService or the database - it
 * only calls back into this controller, keeping the panel free of
 * business logic.
 */
public class TechnicianListController {

    private static final int SEARCH_DEBOUNCE_MS = 250;

    private final TechnicianPanel view;
    private final TechnicianService technicianService;
    private final TechnicianPayoutService payoutService;
    private final Timer searchDebounceTimer;

    public TechnicianListController(TechnicianPanel view) {
        this.view = view;
        this.technicianService = new TechnicianService();
        this.payoutService = new TechnicianPayoutService();
        this.searchDebounceTimer = new Timer(SEARCH_DEBOUNCE_MS, e -> refresh());
        this.searchDebounceTimer.setRepeats(false);
        attachListeners();
        refresh();
    }

    private void attachListeners() {
        view.getAddButton().addActionListener(e -> openAddDialog());
        view.getEditButton().addActionListener(e -> openEditDialogForSelection());
        view.getProfileButton().addActionListener(e -> openProfile());
        view.getRefreshButton().addActionListener(e -> refresh());
        view.getArchiveButton().addActionListener(e -> handleArchiveOrRestoreSelection());

        view.getShowArchivedCheckBox().addActionListener(e -> refresh());

        view.getSearchField().getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }
        });

        view.getTechnicianTable().getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updateSelectionDependentButtons();
            }
        });

        view.getTechnicianTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2) {
                    openEditDialogForSelection();
                }
            }
        });
    }

    private void updateSelectionDependentButtons() {
        Technician selected = getSelectedTechnician();
        view.getEditButton().setEnabled(selected != null);
        view.getProfileButton().setEnabled(selected != null);

        if (selected == null) {
            view.getArchiveButton().setEnabled(false);
            view.getArchiveButton().setText("Archive");
        } else {
            view.getArchiveButton().setEnabled(true);
            view.getArchiveButton().setText(selected.isActive() ? "Archive" : "Restore");
        }
    }

    /**
     * Reloads the table using the current search text and "show archived"
     * state. Single entry point for every reason the list might need to
     * change: initial load, search-as-you-type, the show-archived toggle,
     * the Refresh button, and after Add/Edit/Archive/Restore complete.
     */
    public void refresh() {
        String query = view.getSearchField().getText();
        boolean includeInactive = view.getShowArchivedCheckBox().isSelected();

        SwingWorker<java.util.Map.Entry<List<Technician>, java.util.Map<Integer, Double>>, Void> worker = new SwingWorker<>() {
            @Override
            protected java.util.Map.Entry<List<Technician>, java.util.Map<Integer, Double>> doInBackground() {
                List<Technician> technicians = technicianService.searchTechnicians(query, includeInactive);
                java.util.List<Integer> ids = technicians.stream().map(Technician::getId).toList();
                return new java.util.AbstractMap.SimpleEntry<>(technicians, payoutService.calculateOutstandingByTechnician(ids));
            }

            @Override
            protected void done() {
                try {
                    var data = get();
                    view.getTableModel().setTechnicians(data.getKey(), data.getValue());
                    updateSelectionDependentButtons();
                } catch (Exception ex) {
                    view.showError("Failed to load technicians: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void openAddDialog() {
        TechnicianFormDialog dialog = new TechnicianFormDialog(resolveOwnerFrame(), null);
        dialog.setVisible(true);
        refresh(); // refresh after the dialog closes, whether saved or cancelled
    }

    private void openEditDialogForSelection() {
        Technician selectedTechnician = getSelectedTechnician();
        if (selectedTechnician == null) {
            return;
        }
        TechnicianFormDialog dialog = new TechnicianFormDialog(resolveOwnerFrame(), selectedTechnician);
        dialog.setVisible(true);
        refresh();
    }
    private void openProfile() { Technician technician=getSelectedTechnician(); if(technician!=null)new TechnicianProfileDialog(resolveOwnerFrame(), technician).setVisible(true); }

    private void handleArchiveOrRestoreSelection() {
        Technician selected = getSelectedTechnician();
        if (selected == null) {
            return;
        }

        if (selected.isActive()) {
            boolean confirmed = view.confirm(
                    "Archive \"" + selected.getName() + "\"? " +
                            "This technician will be hidden from the active list, but their job history is preserved " +
                            "and this can be undone later.",
                    "Archive Technician");
            if (!confirmed) {
                return;
            }
            runArchiveAction(technicianService::archiveTechnician, selected.getId());
        } else {
            runArchiveAction(technicianService::restoreTechnician, selected.getId());
        }
    }

    private void runArchiveAction(java.util.function.IntFunction<ServiceResult<Void>> action, int technicianId) {
        SwingWorker<ServiceResult<Void>, Void> worker = new SwingWorker<>() {
            @Override
            protected ServiceResult<Void> doInBackground() {
                return action.apply(technicianId);
            }

            @Override
            protected void done() {
                try {
                    ServiceResult<Void> result = get();
                    if (result.isSuccess()) {
                        refresh();
                    } else {
                        view.showError(result.getMessage());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private Technician getSelectedTechnician() {
        int selectedViewRow = view.getTechnicianTable().getSelectedRow();
        if (selectedViewRow == -1) {
            return null;
        }
        int modelRow = view.getTechnicianTable().convertRowIndexToModel(selectedViewRow);
        return view.getTableModel().getTechnicianAt(modelRow);
    }

    private Frame resolveOwnerFrame() {
        Window owner = SwingUtilities.getWindowAncestor(view);
        return owner instanceof Frame ? (Frame) owner : null;
    }
}
