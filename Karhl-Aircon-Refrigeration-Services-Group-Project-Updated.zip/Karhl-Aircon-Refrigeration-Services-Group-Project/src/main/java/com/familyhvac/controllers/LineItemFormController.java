package com.familyhvac.controllers;

import com.familyhvac.models.JobLineItem;
import com.familyhvac.services.JobLineItemService;
import com.familyhvac.services.ServiceResult;
import com.familyhvac.views.LineItemFormDialog;

import javax.swing.*;

/**
 * Handles saving from {@link LineItemFormDialog}. Works in both Add mode
 * (existingLineItem == null, a new JobLineItem is built from the form)
 * and Edit mode (existingLineItem is mutated in place and re-saved).
 *
 * Quantity and unit price are parsed here (from free-text fields) with
 * immediate, specific validation before ever reaching
 * {@link JobLineItemService}, which re-validates the parsed values as the
 * authoritative check.
 */
public class LineItemFormController {

    private final LineItemFormDialog view;
    private final JobLineItemService jobLineItemService;
    private final int jobId;
    private final JobLineItem existingLineItem;

    public LineItemFormController(LineItemFormDialog view, int jobId, JobLineItem existingLineItem) {
        this.view = view;
        this.jobLineItemService = new JobLineItemService();
        this.jobId = jobId;
        this.existingLineItem = existingLineItem;
        attachListeners();
    }

    private void attachListeners() {
        view.getSaveButton().addActionListener(e -> handleSave());
    }

    private void handleSave() {
        String description = view.getDescriptionInput() == null ? "" : view.getDescriptionInput().trim();
        if (description.isEmpty()) {
            view.markFieldInvalid(view.getDescriptionField());
            view.showError("Description is required.");
            return;
        }

        Double quantity = parsePositiveDouble(view.getQuantityInput());
        if (quantity == null) {
            view.markFieldInvalid(view.getQuantityField());
            view.showError("Quantity must be a number greater than zero.");
            return;
        }

        Double unitPrice = parseNonNegativeDouble(view.getUnitPriceInput());
        if (unitPrice == null) {
            view.markFieldInvalid(view.getUnitPriceField());
            view.showError("Unit price must be a number, zero or greater.");
            return;
        }

        JobLineItem lineItem = existingLineItem != null ? existingLineItem : new JobLineItem();
        lineItem.setJobId(jobId);
        lineItem.setDescription(description);
        lineItem.setQuantity(quantity);
        lineItem.setUnitPrice(unitPrice);

        view.getSaveButton().setEnabled(false);

        SwingWorker<ServiceResult<JobLineItem>, Void> worker = new SwingWorker<>() {
            @Override
            protected ServiceResult<JobLineItem> doInBackground() {
                return existingLineItem != null
                        ? jobLineItemService.updateLineItem(lineItem)
                        : jobLineItemService.addLineItem(lineItem);
            }

            @Override
            protected void done() {
                view.getSaveButton().setEnabled(true);
                try {
                    ServiceResult<JobLineItem> result = get();
                    if (result.isSuccess()) {
                        view.closeDialog();
                    } else {
                        view.showError(result.getMessage());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    /** Parses a strictly-positive (greater than zero) number, or null if invalid. */
    private Double parsePositiveDouble(String text) {
        try {
            double value = Double.parseDouble(text == null ? "" : text.trim());
            return value > 0 ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Parses a number that is zero or greater, or null if invalid. */
    private Double parseNonNegativeDouble(String text) {
        try {
            double value = Double.parseDouble(text == null ? "" : text.trim());
            return value >= 0 ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
