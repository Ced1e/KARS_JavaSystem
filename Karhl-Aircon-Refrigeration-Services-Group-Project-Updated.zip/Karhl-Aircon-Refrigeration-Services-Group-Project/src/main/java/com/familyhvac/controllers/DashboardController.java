package com.familyhvac.controllers;

import com.familyhvac.dao.AnalyticsDAO;
import com.familyhvac.services.AnalyticsService;
import com.familyhvac.views.DashboardPanel;
import javax.swing.*;
import java.util.List;

/** Coordinates dashboard aggregates without putting business calculations in the view. */
public class DashboardController {
    private final DashboardPanel view;
    private final AnalyticsService service = new AnalyticsService();

    public DashboardController(DashboardPanel view) {
        this.view = view;
        view.getRefreshButton().addActionListener(e -> refresh());
        view.getActivityRangeSelector().addActionListener(e -> refreshTrend());
        refresh();
    }

    private void refresh() {
        new SwingWorker<AnalyticsDAO.DashboardData, Void>() {
            @Override protected AnalyticsDAO.DashboardData doInBackground() { return service.dashboard(); }
            @Override protected void done() {
                try {
                    AnalyticsDAO.DashboardData data = get();
                    view.setMetrics(data.totalBusinessEarnings, data.totalReceivable, data.cleanReceivable,
                            data.unpaidJobs, data.pendingPayouts, data.pendingPayoutAmount, data.upcomingJobs);
                    refreshTrend();
                } catch (Exception error) { view.showError("Failed to load dashboard: " + error.getMessage()); }
            }
        }.execute();
    }

    /** Refreshes only the two trend charts when their grouping is changed. */
    private void refreshTrend() {
        final AnalyticsDAO.ActivityRange range = view.getActivityRange();
        new SwingWorker<List<AnalyticsDAO.ActivityPoint>, Void>() {
            @Override protected List<AnalyticsDAO.ActivityPoint> doInBackground() { return service.activityTrend(range); }
            @Override protected void done() {
                try { view.setActivityTrend(get()); }
                catch (Exception error) { view.showError("Failed to load dashboard charts: " + error.getMessage()); }
            }
        }.execute();
    }

}
