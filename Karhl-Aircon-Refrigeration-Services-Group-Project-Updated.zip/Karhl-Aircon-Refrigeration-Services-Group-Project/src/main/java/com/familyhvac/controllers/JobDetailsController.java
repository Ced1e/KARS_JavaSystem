package com.familyhvac.controllers;

import com.familyhvac.services.JobDetailsService;

import javax.swing.*;

/** Loads the derived read-only job workspace without exposing payment tracking. */
public class JobDetailsController {
    public JobDetailsController(com.familyhvac.views.JobDetailsDialog view, int jobId) {
        new SwingWorker<JobDetailsService.Details, Void>() {
            @Override protected JobDetailsService.Details doInBackground() { return new JobDetailsService().load(jobId); }
            @Override protected void done() {
                try {
                    JobDetailsService.Details details = get();
                    double tax = details.total * (details.job.getTaxReductionPercent() / 100.0);
                    view.setTabText("Overview", overview(details, tax));
                    view.setTabText("Pricing Summary", pricing(details, tax));
                    view.setTabText("Technicians", details.payouts.stream()
                            .map(payout -> payout.getTechnicianName() + " - approved: " +
                                    (payout.getApprovedAmount() == null ? "not negotiated" : money(payout.getApprovedAmount())))
                            .reduce("Assignments", (left, right) -> left + "\n" + right));
                    view.setTabText("Cash Advances", details.advances.stream()
                            .map(item -> item.getTransactionDate() + "  " + item.getTechnicianName() + "  " + item.getTransactionType() + "  " + money(item.getAmount()))
                            .reduce("Ledger", (left, right) -> left + "\n" + right));
                    view.setTabText("Expenses", "Job Expenses: " + money(details.jobExpenses) + "\n\n" + details.expenses.stream()
                            .map(item -> item.getExpenseDate() + "  " + item.getCategoryName() + "  " + money(item.getAmount()))
                            .reduce("Entries", (left, right) -> left + "\n" + right));
                    view.setTabText("Activity", String.join("\n", details.activity));
                } catch (Exception error) { view.showError("Failed to load job details: " + error.getMessage()); }
            }
        }.execute();
    }

    private static String overview(JobDetailsService.Details details, double tax) {
        return "Status: " + details.job.getJobStatus() + "\nDate: " + details.job.getJobDate() +
                "\nPO Number: " + dash(details.job.getPoNumber()) + "\nLocation: " + dash(details.job.getLocation()) + "\nDescription: " + dash(details.job.getDescription()) +
                "\n\nGross job total: " + money(details.total) +
                "\nTax reduction (" + String.format("%.2f", details.job.getTaxReductionPercent()) + "%): " + money(tax) +
                "\nNet job total: " + money(details.total - tax) +
                "\nJob Expenses: " + money(details.jobExpenses);
    }

    private static String pricing(JobDetailsService.Details details, double tax) {
        String lines = details.lineItems.stream()
                .map(item -> item.getDescription() + "  x" + item.getQuantity() + "  @ " + money(item.getUnitPrice()))
                .reduce("Line Items", (left, right) -> left + "\n" + right);
        return lines + "\n\nGross job total: " + money(details.total) +
                "\nTax reduction: " + money(tax) +
                "\nNet job total: " + money(details.total - tax);
    }

    private static String dash(String value) { return value == null || value.isBlank() ? "-" : value; }
    private static String money(double amount) { return String.format("PHP %,.2f", amount); }
}
