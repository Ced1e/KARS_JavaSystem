package com.familyhvac.controllers;

import com.familyhvac.database.DatabaseManager;
import com.familyhvac.views.SettingsPanel;
import javax.swing.*;
import java.nio.file.*;
import java.sql.DriverManager;
import java.time.*;
import java.time.format.DateTimeFormatter;

/** Runs backup and guarded restore operations outside Swing's event thread. */
public class SettingsController {
    private final SettingsPanel view;
    public SettingsController(SettingsPanel v){view=v;view.getBackupButton().addActionListener(e->backup());view.getRestoreButton().addActionListener(e->restore());view.getThemeMode().addActionListener(e->saveTheme());}
    private void saveTheme(){com.familyhvac.utils.UITheme.ThemeMode mode=(com.familyhvac.utils.UITheme.ThemeMode)view.getThemeMode().getSelectedItem();if(mode==null)return;com.familyhvac.utils.UITheme.setThemeMode(mode);view.setThemeStatus("Saved " + mode + " mode. Restart the app to apply it.");}
    private Path backupPath(){Path source=Path.of(DatabaseManager.getInstance().getDatabaseFilePath());return source.getParent().resolve("backups").resolve("karhl_aircon_backup_"+LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))+".db");}
    private void backup(){view.getBackupButton().setEnabled(false);new SwingWorker<Path,Void>(){protected Path doInBackground() throws Exception {Path source=Path.of(DatabaseManager.getInstance().getDatabaseFilePath());Path target=backupPath();Files.createDirectories(target.getParent());return Files.copy(source,target,StandardCopyOption.COPY_ATTRIBUTES);}protected void done(){view.getBackupButton().setEnabled(true);try{view.setBackupStatus("Backup created: "+get(),false);}catch(Exception e){view.setBackupStatus("Backup failed: "+e.getMessage(),true);}}}.execute();}
    private void restore(){JFileChooser chooser=new JFileChooser(Path.of(DatabaseManager.getInstance().getDatabaseFilePath()).getParent().resolve("backups").toFile());chooser.setDialogTitle("Choose a database backup to restore");if(chooser.showOpenDialog(view)!=JFileChooser.APPROVE_OPTION)return;Path selected=chooser.getSelectedFile().toPath();if(!selected.getFileName().toString().toLowerCase().endsWith(".db")){view.showError("Please select a .db backup file.");return;}if(!view.confirmRestore("Restore the selected backup?\n\nYour current data will first be saved as a safety backup. The application will need to restart after the restore."))return;view.getRestoreButton().setEnabled(false);view.getBackupButton().setEnabled(false);new SwingWorker<Path,Void>(){protected Path doInBackground() throws Exception {try(var ignored=DriverManager.getConnection("jdbc:sqlite:"+selected.toAbsolutePath())){}Path active=Path.of(DatabaseManager.getInstance().getDatabaseFilePath());Path safety=backupPath();Files.createDirectories(safety.getParent());Files.copy(active,safety,StandardCopyOption.COPY_ATTRIBUTES);Files.copy(selected,active,StandardCopyOption.REPLACE_EXISTING);return safety;}protected void done(){view.getRestoreButton().setEnabled(true);view.getBackupButton().setEnabled(true);try{Path safety=get();view.setBackupStatus("Restore complete. Safety backup: "+safety+". Close and reopen the app.",false);}catch(Exception e){view.setBackupStatus("Restore failed; current data was not replaced: "+e.getMessage(),true);}}}.execute();}
}
