package com.familyhvac.controllers;

import com.familyhvac.models.Client;
import com.familyhvac.services.ClientService;
import com.familyhvac.services.ServiceResult;
import com.familyhvac.views.ClientFormDialog;

import javax.swing.*;
import java.util.List;

/**
 * Handles saving from {@link ClientFormDialog}. Works in both Add mode
 * (existingClient == null, a new Client is built from the form) and Edit
 * mode (existingClient is mutated in place and re-saved).
 *
 * Save flow:
 *   1. Immediate client-side check that a name was entered at all (fast
 *      feedback, no database round-trip for the most common mistake).
 *   2. Background check for similarly-named clients. If any are found,
 *      show a non-blocking warning and let the user choose to continue
 *      or go back and edit - never a hard block, per the design.
 *   3. Actual create/update, via ClientService (which re-validates
 *      everything - the client-side check above is just a UX shortcut,
 *      not the source of truth).
 */
public class ClientFormController {

    private final ClientFormDialog view;
    private final ClientService clientService;
    private final Client existingClient;

    public ClientFormController(ClientFormDialog view, Client existingClient) {
        this.view = view;
        this.clientService = new ClientService();
        this.existingClient = existingClient;
        attachListeners();
    }

    private void attachListeners() {
        view.getSaveButton().addActionListener(e -> handleSave());
    }

    private void handleSave() {
        String clientName = trimToNull(view.getClientNameInput());

        if (clientName == null) {
            view.markFieldInvalid(view.getClientNameField());
            view.showError("Client name is required.");
            return;
        }

        view.getSaveButton().setEnabled(false);

        Integer excludeId = existingClient != null ? existingClient.getId() : null;

        SwingWorker<List<Client>, Void> duplicateCheckWorker = new SwingWorker<>() {
            @Override
            protected List<Client> doInBackground() {
                return clientService.findSimilarClients(clientName, excludeId);
            }

            @Override
            protected void done() {
                try {
                    List<Client> similarClients = get();
                    if (similarClients.isEmpty() || view.confirmDespiteSimilarClients(similarClients)) {
                        performSave();
                    } else {
                        view.getSaveButton().setEnabled(true);
                    }
                } catch (Exception ex) {
                    // Duplicate checking is a courtesy, not a requirement - if it fails,
                    // don't block the user from saving. Just proceed to the real save.
                    performSave();
                }
            }
        };
        duplicateCheckWorker.execute();
    }

    private void performSave() {
        Client client = existingClient != null ? existingClient : new Client();

        client.setClientName(trimToNull(view.getClientNameInput()));
        client.setContactPerson(trimToNull(view.getContactPersonInput()));
        client.setPhoneNumber(trimToNull(view.getPhoneInput()));
        client.setEmail(trimToNull(view.getEmailInput()));
        client.setTin(trimToNull(view.getTinInput()));
        client.setAddress(trimToNull(view.getAddressInput()));
        client.setPreferredPaymentMethod(view.getPreferredPaymentMethodInput());
        client.setNotes(trimToNull(view.getNotesInput()));

        view.getSaveButton().setEnabled(false);

        SwingWorker<ServiceResult<Client>, Void> saveWorker = new SwingWorker<>() {
            @Override
            protected ServiceResult<Client> doInBackground() {
                return existingClient != null
                        ? clientService.updateClient(client)
                        : clientService.createClient(client);
            }

            @Override
            protected void done() {
                view.getSaveButton().setEnabled(true);
                try {
                    ServiceResult<Client> result = get();
                    if (result.isSuccess()) {
                        view.closeDialog();
                    } else {
                        view.showError(result.getMessage());
                        highlightFieldForError(result.getMessage());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        saveWorker.execute();
    }

    /**
     * Maps a validation failure message from the service back to the field
     * it concerns, so the field gets a red border instead of leaving the
     * user to guess which one needs fixing. The service message stays the
     * single source of truth for the actual rule - this only decides where
     * to point.
     */
    private void highlightFieldForError(String message) {
        view.clearFieldValidation(view.getClientNameField());
        view.clearFieldValidation(view.getEmailField());

        if (message == null) {
            return;
        }
        String lowerMessage = message.toLowerCase();
        if (lowerMessage.contains("name")) {
            view.markFieldInvalid(view.getClientNameField());
        } else if (lowerMessage.contains("email")) {
            view.markFieldInvalid(view.getEmailField());
        }
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
