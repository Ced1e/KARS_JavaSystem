package com.familyhvac.controllers;

import com.familyhvac.models.Client;
import com.familyhvac.models.Job;
import com.familyhvac.models.ServiceCategory;
import com.familyhvac.services.ClientService;
import com.familyhvac.services.JobService;
import com.familyhvac.services.ExpenseService;
import com.familyhvac.services.TechnicianPayoutService;
import com.familyhvac.services.ServiceCategoryService;
import com.familyhvac.views.JobFormDialog;
import com.familyhvac.views.JobPanel;
import com.familyhvac.views.JobDetailsDialog;
import com.familyhvac.views.DatePickerField;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Handles the job list screen's search/filter/table/button events. The
 * view knows nothing about JobService or the database - it only calls
 * back into this controller, keeping the panel free of business logic.
 */
public class JobListController {

    private static final int SEARCH_DEBOUNCE_MS = 250;

    private final JobPanel view;
    private final JobService jobService;
    private final ClientService clientService;
    private final ServiceCategoryService serviceCategoryService;
    private final ExpenseService expenseService;
    private final TechnicianPayoutService payoutService;
    private final Timer searchDebounceTimer;

    public JobListController(JobPanel view) {
        this.view = view;
        this.jobService = new JobService();
        this.clientService = new ClientService();
        this.serviceCategoryService = new ServiceCategoryService();
        this.expenseService = new ExpenseService();
        this.payoutService = new TechnicianPayoutService();
        this.searchDebounceTimer = new Timer(SEARCH_DEBOUNCE_MS, e -> refresh());
        this.searchDebounceTimer.setRepeats(false);
        attachListeners();
        refresh();
    }

    private void attachListeners() {
        view.getAddButton().addActionListener(e -> openAddDialog());
        view.getEditButton().addActionListener(e -> openEditDialogForSelection());
        view.getDetailsButton().addActionListener(e -> openDetailsForSelection());
        view.getDeleteButton().addActionListener(e -> deleteSelectedJob());
        view.getChangeStatusButton().addActionListener(e -> updateSelectedStatus());
        view.getRefreshButton().addActionListener(e -> refresh());

        view.getStatusFilterCombo().addActionListener(e -> refresh());
        view.getCategoryFilterCombo().addActionListener(e -> refresh());
        view.getDateRangeFilterCombo().addActionListener(e -> refresh());
        view.getDateFilterField().getTextField().getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { searchDebounceTimer.restart(); }
            @Override public void removeUpdate(DocumentEvent e) { searchDebounceTimer.restart(); }
            @Override public void changedUpdate(DocumentEvent e) { searchDebounceTimer.restart(); }
        });

        view.getSearchField().getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                searchDebounceTimer.restart();
            }
        });

        view.getJobTable().getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                view.getEditButton().setEnabled(view.getJobTable().getSelectedRow() != -1);
                view.getDetailsButton().setEnabled(view.getJobTable().getSelectedRow() != -1);
                boolean selected = view.getJobTable().getSelectedRow() != -1;
                view.getDeleteButton().setEnabled(selected);
                view.getChangeStatusCombo().setEnabled(selected);
                view.getChangeStatusButton().setEnabled(selected);
                if (selected) view.getChangeStatusCombo().setSelectedItem(view.getTableModel().getJobAt(view.getJobTable().convertRowIndexToModel(view.getJobTable().getSelectedRow())).getJobStatus());
            }
        });

        view.getJobTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2) {
                    openEditDialogForSelection();
                }
            }
        });
        loadCategoryFilters();
    }

    private void loadCategoryFilters() {
        new SwingWorker<List<ServiceCategory>, Void>() {
            @Override protected List<ServiceCategory> doInBackground() { return serviceCategoryService.listAllCategories(); }
            @Override protected void done() { try { view.setCategoryFilters(get()); } catch (Exception ignored) { } }
        }.execute();
    }

    /** Result bundle for the background fetch - jobs plus the name-lookup maps the table needs. */
    private static final class JobListData {
        final List<Job> jobs;
        final Map<Integer, String> clientNamesById;
        final Map<Integer, String> categoryNamesById;
        final Map<Integer, Double> expensesByJob;
        final Map<Integer, Double> payoutsByJob;

        JobListData(List<Job> jobs, Map<Integer, String> clientNamesById, Map<Integer, String> categoryNamesById,
                    Map<Integer, Double> expensesByJob, Map<Integer, Double> payoutsByJob) {
            this.jobs = jobs;
            this.clientNamesById = clientNamesById;
            this.categoryNamesById = categoryNamesById;
            this.expensesByJob = expensesByJob;
            this.payoutsByJob = payoutsByJob;
        }
    }

    /**
     * Reloads the table using the current search text and status filter.
     * Single entry point for every reason the list might need to change:
     * initial load, search-as-you-type, the status filter, the Refresh
     * button, and after Add/Edit complete. Runs off the EDT so the UI
     * never freezes.
     */
    public void refresh() {
        String query = view.getSearchField().getText();
        Job.JobStatus statusFilter = view.getSelectedStatusFilter();
        Integer categoryId = view.getSelectedCategoryId();
        LocalDate reference = view.getFilterReferenceDate();
        LocalDate from = null, to = null;
        switch (view.getSelectedDateRange()) {
            case "Selected Date" -> { from = reference; to = reference; }
            case "Week" -> { from = reference.minusDays(reference.getDayOfWeek().getValue() - 1L); to = from.plusDays(6); }
            case "Month" -> { from = reference.withDayOfMonth(1); to = reference.withDayOfMonth(reference.lengthOfMonth()); }
            case "Year" -> { from = reference.withDayOfYear(1); to = reference.withMonth(12).withDayOfMonth(31); }
        }
        final LocalDate dateFrom = from, dateTo = to;

        SwingWorker<JobListData, Void> worker = new SwingWorker<>() {
            @Override
            protected JobListData doInBackground() {
                List<Job> jobs = jobService.searchJobs(query, statusFilter, categoryId, dateFrom, dateTo);

                Map<Integer, String> clientNames = new HashMap<>();
                for (Client client : clientService.listAllClients()) {
                    clientNames.put(client.getId(), client.getClientName());
                }

                Map<Integer, String> categoryNames = new HashMap<>();
                for (ServiceCategory category : serviceCategoryService.listAllCategories()) {
                    categoryNames.put(category.getId(), category.getName());
                }

                List<Integer> jobIds = jobs.stream().map(Job::getId).toList();
                return new JobListData(jobs, clientNames, categoryNames,
                        expenseService.calculateJobExpenseTotals(jobIds),
                        payoutService.releasedPayoutTotalsByJob(jobIds));
            }

            @Override
            protected void done() {
                try {
                    JobListData data = get();
                    view.getTableModel().setJobs(data.jobs, data.clientNamesById, data.categoryNamesById,
                            data.expensesByJob, data.payoutsByJob);
                    view.showEmptyState(data.jobs.isEmpty());
                    view.getJobTable().clearSelection();
                    view.getEditButton().setEnabled(false);
                    view.getDetailsButton().setEnabled(false);
                    view.getDeleteButton().setEnabled(false);
                    view.getChangeStatusCombo().setEnabled(false);
                    view.getChangeStatusButton().setEnabled(false);
                } catch (Exception ex) {
                    view.showError("Failed to load jobs: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void openAddDialog() {
        JobFormDialog dialog = new JobFormDialog(resolveOwnerFrame(), null);
        dialog.setVisible(true);
        refresh(); // refresh after the dialog closes, whether saved or cancelled
    }

    private void openEditDialogForSelection() {
        int selectedViewRow = view.getJobTable().getSelectedRow();
        if (selectedViewRow == -1) {
            return;
        }
        int modelRow = view.getJobTable().convertRowIndexToModel(selectedViewRow);
        Job selectedJob = view.getTableModel().getJobAt(modelRow);

        JobFormDialog dialog = new JobFormDialog(resolveOwnerFrame(), selectedJob);
        dialog.setVisible(true);
        refresh();
    }

    private void openDetailsForSelection() {
        int row = view.getJobTable().getSelectedRow(); if (row == -1) return;
        Job job = view.getTableModel().getJobAt(view.getJobTable().convertRowIndexToModel(row));
        new JobDetailsDialog(resolveOwnerFrame(), job).setVisible(true);
    }

    private void deleteSelectedJob() {
        int row = view.getJobTable().getSelectedRow();
        if (row == -1) return;
        Job job = view.getTableModel().getJobAt(view.getJobTable().convertRowIndexToModel(row));
        String warning = "Permanently delete " + job.getJobCode() + "?\n\n" +
                "This also removes its expenses, technician payouts and disbursements, " +
                "payments, cash advances, and line items. This cannot be undone.";
        if (!view.confirm(warning, "Delete Job")) return;
        view.getDeleteButton().setEnabled(false);
        new SwingWorker<com.familyhvac.services.ServiceResult<Void>, Void>() {
            @Override protected com.familyhvac.services.ServiceResult<Void> doInBackground() { return jobService.deleteJob(job.getId()); }
            @Override protected void done() {
                try {
                    var result = get();
                    if (result.isSuccess()) refresh(); else { view.showError(result.getMessage()); view.getDeleteButton().setEnabled(true); }
                } catch (Exception error) { view.showError("Unable to delete job: " + error.getMessage()); view.getDeleteButton().setEnabled(true); }
            }
        }.execute();
    }
    private void updateSelectedStatus() {
        int row=view.getJobTable().getSelectedRow(); if(row==-1)return;
        Job job=view.getTableModel().getJobAt(view.getJobTable().convertRowIndexToModel(row));
        Job.JobStatus status=(Job.JobStatus)view.getChangeStatusCombo().getSelectedItem();
        if(status==job.getJobStatus()) return;
        java.time.LocalDate actualCompletionDate = null;
        if (status == Job.JobStatus.COMPLETED) {
            DatePickerField picker = new DatePickerField(true);
            JPanel content = new JPanel(new BorderLayout(0, 8));
            content.add(new JLabel("Actual completion date:"), BorderLayout.NORTH);
            content.add(picker, BorderLayout.CENTER);
            if (JOptionPane.showConfirmDialog(view, content, "Complete Job", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) != JOptionPane.OK_OPTION) return;
            try { actualCompletionDate = picker.getDate(); }
            catch (Exception error) { view.showError("Actual completion date must be in DD-MM-YYYY format."); return; }
            if (actualCompletionDate == null) { view.showError("An actual completion date is required."); return; }
        }
        final java.time.LocalDate completionDate = actualCompletionDate;
        new SwingWorker<com.familyhvac.services.ServiceResult<Job>,Void>(){
            @Override protected com.familyhvac.services.ServiceResult<Job> doInBackground(){return jobService.updateJobStatus(job.getId(),status,completionDate);}
            @Override protected void done(){try{var result=get();if(result.isSuccess())refresh();else view.showError(result.getMessage());}catch(Exception e){view.showError("Unable to update job status: "+e.getMessage());}}
        }.execute();
    }

    private Frame resolveOwnerFrame() {
        Window owner = SwingUtilities.getWindowAncestor(view);
        return owner instanceof Frame ? (Frame) owner : null;
    }
}
