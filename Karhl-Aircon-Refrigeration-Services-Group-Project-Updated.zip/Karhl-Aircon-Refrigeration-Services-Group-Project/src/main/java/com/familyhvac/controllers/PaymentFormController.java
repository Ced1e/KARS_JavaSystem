package com.familyhvac.controllers;

import com.familyhvac.models.Payment;
import com.familyhvac.services.JobLineItemService;
import com.familyhvac.services.JobService;
import com.familyhvac.services.PaymentService;
import com.familyhvac.services.ServiceResult;
import com.familyhvac.views.PaymentFormDialog;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import java.time.LocalDate;

/**
 * Handles saving from {@link PaymentFormDialog}. Works in both Add mode
 * (existingPayment == null, a new Payment is built from the form) and
 * Edit mode (existingPayment is mutated in place and re-saved).
 *
 * Date format and amount are parsed here (from free-text fields) with
 * immediate, specific validation before ever reaching
 * {@link PaymentService}, which re-validates as the authoritative check.
 *
 * Save flow: after date/amount pass validation, a background check
 * compares the amount against the job's remaining balance (Job Total
 * minus payments already recorded, excluding this payment's own prior
 * amount when editing). If it would exceed the balance, a non-blocking
 * warning lets the user confirm or go back and adjust - this mirrors the
 * duplicate-name warning pattern used for Clients/Technicians rather than
 * a hard reject, consistent with the project's OVERPAID payment status
 * being an allowed, visible state rather than a forbidden one.
 */
public class PaymentFormController {

    private final PaymentFormDialog view;
    private final PaymentService paymentService;
    private final JobLineItemService jobLineItemService;
    private final JobService jobService;
    private final int jobId;
    private final Payment existingPayment;

    public PaymentFormController(PaymentFormDialog view, int jobId, Payment existingPayment) {
        this.view = view;
        this.paymentService = new PaymentService();
        this.jobLineItemService = new JobLineItemService();
        this.jobService = new JobService();
        this.jobId = jobId;
        this.existingPayment = existingPayment;
        attachListeners();
    }

    private void attachListeners() {
        view.getSaveButton().addActionListener(e -> handleSave());
    }

    private void handleSave() {
        LocalDate paymentDate;
        try { paymentDate = view.getPaymentDate(); }
        catch (Exception error) { view.markFieldInvalid(view.getPaymentDateField()); view.showError("Payment date must be in DD-MM-YYYY format."); return; }
        if (paymentDate == null) {
            view.markFieldInvalid(view.getPaymentDateField());
            view.showError("Payment date is required.");
            return;
        }

        Double amount = parsePositiveDouble(view.getAmountInput());
        if (amount == null) {
            view.markFieldInvalid(view.getAmountField());
            view.showError("Amount must be a number greater than zero.");
            return;
        }

        Payment payment = existingPayment != null ? existingPayment : new Payment();
        payment.setJobId(jobId);
        payment.setPaymentDate(DateSupport.toStorage(paymentDate));
        payment.setAmount(amount);
        payment.setPaymentType(view.getSelectedPaymentType());
        payment.setReferenceNumber(trimToNull(view.getReferenceNumberInput()));
        payment.setRemarks(trimToNull(view.getRemarksInput()));

        view.getSaveButton().setEnabled(false);

        SwingWorker<Double, Void> balanceCheckWorker = new SwingWorker<>() {
            @Override
            protected Double doInBackground() {
                double grossTotal = jobLineItemService.calculateJobTotal(jobId);
                double jobTotal = jobService.getJobById(jobId)
                        .map(j -> PaymentService.calculateExpectedNetAmount(grossTotal, j.getTaxReductionPercent()))
                        .orElse(grossTotal);
                double totalPaid = paymentService.calculateTotalPaid(jobId);
                // Exclude this payment's own prior amount when editing, so editing
                // a payment doesn't count its old amount against its new amount.
                double totalPaidExcludingThis = existingPayment != null
                        ? totalPaid - existingPayment.getAmount()
                        : totalPaid;
                return jobTotal - totalPaidExcludingThis;
            }

            @Override
            protected void done() {
                try {
                    double remainingBalance = get();
                    if (amount > remainingBalance) {
                        boolean proceed = view.confirm(
                                String.format("This payment of \u20B1%,.2f exceeds the remaining balance of \u20B1%,.2f by \u20B1%,.2f.\n\n" +
                                        "Do you want to record it anyway?",
                                        amount, remainingBalance, amount - remainingBalance),
                                "Payment Exceeds Balance");
                        if (!proceed) {
                            view.getSaveButton().setEnabled(true);
                            return;
                        }
                    }
                } catch (Exception ex) {
                    // Balance checking is a courtesy, not a requirement - if it fails,
                    // don't block the user from saving. Just proceed to the real save.
                }
                performSave(payment);
            }
        };
        balanceCheckWorker.execute();
    }

    private void performSave(Payment payment) {
        SwingWorker<ServiceResult<Payment>, Void> worker = new SwingWorker<>() {
            @Override
            protected ServiceResult<Payment> doInBackground() {
                return existingPayment != null
                        ? paymentService.updatePayment(payment)
                        : paymentService.addPayment(payment);
            }

            @Override
            protected void done() {
                view.getSaveButton().setEnabled(true);
                try {
                    ServiceResult<Payment> result = get();
                    if (result.isSuccess()) {
                        view.closeDialog();
                    } else {
                        view.showError(result.getMessage());
                        highlightFieldForError(result.getMessage());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    /**
     * Maps a validation failure message from PaymentService back to the
     * field it concerns, so the field gets a red border instead of
     * leaving the user to guess which one needs fixing. In normal use the
     * client-side checks above already catch blank/malformed dates and
     * non-positive amounts before this is ever reached, so this exists as
     * a defensive fallback matching the pattern already used in
     * JobFormController - if a service-layer rule ever rejects a payment
     * for a reason the client-side check didn't anticipate, the UI still
     * points at the right field instead of just showing a message with no
     * visual cue.
     */
    private void highlightFieldForError(String message) {
        view.clearFieldValidation(view.getPaymentDateField());
        view.clearFieldValidation(view.getAmountField());

        if (message == null) {
            return;
        }
        String lowerMessage = message.toLowerCase();
        if (lowerMessage.contains("date")) {
            view.markFieldInvalid(view.getPaymentDateField());
        } else if (lowerMessage.contains("amount")) {
            view.markFieldInvalid(view.getAmountField());
        }
    }

    /** Parses a strictly-positive (greater than zero) number, or null if invalid. */
    private Double parsePositiveDouble(String text) {
        try {
            double value = Double.parseDouble(text == null ? "" : text.trim());
            return value > 0 ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
