package com.familyhvac.controllers;

import com.familyhvac.models.Technician;
import com.familyhvac.services.ServiceResult;
import com.familyhvac.services.TechnicianService;
import com.familyhvac.views.TechnicianFormDialog;

import javax.swing.*;
import java.util.List;

/**
 * Handles saving from {@link TechnicianFormDialog}. Works in both Add
 * mode (existingTechnician == null, a new Technician is built from the
 * form) and Edit mode (existingTechnician is mutated in place and
 * re-saved).
 *
 * Save flow (mirrors ClientFormController):
 *   1. Immediate client-side check that a name was entered at all.
 *   2. Background check for similarly-named technicians. If any are
 *      found, show a non-blocking warning and let the user choose to
 *      continue or go back and edit - never a hard block.
 *   3. Actual create/update, via TechnicianService (which re-validates
 *      everything - the client-side check above is just a UX shortcut).
 */
public class TechnicianFormController {

    private final TechnicianFormDialog view;
    private final TechnicianService technicianService;
    private final Technician existingTechnician;

    public TechnicianFormController(TechnicianFormDialog view, Technician existingTechnician) {
        this.view = view;
        this.technicianService = new TechnicianService();
        this.existingTechnician = existingTechnician;
        attachListeners();
    }

    private void attachListeners() {
        view.getSaveButton().addActionListener(e -> handleSave());
    }

    private void handleSave() {
        String name = trimToNull(view.getNameInput());

        if (name == null) {
            view.markFieldInvalid(view.getNameField());
            view.showError("Technician name is required.");
            return;
        }

        view.getSaveButton().setEnabled(false);

        Integer excludeId = existingTechnician != null ? existingTechnician.getId() : null;

        SwingWorker<List<Technician>, Void> duplicateCheckWorker = new SwingWorker<>() {
            @Override
            protected List<Technician> doInBackground() {
                return technicianService.findSimilarTechnicians(name, excludeId);
            }

            @Override
            protected void done() {
                try {
                    List<Technician> similarTechnicians = get();
                    if (similarTechnicians.isEmpty() || view.confirmDespiteSimilarTechnicians(similarTechnicians)) {
                        performSave();
                    } else {
                        view.getSaveButton().setEnabled(true);
                    }
                } catch (Exception ex) {
                    // Duplicate checking is a courtesy, not a requirement - if it fails,
                    // don't block the user from saving. Just proceed to the real save.
                    performSave();
                }
            }
        };
        duplicateCheckWorker.execute();
    }

    private void performSave() {
        Technician technician = existingTechnician != null ? existingTechnician : new Technician();

        technician.setName(trimToNull(view.getNameInput()));
        technician.setPhoneNumber(trimToNull(view.getPhoneInput()));
        technician.setNotes(trimToNull(view.getNotesInput()));

        view.getSaveButton().setEnabled(false);

        SwingWorker<ServiceResult<Technician>, Void> saveWorker = new SwingWorker<>() {
            @Override
            protected ServiceResult<Technician> doInBackground() {
                return existingTechnician != null
                        ? technicianService.updateTechnician(technician)
                        : technicianService.createTechnician(technician);
            }

            @Override
            protected void done() {
                view.getSaveButton().setEnabled(true);
                try {
                    ServiceResult<Technician> result = get();
                    if (result.isSuccess()) {
                        view.closeDialog();
                    } else {
                        view.showError(result.getMessage());
                        view.markFieldInvalid(view.getNameField());
                    }
                } catch (Exception ex) {
                    view.showError("Unexpected error: " + ex.getMessage());
                }
            }
        };
        saveWorker.execute();
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}

