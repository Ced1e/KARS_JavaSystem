package com.familyhvac.controllers;

import com.familyhvac.models.TechnicianPayout;
import com.familyhvac.models.TechnicianPayoutDisbursement;
import com.familyhvac.services.ServiceResult;
import com.familyhvac.services.TechnicianPayoutService;
import com.familyhvac.views.PendingPayoutsDialog;

import javax.swing.*;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Coordinates dashboard payout drill-down and release action. */
public class PendingPayoutsController {
    private final PendingPayoutsDialog view;
    private final TechnicianPayoutService payouts = new TechnicianPayoutService();
    public PendingPayoutsController(PendingPayoutsDialog view) { this.view=view; view.getRefreshButton().addActionListener(e->load()); view.getReleaseButton().addActionListener(e->releaseSelected()); load(); }
    private void load() { new SwingWorker<List<TechnicianPayout>, Void>() {
        @Override protected List<TechnicianPayout> doInBackground() { return payouts.listAllPayouts().stream().filter(p -> payouts.calculateRemaining(p) > 0).toList(); }
        @Override protected void done() { try { List<TechnicianPayout> values=get(); Map<Integer,Double> released=new HashMap<>(); double total=0; for(TechnicianPayout payout:values){double amount=payouts.calculateDisbursed(payout.getId()); released.put(payout.getId(),amount); total+=Math.max(0,(payout.getApprovedAmount()==null?0:payout.getApprovedAmount())-amount);} view.setPayouts(values,released,total); } catch(Exception error) { view.showError(error.getMessage()); } }
    }.execute(); }
    private void releaseSelected() { TechnicianPayout payout=view.getSelectedPayout(); if(payout==null){view.showError("Select a payout first.");return;} double remaining=payouts.calculateRemaining(payout); if(remaining<=0){view.showError("This payout has already been released.");load();return;} TechnicianPayoutDisbursement disbursement=new TechnicianPayoutDisbursement(); disbursement.setTechnicianPayoutId(payout.getId()); disbursement.setAmount(remaining); disbursement.setDisbursementType(TechnicianPayoutDisbursement.DisbursementType.SETTLEMENT); disbursement.setPaymentMethod(TechnicianPayoutDisbursement.PaymentMethod.CASH); disbursement.setDisbursementDate(LocalDate.now().toString()); new SwingWorker<ServiceResult<TechnicianPayoutDisbursement>, Void>() { @Override protected ServiceResult<TechnicianPayoutDisbursement> doInBackground(){return payouts.addDisbursement(disbursement);} @Override protected void done(){try{ServiceResult<TechnicianPayoutDisbursement> result=get();if(result.isSuccess())load();else view.showError(result.getMessage());}catch(Exception error){view.showError(error.getMessage());}} }.execute(); }
}
