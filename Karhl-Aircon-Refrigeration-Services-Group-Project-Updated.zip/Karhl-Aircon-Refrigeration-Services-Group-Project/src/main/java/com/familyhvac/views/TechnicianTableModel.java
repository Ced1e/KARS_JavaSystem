package com.familyhvac.views;

import com.familyhvac.models.Technician;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/**
 * Adapts a list of {@link Technician} objects for display in a JTable.
 * Kept read-only (isCellEditable always false) - all edits happen through
 * {@link TechnicianFormDialog}, never inline in the table.
 */
public class TechnicianTableModel extends AbstractTableModel {

    private static final String[] COLUMN_NAMES = {
            "Technician Code", "Name", "Phone", "Status", "Outstanding Payouts"
    };

    private List<Technician> technicians = new ArrayList<>();
    private java.util.Map<Integer, Double> outstandingPayouts = java.util.Map.of();

    public void setTechnicians(List<Technician> technicians, java.util.Map<Integer, Double> outstandingPayouts) {
        this.technicians = technicians != null ? technicians : new ArrayList<>();
        this.outstandingPayouts = outstandingPayouts != null ? outstandingPayouts : java.util.Map.of();
        fireTableDataChanged();
    }

    public Technician getTechnicianAt(int rowIndex) {
        return technicians.get(rowIndex);
    }

    @Override
    public int getRowCount() {
        return technicians.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return COLUMN_NAMES[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Technician technician = technicians.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> technician.getTechnicianCode();
            case 1 -> technician.getName();
            case 2 -> nullToDash(technician.getPhoneNumber());
            case 3 -> technician.isActive() ? "Active" : "Archived";
            case 4 -> String.format("₱%,.2f", outstandingPayouts.getOrDefault(technician.getId(), 0.0));
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    private String nullToDash(String value) {
        return (value == null || value.isBlank()) ? "-" : value;
    }
}
