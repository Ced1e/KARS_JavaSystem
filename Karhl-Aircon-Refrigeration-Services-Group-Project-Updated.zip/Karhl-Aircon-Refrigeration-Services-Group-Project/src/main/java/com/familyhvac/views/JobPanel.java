package com.familyhvac.views;

import com.familyhvac.controllers.JobListController;
import com.familyhvac.models.Job;
import com.familyhvac.models.ServiceCategory;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Job list screen shown under the "Jobs" sidebar item. Contains no
 * business logic and no SQL - it only exposes getters for its
 * table/fields/buttons. All behavior lives in {@link JobListController}.
 *
 * A selected duplicate or erroneous job can be permanently removed only
 * after an explicit confirmation in the controller.
 */
public class JobPanel extends JPanel {

    private static final String CARD_TABLE = "TABLE";
    private static final String CARD_EMPTY = "EMPTY";

    private JTable jobTable;
    private JobTableModel tableModel;
    private JTextField searchField;
    private JComboBox<Job.JobStatus> statusFilterCombo;
    private JComboBox<ServiceCategory> categoryFilterCombo;
    private JComboBox<String> dateRangeFilterCombo;
    private DatePickerField dateFilterField;
    private JButton addButton;
    private JButton editButton;
    private JButton detailsButton;
    private JButton deleteButton;
    private JButton refreshButton;
    private JComboBox<Job.JobStatus> changeStatusCombo;
    private JButton changeStatusButton;

    private final CardLayout tableAreaLayout = new CardLayout();
    private final JPanel tableAreaPanel = new JPanel(tableAreaLayout);

    public JobPanel() {
        buildUI();
        new JobListController(this);
    }

    private void buildUI() {
        setLayout(new BorderLayout());
        setBackground(UITheme.COLOR_BACKGROUND);
        setBorder(PageLayoutSupport.pagePadding());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTableArea(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(UITheme.COLOR_BACKGROUND);
        header.setBorder(new EmptyBorder(0, 0, UITheme.SPACING_MD, 0));

        JPanel title = PageLayoutSupport.titleBlock("Jobs", "Schedule work, monitor progress, and update the status in one place.");
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel toolbar = buildToolbar();
        toolbar.setAlignmentX(Component.LEFT_ALIGNMENT);
        toolbar.setBorder(new EmptyBorder(UITheme.SPACING_MD, 0, 0, 0));

        header.add(title);
        header.add(toolbar);
        return header;
    }

    private JPanel buildToolbar() {
        JPanel toolbar = PageLayoutSupport.toolbarSurface();

        // Filters and actions have separate rows so neither group can be squeezed
        // underneath or on top of the other at narrower window widths.
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);
        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filterRow.setOpaque(false);
        filterRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        filterRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        searchField = PageLayoutSupport.searchField("Search by job code, client, location, or description");

        statusFilterCombo = new JComboBox<>();
        statusFilterCombo.addItem(null);
        for (Job.JobStatus status : Job.JobStatus.values()) {
            statusFilterCombo.addItem(status);
        }
        statusFilterCombo.setFont(UITheme.FONT_BODY);
        statusFilterCombo.setRenderer(new StatusFilterCellRenderer());

        searchField.setPreferredSize(new Dimension(300, 36));
        statusFilterCombo.setPreferredSize(new Dimension(180, 36));
        filterRow.add(searchField);
        filterRow.add(statusFilterCombo);
        categoryFilterCombo = new JComboBox<>();
        categoryFilterCombo.addItem(null);
        categoryFilterCombo.setRenderer(new CategoryFilterCellRenderer());
        dateRangeFilterCombo = new JComboBox<>(new String[]{"All Dates", "Selected Date", "Week", "Month", "Year"});
        dateFilterField = new DatePickerField(false);
        dateFilterField.setPreferredSize(new Dimension(155, 34));
        categoryFilterCombo.setPreferredSize(new Dimension(220, 36));
        dateRangeFilterCombo.setPreferredSize(new Dimension(150, 36));
        filterRow.add(categoryFilterCombo);
        filterRow.add(dateRangeFilterCombo);
        filterRow.add(dateFilterField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttonPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        refreshButton = createSecondaryButton("Refresh");
        editButton = createSecondaryButton("Edit");
        editButton.setEnabled(false);
        detailsButton = createSecondaryButton("Details");
        detailsButton.setEnabled(false);
        deleteButton = createSecondaryButton("Delete Job");
        deleteButton.setForeground(UITheme.COLOR_DANGER);
        deleteButton.setEnabled(false);
        changeStatusCombo = new JComboBox<>(Job.JobStatus.values());
        changeStatusCombo.setEnabled(false);
        changeStatusButton = createSecondaryButton("Update Status");
        changeStatusButton.setEnabled(false);
        addButton = UITheme.createPrimaryButton("+ Add Job");

        buttonPanel.add(refreshButton);
        buttonPanel.add(editButton);
        buttonPanel.add(detailsButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(changeStatusCombo);
        buttonPanel.add(changeStatusButton);
        buttonPanel.add(addButton);

        content.add(filterRow);
        content.add(Box.createVerticalStrut(8));
        content.add(buttonPanel);
        toolbar.add(content, BorderLayout.CENTER);
        return toolbar;
    }

    private JButton createSecondaryButton(String text) {
        return UITheme.createSecondaryButton(text);
    }

    private JPanel buildTableArea() {
        tableModel = new JobTableModel();
        jobTable = new JTable(tableModel);
        jobTable.setFont(UITheme.FONT_BODY);
        jobTable.setRowHeight(36);
        jobTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jobTable.setAutoCreateRowSorter(true);
        jobTable.getTableHeader().setFont(UITheme.FONT_LABEL);
        jobTable.setFillsViewportHeight(true);
        jobTable.getColumnModel().getColumn(4).setCellRenderer(new StatusBadgeRenderer());
        jobTable.getColumnModel().getColumn(5).setCellRenderer(new CurrencyRenderer());
        jobTable.getColumnModel().getColumn(6).setCellRenderer(new CurrencyRenderer());

        JScrollPane scrollPane = PageLayoutSupport.tableSurface(jobTable);

        tableAreaPanel.setBackground(UITheme.COLOR_BACKGROUND);
        tableAreaPanel.add(scrollPane, CARD_TABLE);
        tableAreaPanel.add(buildEmptyStatePanel(), CARD_EMPTY);
        tableAreaLayout.show(tableAreaPanel, CARD_TABLE);

        return tableAreaPanel;
    }

    private JPanel buildEmptyStatePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER));

        JLabel label = new JLabel("No jobs found. Try adjusting your search or filters.");
        label.setFont(UITheme.FONT_SUBTITLE);
        label.setForeground(UITheme.COLOR_TEXT_SECONDARY);

        panel.add(label);
        return panel;
    }

    /** Switches between the table and the "no jobs found" placeholder. */
    public void showEmptyState(boolean empty) {
        tableAreaLayout.show(tableAreaPanel, empty ? CARD_EMPTY : CARD_TABLE);
    }

    public JTable getJobTable() {
        return jobTable;
    }

    public JobTableModel getTableModel() {
        return tableModel;
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public JComboBox<Job.JobStatus> getStatusFilterCombo() {
        return statusFilterCombo;
    }

    public Job.JobStatus getSelectedStatusFilter() {
        return (Job.JobStatus) statusFilterCombo.getSelectedItem();
    }
    public JComboBox<ServiceCategory> getCategoryFilterCombo() { return categoryFilterCombo; }
    public Integer getSelectedCategoryId() { ServiceCategory selected=(ServiceCategory)categoryFilterCombo.getSelectedItem(); return selected==null?null:selected.getId(); }
    public JComboBox<String> getDateRangeFilterCombo() { return dateRangeFilterCombo; }
    public String getSelectedDateRange() { return (String)dateRangeFilterCombo.getSelectedItem(); }
    public DatePickerField getDateFilterField() { return dateFilterField; }
    public java.time.LocalDate getFilterReferenceDate() { try { java.time.LocalDate value=dateFilterField.getDate(); return value==null?java.time.LocalDate.now():value; } catch (RuntimeException ignored) { return java.time.LocalDate.now(); } }
    public void setCategoryFilters(java.util.List<ServiceCategory> categories) { Integer selected=getSelectedCategoryId(); DefaultComboBoxModel<ServiceCategory> model=new DefaultComboBoxModel<>(); model.addElement(null); for(ServiceCategory category:categories)model.addElement(category); categoryFilterCombo.setModel(model); if(selected!=null)for(int i=1;i<model.getSize();i++)if(model.getElementAt(i).getId()==selected){categoryFilterCombo.setSelectedIndex(i);return;} }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getEditButton() {
        return editButton;
    }
    public JButton getDetailsButton() { return detailsButton; }
    public JButton getDeleteButton() { return deleteButton; }

    public JButton getRefreshButton() {
        return refreshButton;
    }
    public JComboBox<Job.JobStatus> getChangeStatusCombo() { return changeStatusCombo; }
    public JButton getChangeStatusButton() { return changeStatusButton; }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public boolean confirm(String message, String title) {
        return JOptionPane.showConfirmDialog(this, message, title, JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
    }

    /** Renders a null status filter selection as "All Statuses" instead of the word "null". */
    private static class StatusFilterCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                        boolean isSelected, boolean cellHasFocus) {
            String display = (value == null) ? "All Statuses" : formatStatus((Job.JobStatus) value);
            return super.getListCellRendererComponent(list, display, index, isSelected, cellHasFocus);
        }

        private String formatStatus(Job.JobStatus status) {
            String[] words = status.name().split("_");
            StringBuilder builder = new StringBuilder();
            for (String word : words) {
                if (!word.isEmpty()) {
                    builder.append(Character.toUpperCase(word.charAt(0)))
                            .append(word.substring(1).toLowerCase())
                            .append(' ');
                }
            }
            return builder.toString().trim();
        }
    }

    private static class CurrencyRenderer extends javax.swing.table.DefaultTableCellRenderer {
        CurrencyRenderer() { setHorizontalAlignment(SwingConstants.CENTER); }
        @Override protected void setValue(Object value) { setText(value instanceof Number amount ? String.format("₱%,.2f", amount.doubleValue()) : "₱0.00"); }
    }
    private static class CategoryFilterCellRenderer extends DefaultListCellRenderer {
        @Override public Component getListCellRendererComponent(JList<?> list,Object value,int index,boolean selected,boolean focus) { super.getListCellRendererComponent(list,value,index,selected,focus); setText(value==null?"All Categories":((ServiceCategory)value).getName()); return this; }
    }
}
