package com.familyhvac.views;

import com.familyhvac.dao.AnalyticsDAO;
import com.familyhvac.controllers.ReportsController;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import javax.swing.table.TableRowSorter;
import javax.swing.table.DefaultTableModel;

/** Detailed, date-scoped job activity log with gross, tax, and net totals. */
public class ReportsPanel extends JPanel {
    private JComboBox<String> period;
    private JSpinner date;
    private JButton run, pdf, docx, print;
    private JobReportTableModel model;
    private JTable table;
    private JLabel jobCount, grossTotal, operatingExpenses, technicianPayouts, ewtTotal, netEarnings;
    private DefaultTableModel expenseBreakdownModel;
    private AnalyticsDAO.ReportSummary currentSummary;
    private JTextField search;

    public ReportsPanel() {
        setLayout(new BorderLayout(0, 18));
        setBackground(UITheme.COLOR_BACKGROUND);
        setBorder(PageLayoutSupport.pagePadding());
        add(buildHeader(), BorderLayout.NORTH);
        model = new JobReportTableModel(); table = new JTable(model); configureTable();
        JPanel content = new JPanel(new BorderLayout(0, 14)); content.setOpaque(false);
        content.add(PageLayoutSupport.tableSurface(table), BorderLayout.CENTER);
        content.add(buildExpenseBreakdown(), BorderLayout.SOUTH);
        add(content, BorderLayout.CENTER);
        new ReportsController(this);
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout(0, 18)); header.setOpaque(false);
        header.add(PageLayoutSupport.titleBlock("Work Reports", "Review a complete job log for a day, week, month, quarter, or year."), BorderLayout.NORTH);
        JPanel controls = PageLayoutSupport.toolbarSurface();
        JPanel line = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); line.setOpaque(false);
        period = new JComboBox<>(new String[]{"Day", "Week", "Month", "Quarter", "Year"});
        date = new JSpinner(new SpinnerDateModel(java.util.Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()), null, null, java.util.Calendar.DAY_OF_MONTH)); date.setEditor(new JSpinner.DateEditor(date, "dd-MM-yyyy"));
        search = PageLayoutSupport.searchField("Filter client, job, category, status, or expense details");
        line.add(caption("Period")); line.add(period); line.add(caption("Reference date")); line.add(date); line.add(search);
        run = UITheme.createPrimaryButton("Run Report"); pdf = UITheme.createSecondaryButton("Export PDF"); docx = UITheme.createSecondaryButton("Export DOCX"); print = UITheme.createSecondaryButton("Print");
        line.add(run); line.add(pdf); line.add(docx); line.add(print); controls.add(line, BorderLayout.CENTER);
        JPanel totals = new JPanel(new GridLayout(2, 3, 12, 10)); totals.setOpaque(false);
        jobCount = totalLabel("Jobs: 0"); grossTotal = totalLabel("Gross Revenue: PHP 0.00"); operatingExpenses = totalLabel("Operating Expenses: PHP 0.00"); technicianPayouts = totalLabel("Technician Payouts: PHP 0.00"); ewtTotal = totalLabel("Total EWT Withheld: PHP 0.00"); netEarnings = totalLabel("Net Earnings: PHP 0.00");
        totals.add(jobCount); totals.add(grossTotal); totals.add(operatingExpenses); totals.add(technicianPayouts); totals.add(ewtTotal); totals.add(netEarnings); JPanel lower=new JPanel(); lower.setLayout(new BoxLayout(lower, BoxLayout.Y_AXIS)); lower.setOpaque(false); lower.add(controls); lower.add(Box.createVerticalStrut(12)); lower.add(totals); header.add(lower, BorderLayout.SOUTH);
        return header;
    }
    private JComponent buildExpenseBreakdown() { JPanel section=new JPanel(new BorderLayout(0,6)); section.setOpaque(false); JLabel title=new JLabel("Operating Expense Breakdown"); title.setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD)); title.setForeground(UITheme.COLOR_TEXT_PRIMARY); expenseBreakdownModel=new DefaultTableModel(new Object[]{"Expense Category","Amount"},0){@Override public boolean isCellEditable(int r,int c){return false;}}; JTable breakdown=new JTable(expenseBreakdownModel); PageLayoutSupport.centerTableContents(breakdown); breakdown.setFont(UITheme.FONT_LABEL); breakdown.setRowHeight(25); breakdown.getTableHeader().setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD)); JScrollPane scroll=new JScrollPane(breakdown); scroll.setPreferredSize(new Dimension(100,110)); section.add(title,BorderLayout.NORTH); section.add(scroll,BorderLayout.CENTER); return section; }

    private JLabel caption(String text) { JLabel label = new JLabel(text); label.setFont(UITheme.FONT_LABEL); label.setForeground(UITheme.COLOR_TEXT_SECONDARY); return label; }
    private JLabel totalLabel(String text) { JLabel label = new JLabel(text); label.setOpaque(true); label.setBackground(UITheme.COLOR_CARD_BG); label.setBorder(new EmptyBorder(10, 12, 10, 12)); label.setFont(UITheme.FONT_BUTTON); label.setForeground(UITheme.COLOR_TEXT_PRIMARY); return label; }
    private void configureTable() { table.setFont(UITheme.FONT_BODY); table.setRowHeight(36); table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); table.setFillsViewportHeight(true); table.getTableHeader().setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD)); PageLayoutSupport.centerTableContents(table); TableRowSorter<JobReportTableModel> sorter=new TableRowSorter<>(model);table.setRowSorter(sorter);search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){public void insertUpdate(javax.swing.event.DocumentEvent e){f();}public void removeUpdate(javax.swing.event.DocumentEvent e){f();}public void changedUpdate(javax.swing.event.DocumentEvent e){f();}private void f(){String q=search.getText().trim();sorter.setRowFilter(q.isEmpty()?null:RowFilter.regexFilter("(?i)"+java.util.regex.Pattern.quote(q)));}}); }
    public JButton getRunButton() { return run; } public JButton getPdfButton() { return pdf; } public JButton getDocxButton() { return docx; } public JButton getPrintButton() { return print; }
    public LocalDate getDate() { return ((java.util.Date) date.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate(); } public String getPeriod() { return (String) period.getSelectedItem(); } public String getReportType() { return "Job Activity Log"; }
    public void setJobLog(List<AnalyticsDAO.JobReportRow> rows) { model.setRows(rows); }
    public void setSummary(AnalyticsDAO.ReportSummary summary) { currentSummary=summary; jobCount.setText("Jobs: " + summary.jobCount()); grossTotal.setText("Gross Revenue: " + money(summary.grossRevenue())); operatingExpenses.setText("Operating Expenses: " + money(summary.operatingExpenses())); technicianPayouts.setText("Technician Payouts: " + money(summary.technicianPayouts())); ewtTotal.setText("Total EWT Withheld: " + money(summary.totalEwtWithheld())); netEarnings.setText("Net Earnings: " + money(summary.netEarnings())); expenseBreakdownModel.setRowCount(0); for(AnalyticsDAO.ExpenseCategoryTotal item:summary.expenseBreakdown())expenseBreakdownModel.addRow(new Object[]{item.category(),money(item.amount())}); }
    public AnalyticsDAO.ReportSummary getSummary(){ return currentSummary; }
    public List<AnalyticsDAO.JobReportRow> getReportRows() { return model.getRows(); }
    public boolean printResults() { try { return table.print(); } catch (java.awt.print.PrinterException error) { showError(error.getMessage()); return false; } }
    public void showError(String message) { JOptionPane.showMessageDialog(this, message, "Reports", JOptionPane.ERROR_MESSAGE); }
    private String money(double amount) { return String.format("PHP %,.2f", amount); }
}
