package com.familyhvac.views;
import com.familyhvac.models.TechnicianPayout; import javax.swing.table.AbstractTableModel; import java.util.*;
/** Read-only payout table; remaining values are supplied freshly by the controller. */
public class TechnicianPayoutTableModel extends AbstractTableModel {
 private final String[] columns={"Technician","Lead","Approved Payout","Disbursed","Remaining"}; private List<TechnicianPayout> payouts=new ArrayList<>(); private Map<Integer,Double> disbursed=Map.of();
 public void setPayouts(List<TechnicianPayout> value,Map<Integer,Double> totals){payouts=value==null?new ArrayList<>():value;disbursed=totals==null?Map.of():totals;fireTableDataChanged();}
 public TechnicianPayout getPayoutAt(int row){return payouts.get(row);} @Override public int getRowCount(){return payouts.size();}@Override public int getColumnCount(){return columns.length;}@Override public String getColumnName(int c){return columns[c];}
 @Override public Object getValueAt(int r,int c){TechnicianPayout p=payouts.get(r);double paid=disbursed.getOrDefault(p.getId(),0.0);Double approved=p.getApprovedAmount();return switch(c){case 0->p.getTechnicianName();case 1->p.isLead()?"Yes":"";case 2->approved==null?"Not negotiated":money(approved);case 3->money(paid);case 4->approved==null?"—":money(approved-paid);default->"";};}
 @Override public boolean isCellEditable(int r,int c){return false;} private String money(double v){return String.format("₱%,.2f",v);}
}
