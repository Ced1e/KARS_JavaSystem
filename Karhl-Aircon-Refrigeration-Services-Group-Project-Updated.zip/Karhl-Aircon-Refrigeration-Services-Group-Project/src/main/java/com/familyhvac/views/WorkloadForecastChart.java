package com.familyhvac.views;

import com.familyhvac.dao.AnalyticsDAO.ActivityPoint;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Dependency-free, dual-axis line chart for complete day-by-day job activity. */
public final class WorkloadForecastChart extends JPanel {
    private static final Color WORKLOAD_BLUE = new Color(0x25, 0x6D, 0xD7);
    private static final Color EARNINGS_GREEN = new Color(0x18, 0x8A, 0x4C);
    private static final DateTimeFormatter WEEK_FORMAT = DateTimeFormatter.ofPattern("dd MMM");
    private List<ActivityPoint> trend = List.of();

    public WorkloadForecastChart() {
        setOpaque(false);
        setPreferredSize(new Dimension(760, 270));
        setToolTipText(" ");
    }

    public void setTrend(List<ActivityPoint> values) {
        trend = values == null ? List.of() : List.copyOf(values);
        repaint();
    }

    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int width = getWidth(), height = getHeight();
            int left = 50, right = 76, top = 34, bottom = 42;
            int plotWidth = Math.max(1, width - left - right), plotHeight = Math.max(1, height - top - bottom);
            drawLegend(g, left);
            if (trend.isEmpty() || trend.stream().allMatch(p -> p.scheduledJobs() == 0 && p.expectedEarnings() == 0)) {
                g.setFont(UITheme.FONT_BODY);
                g.setColor(UITheme.COLOR_TEXT_SECONDARY);
                String message = "No job activity has been recorded yet.";
                FontMetrics metrics = g.getFontMetrics();
                g.drawString(message, (width - metrics.stringWidth(message)) / 2, top + plotHeight / 2);
                return;
            }
            int maxJobs = Math.max(1, trend.stream().mapToInt(ActivityPoint::scheduledJobs).max().orElse(1));
            double maxEarnings = Math.max(1, trend.stream().mapToDouble(ActivityPoint::expectedEarnings).max().orElse(1));
            maxJobs = roundedJobMaximum(maxJobs);
            maxEarnings = roundedMoneyMaximum(maxEarnings);
            g.setStroke(new BasicStroke(1f));
            g.setFont(UITheme.FONT_LABEL.deriveFont(10f));
            for (int step = 0; step <= 4; step++) {
                int y = top + (plotHeight * step / 4);
                g.setColor(UITheme.COLOR_BORDER);
                g.drawLine(left, y, width - right, y);
                g.setColor(UITheme.COLOR_TEXT_SECONDARY);
                int jobs = Math.round(maxJobs * (4 - step) / 4f);
                String jobText = String.valueOf(jobs);
                g.drawString(jobText, left - 8 - g.getFontMetrics().stringWidth(jobText), y + 4);
                String moneyText = shortPeso(maxEarnings * (4 - step) / 4d);
                g.drawString(moneyText, width - right + 8, y + 4);
            }
            Path2D jobsLine = new Path2D.Double(), earningsLine = new Path2D.Double();
            for (int index = 0; index < trend.size(); index++) {
                ActivityPoint point = trend.get(index);
                double x = xFor(index, trend.size(), left, plotWidth);
                double jobsY = top + plotHeight - (point.scheduledJobs() / (double) maxJobs * plotHeight);
                double earningsY = top + plotHeight - (point.expectedEarnings() / maxEarnings * plotHeight);
                if (index == 0) { jobsLine.moveTo(x, jobsY); earningsLine.moveTo(x, earningsY); }
                else { jobsLine.lineTo(x, jobsY); earningsLine.lineTo(x, earningsY); }
            }
            g.setStroke(new BasicStroke(2.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(WORKLOAD_BLUE); g.draw(jobsLine);
            g.setColor(EARNINGS_GREEN); g.draw(earningsLine);
            int labelEvery = Math.max(1, (trend.size() - 1) / 6);
            for (int index = 0; index < trend.size(); index++) {
                ActivityPoint point = trend.get(index);
                int x = (int) Math.round(xFor(index, trend.size(), left, plotWidth));
                int jobsY = (int) Math.round(top + plotHeight - (point.scheduledJobs() / (double) maxJobs * plotHeight));
                int earningsY = (int) Math.round(top + plotHeight - (point.expectedEarnings() / maxEarnings * plotHeight));
                dot(g, x, jobsY, WORKLOAD_BLUE); dot(g, x, earningsY, EARNINGS_GREEN);
                g.setFont(UITheme.FONT_LABEL.deriveFont(10f)); g.setColor(UITheme.COLOR_TEXT_SECONDARY);
                if (index % labelEvery == 0 || index == trend.size() - 1) { String label = WEEK_FORMAT.format(point.periodStart()); FontMetrics metrics = g.getFontMetrics(); g.drawString(label, x - metrics.stringWidth(label) / 2, height - 16); }
            }
        } finally { g.dispose(); }
    }

    @Override public String getToolTipText(MouseEvent event) {
        if (trend.isEmpty()) return null;
        int left = 50, right = 76, plotWidth = Math.max(1, getWidth() - left - right);
        int nearest = Math.max(0, Math.min(trend.size() - 1,
                (int) Math.round((event.getX() - left) * (trend.size() - 1d) / plotWidth)));
        ActivityPoint point = trend.get(nearest);
        return WEEK_FORMAT.format(point.periodStart()) + " — " + point.scheduledJobs()
                + " scheduled job" + (point.scheduledJobs() == 1 ? "" : "s")
                + "; expected earnings ₱" + String.format("%,.2f", point.expectedEarnings());
    }

    private void drawLegend(Graphics2D g, int x) {
        g.setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD, 11f));
        g.setColor(WORKLOAD_BLUE); g.fillRoundRect(x, 10, 18, 4, 4, 4);
        g.setColor(UITheme.COLOR_TEXT_SECONDARY); g.drawString("Jobs scheduled", x + 25, 16);
        int second = x + 150;
        g.setColor(EARNINGS_GREEN); g.fillRoundRect(second, 10, 18, 4, 4, 4);
        g.setColor(UITheme.COLOR_TEXT_SECONDARY); g.drawString("Expected earnings", second + 25, 16);
    }
    private void dot(Graphics2D g, int x, int y, Color color) { g.setColor(Color.WHITE); g.fillOval(x - 4, y - 4, 8, 8); g.setColor(color); g.fillOval(x - 3, y - 3, 6, 6); }
    private double xFor(int index, int size, int left, int width) { return size <= 1 ? left + width / 2d : left + index * (width / (double) (size - 1)); }
    private int roundedJobMaximum(int value) { return value <= 4 ? 4 : ((value + 4) / 5) * 5; }
    private double roundedMoneyMaximum(double value) { double unit = Math.pow(10, Math.floor(Math.log10(value))); return Math.ceil(value / unit) * unit; }
    private String shortPeso(double value) { return value >= 1000 ? "₱" + String.format("%.0fk", value / 1000d) : "₱" + String.format("%.0f", value); }
}
