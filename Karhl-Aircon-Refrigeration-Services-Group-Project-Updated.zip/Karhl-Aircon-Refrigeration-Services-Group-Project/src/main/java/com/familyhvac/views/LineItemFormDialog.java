package com.familyhvac.views;

import com.familyhvac.controllers.LineItemFormController;
import com.familyhvac.models.JobLineItem;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Add/Edit form for one job line item (description, quantity, unit
 * price). Subtotal is never entered here - it's shown live, computed as
 * quantity * unitPrice, and never sent to the database as its own value.
 *
 * Contains no business logic and no SQL. All behavior lives in
 * {@link LineItemFormController}.
 *
 * When constructed with a null {@code existingLineItem}, this is an "Add"
 * dialog for the given job; otherwise it's an "Edit" dialog pre-populated
 * from that line item.
 */
public class LineItemFormDialog extends JDialog {

    private final int jobId;
    private final JobLineItem existingLineItem;

    private JTextField descriptionField;
    private JTextField quantityField;
    private JTextField unitPriceField;
    private JLabel subtotalValueLabel;
    private JLabel errorLabel;
    private JButton saveButton;
    private JButton cancelButton;

    public LineItemFormDialog(Dialog owner, int jobId, JobLineItem existingLineItem) {
        super(owner, existingLineItem == null ? "Add Line Item" : "Edit Line Item", true);
        this.jobId = jobId;
        this.existingLineItem = existingLineItem;
        buildUI();
        populateFieldsIfEditing();
        new LineItemFormController(this, jobId, existingLineItem);
    }

    private void buildUI() {
        setSize(480, 430);
        setMinimumSize(new Dimension(420, 380));
        setLocationRelativeTo(getOwner());

        errorLabel = FormDialogSupport.errorLabel();

        descriptionField = new JTextField();
        quantityField = new JTextField();
        quantityField.setText("1");
        unitPriceField = new JTextField();
        unitPriceField.setText("0");

        addClearValidationOnEdit(descriptionField);
        addClearValidationOnEdit(quantityField);
        addClearValidationOnEdit(unitPriceField);

        JPanel body = FormDialogSupport.formStack(errorLabel,
                FormDialogSupport.field("Description *", descriptionField),
                FormDialogSupport.field("Quantity *", quantityField),
                FormDialogSupport.field("Unit Price *", unitPriceField), buildSubtotalRow());
        setContentPane(FormDialogSupport.dialogRoot(existingLineItem == null ? "Add line item" : "Edit line item",
                "Enter the work item and its agreed unit price.", body, buildButtonRow()));
    }

    private JPanel buildSubtotalRow() {
        subtotalValueLabel = new JLabel("\u20B10.00");
        return FormDialogSupport.amountSummary("Calculated subtotal", subtotalValueLabel);
    }

    private JPanel labeledField(String label, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(UITheme.FONT_LABEL);
        labelComponent.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        labelComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        field.setFont(UITheme.FONT_BODY);
        if (field instanceof JTextField textField) {
            textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                    new EmptyBorder(4, 8, 4, 8)
            ));
        }

        panel.add(labelComponent);
        panel.add(Box.createVerticalStrut(4));
        panel.add(field);
        return panel;
    }

    private JPanel buildButtonRow() {
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        saveButton = UITheme.createPrimaryButton("Save");
        return FormDialogSupport.actionRow(cancelButton, saveButton);
    }

    private void populateFieldsIfEditing() {
        if (existingLineItem == null) {
            updateSubtotalPreview();
            return;
        }
        descriptionField.setText(existingLineItem.getDescription());
        quantityField.setText(formatPlainNumber(existingLineItem.getQuantity()));
        unitPriceField.setText(formatPlainNumber(existingLineItem.getUnitPrice()));
        updateSubtotalPreview();
    }

    private String formatPlainNumber(double value) {
        return (value == Math.floor(value)) ? String.format("%.0f", value) : String.format("%.2f", value);
    }

    /** Puts a red border on the given field to flag it as invalid. */
    public void markFieldInvalid(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_DANGER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }

    /** Restores the given field's border to its normal (non-error) style. */
    public void clearFieldValidation(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }

    /**
     * Clears a field's red "invalid" border and refreshes the live
     * subtotal preview as soon as the user edits any of the three fields.
     */
    private void addClearValidationOnEdit(JTextField field) {
        field.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
                updateSubtotalPreview();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
                updateSubtotalPreview();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
                updateSubtotalPreview();
            }
        });
    }

    /**
     * Live subtotal preview as the user types - purely a display
     * convenience computed from the current field text. Invalid/blank
     * numeric input is just shown as zero here; real validation happens
     * in {@link LineItemFormController} on Save.
     */
    private void updateSubtotalPreview() {
        double quantity = parseLenient(quantityField.getText());
        double unitPrice = parseLenient(unitPriceField.getText());
        subtotalValueLabel.setText(String.format("\u20B1%,.2f", quantity * unitPrice));
    }

    private double parseLenient(String text) {
        try {
            return text == null ? 0 : Double.parseDouble(text.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public int getJobId() {
        return jobId;
    }

    public String getDescriptionInput() {
        return descriptionField.getText();
    }

    public String getQuantityInput() {
        return quantityField.getText();
    }

    public String getUnitPriceInput() {
        return unitPriceField.getText();
    }

    public JTextField getDescriptionField() {
        return descriptionField;
    }

    public JTextField getQuantityField() {
        return quantityField;
    }

    public JTextField getUnitPriceField() {
        return unitPriceField;
    }

    public JButton getSaveButton() {
        return saveButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public void showError(String message) {
        errorLabel.setText(message);
    }

    public void closeDialog() {
        dispose();
    }
}
