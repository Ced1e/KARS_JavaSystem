package com.familyhvac.views;

import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Shared layout pieces that keep data-entry dialogs aligned and consistent. */
final class FormDialogSupport {
    private FormDialogSupport() { }

    static JPanel dialogRoot(String title, String subtitle, JComponent body, JComponent footer) {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.COLOR_CARD_BG);

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(UITheme.COLOR_CARD_BG);
        header.setBorder(new EmptyBorder(24, 26, 14, 26));
        header.add(UITheme.createSectionTitle(title));
        header.add(Box.createVerticalStrut(5));
        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(UITheme.FONT_SUBTITLE);
        subtitleLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        header.add(subtitleLabel);

        JScrollPane content = new JScrollPane(body);
        content.setBorder(null);
        content.getVerticalScrollBar().setUnitIncrement(16);
        root.add(header, BorderLayout.NORTH);
        root.add(content, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        return root;
    }

    static JPanel formStack(JComponent... components) {
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(UITheme.COLOR_CARD_BG);
        body.setBorder(new EmptyBorder(18, 26, 8, 26));
        for (int i = 0; i < components.length; i++) {
            body.add(components[i]);
            if (i < components.length - 1) body.add(Box.createVerticalStrut(14));
        }
        return body;
    }

    static JPanel field(String label, JComponent component) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));

        if (!label.isBlank()) {
            JLabel caption = new JLabel(label);
            caption.setFont(UITheme.FONT_LABEL);
            caption.setForeground(UITheme.COLOR_TEXT_SECONDARY);
            caption.setAlignmentX(Component.LEFT_ALIGNMENT);
            panel.add(caption);
            panel.add(Box.createVerticalStrut(5));
        }
        styleInput(component);
        panel.add(component);
        return panel;
    }

    static JPanel amountSummary(String label, JLabel value) {
        JPanel summary = new JPanel(new BorderLayout());
        summary.setBackground(UITheme.COLOR_SECONDARY);
        summary.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                new EmptyBorder(12, 14, 12, 14)));
        JLabel caption = new JLabel(label);
        caption.setFont(UITheme.FONT_LABEL);
        caption.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        value.setFont(UITheme.FONT_BUTTON);
        value.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        summary.add(caption, BorderLayout.WEST);
        summary.add(value, BorderLayout.EAST);
        return summary;
    }

    static JPanel actionRow(JButton cancel, JButton primary) {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        footer.setBackground(UITheme.COLOR_CARD_BG);
        footer.setBorder(new EmptyBorder(16, 26, 22, 26));
        cancel.setFont(UITheme.FONT_BODY);
        cancel.setFocusPainted(false);
        cancel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        footer.add(cancel);
        footer.add(primary);
        return footer;
    }

    static JLabel errorLabel() {
        JLabel error = new JLabel(" ");
        error.setFont(UITheme.FONT_LABEL);
        error.setForeground(UITheme.COLOR_DANGER);
        error.setAlignmentX(Component.LEFT_ALIGNMENT);
        error.setBorder(new EmptyBorder(0, 0, 2, 0));
        return error;
    }

    static void styleInput(JComponent component) {
        component.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        component.setFont(UITheme.FONT_BODY);
        if (component instanceof JTextField textField) {
            textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                    new EmptyBorder(5, 9, 5, 9)));
        }
    }
}
