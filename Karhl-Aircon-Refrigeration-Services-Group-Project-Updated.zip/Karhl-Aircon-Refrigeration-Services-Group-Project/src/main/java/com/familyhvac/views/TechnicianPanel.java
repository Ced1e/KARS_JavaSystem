package com.familyhvac.views;

import com.familyhvac.controllers.TechnicianListController;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Technician list screen shown under the "Technicians" sidebar item.
 * Contains no business logic and no SQL - it only exposes getters for its
 * table/fields/buttons. All behavior lives in {@link TechnicianListController}.
 */
public class TechnicianPanel extends JPanel {

    private JTable technicianTable;
    private TechnicianTableModel tableModel;
    private JTextField searchField;
    private JCheckBox showArchivedCheckBox;
    private JButton addButton;
    private JButton editButton;
    private JButton profileButton;
    private JButton archiveButton;
    private JButton refreshButton;

    public TechnicianPanel() {
        buildUI();
        new TechnicianListController(this);
    }

    private void buildUI() {
        setLayout(new BorderLayout());
        setBackground(UITheme.COLOR_BACKGROUND);
        setBorder(PageLayoutSupport.pagePadding());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTable(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(UITheme.COLOR_BACKGROUND);
        header.setBorder(new EmptyBorder(0, 0, UITheme.SPACING_MD, 0));

        JPanel title = PageLayoutSupport.titleBlock("Technicians", "Maintain technician profiles and review their outstanding job payouts.");
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel toolbar = buildToolbar();
        toolbar.setAlignmentX(Component.LEFT_ALIGNMENT);
        toolbar.setBorder(new EmptyBorder(UITheme.SPACING_MD, 0, 0, 0));

        header.add(title);
        header.add(toolbar);
        return header;
    }

    private JPanel buildToolbar() {
        JPanel toolbar = PageLayoutSupport.toolbarSurface();

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        searchPanel.setOpaque(false);

        searchField = PageLayoutSupport.searchField("Search by name or phone");

        showArchivedCheckBox = new JCheckBox("Show Archived");
        showArchivedCheckBox.setFont(UITheme.FONT_LABEL);
        showArchivedCheckBox.setOpaque(false);
        showArchivedCheckBox.setFocusPainted(false);
        showArchivedCheckBox.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        searchPanel.add(searchField);
        searchPanel.add(showArchivedCheckBox);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttonPanel.setOpaque(false);

        refreshButton = createSecondaryButton("Refresh");
        editButton = createSecondaryButton("Edit");
        editButton.setEnabled(false);
        profileButton = createSecondaryButton("Profile");
        profileButton.setEnabled(false);
        archiveButton = createSecondaryButton("Archive");
        archiveButton.setEnabled(false);
        addButton = UITheme.createPrimaryButton("+ Add Technician");

        buttonPanel.add(refreshButton);
        buttonPanel.add(editButton);
        buttonPanel.add(profileButton);
        buttonPanel.add(archiveButton);
        buttonPanel.add(addButton);

        toolbar.add(searchPanel, BorderLayout.WEST);
        toolbar.add(buttonPanel, BorderLayout.EAST);
        return toolbar;
    }

    private JButton createSecondaryButton(String text) {
        return UITheme.createSecondaryButton(text);
    }

    private JScrollPane buildTable() {
        tableModel = new TechnicianTableModel();
        technicianTable = new JTable(tableModel);
        technicianTable.setFont(UITheme.FONT_BODY);
        technicianTable.setRowHeight(36);
        technicianTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        technicianTable.setAutoCreateRowSorter(true);
        technicianTable.getTableHeader().setFont(UITheme.FONT_LABEL);
        technicianTable.setFillsViewportHeight(true);
        javax.swing.table.DefaultTableCellRenderer currency = new javax.swing.table.DefaultTableCellRenderer();
        currency.setHorizontalAlignment(SwingConstants.CENTER);
        technicianTable.getColumnModel().getColumn(4).setCellRenderer(currency);

        return PageLayoutSupport.tableSurface(technicianTable);
    }

    public JTable getTechnicianTable() {
        return technicianTable;
    }

    public TechnicianTableModel getTableModel() {
        return tableModel;
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public JCheckBox getShowArchivedCheckBox() {
        return showArchivedCheckBox;
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getEditButton() {
        return editButton;
    }
    public JButton getProfileButton() { return profileButton; }

    public JButton getArchiveButton() {
        return archiveButton;
    }

    public JButton getRefreshButton() {
        return refreshButton;
    }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public boolean confirm(String message, String title) {
        int result = JOptionPane.showConfirmDialog(this, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }
}
