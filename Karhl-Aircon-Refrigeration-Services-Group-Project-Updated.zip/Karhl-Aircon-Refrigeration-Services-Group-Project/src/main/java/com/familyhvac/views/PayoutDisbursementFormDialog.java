package com.familyhvac.views;

import com.familyhvac.controllers.PayoutDisbursementFormController;
import com.familyhvac.models.TechnicianPayoutDisbursement;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import java.awt.*;

/** Records one release against a technician's approved job payout. */
public class PayoutDisbursementFormDialog extends JDialog {
    private DatePickerField date;
    private JTextField amount, reference, remarks;
    private JComboBox<TechnicianPayoutDisbursement.DisbursementType> type;
    private JComboBox<TechnicianPayoutDisbursement.PaymentMethod> method;
    private JLabel error;
    private JButton save;

    public PayoutDisbursementFormDialog(Dialog owner, int payoutId) {
        super(owner, "Record Payout Disbursement", true);
        build();
        new PayoutDisbursementFormController(this, payoutId);
    }

    private void build() {
        setSize(520, 570);
        setMinimumSize(new Dimension(450, 490));
        setLocationRelativeTo(getOwner());
        error = FormDialogSupport.errorLabel();
        date = new DatePickerField(true);
        amount = new JTextField();
        type = new JComboBox<>(TechnicianPayoutDisbursement.DisbursementType.values());
        method = new JComboBox<>(TechnicianPayoutDisbursement.PaymentMethod.values());
        reference = new JTextField();
        remarks = new JTextField();
        JPanel body = FormDialogSupport.formStack(error,
                FormDialogSupport.field("Disbursement date * (DD-MM-YYYY)", date),
                FormDialogSupport.field("Amount released *", amount),
                FormDialogSupport.field("Release type", type),
                FormDialogSupport.field("Payment method", method),
                FormDialogSupport.field("Reference number", reference),
                FormDialogSupport.field("Remarks", remarks));
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener(e -> dispose());
        save = UITheme.createPrimaryButton("Record Release");
        setContentPane(FormDialogSupport.dialogRoot("Record payout release",
                "This reduces the technician's remaining approved payout balance.", body,
                FormDialogSupport.actionRow(cancel, save)));
    }

    public java.time.LocalDate getDate() { return date.getDate(); }
    public String getAmount() { return amount.getText(); }
    public TechnicianPayoutDisbursement.DisbursementType getSelectedDisbursementType() { return (TechnicianPayoutDisbursement.DisbursementType) type.getSelectedItem(); }
    public TechnicianPayoutDisbursement.PaymentMethod getMethod() { return (TechnicianPayoutDisbursement.PaymentMethod) method.getSelectedItem(); }
    public String getReference() { return reference.getText(); }
    public String getRemarks() { return remarks.getText(); }
    public JButton getSaveButton() { return save; }
    public void showError(String value) { error.setText(value); }
    public void closeDialog() { dispose(); }
}
