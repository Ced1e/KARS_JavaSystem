package com.familyhvac.views;

import com.familyhvac.controllers.DashboardController;
import com.familyhvac.utils.RoundedPanel;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Live operational overview; values are loaded fresh by its controller. */
public class DashboardPanel extends JPanel {
    private JLabel totalBusinessEarnings, totalReceivable, cleanReceivable, unpaidJobs, pendingPayouts, pendingPayoutsNote, upcomingJobs;
    private BusinessTrendChart workloadChart, revenueChart;
    private JComboBox<String> activityRange;
    private Runnable pendingPayoutsAction;
    private JButton refresh;

    public DashboardPanel() {
        setLayout(new BorderLayout(0, 24));
        setBackground(UITheme.COLOR_BACKGROUND);
        setBorder(PageLayoutSupport.pagePadding());

        add(buildHeader(), BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(2, 3, 18, 18));
        cards.setOpaque(false);
        cards.setMaximumSize(new Dimension(Integer.MAX_VALUE, 300));
        cards.setPreferredSize(new Dimension(900, 300));
        totalBusinessEarnings = metricCard(cards, "Total Business Earnings (All-Time)", "Fully paid jobs: received payments less expenses and technician payouts");
        totalReceivable = metricCard(cards, "Total Business Receivable", "Client balances not yet paid");
        cleanReceivable = metricCard(cards, "Clean Receivable", "Unpaid job balances less their expenses and technician payouts");
        unpaidJobs = metricCard(cards, "<html>Jobs Awaiting<br>Payment</html>", "Unpaid or partially paid jobs");
        pendingPayouts = clickableMetricCard(cards, "<html>Technician payouts<br>to release</html>");
        upcomingJobs = metricCard(cards, "Upcoming Jobs", "Scheduled jobs after today");
        JPanel workspace = new JPanel();
        workspace.setLayout(new BoxLayout(workspace, BoxLayout.Y_AXIS));
        workspace.setOpaque(false);
        workspace.add(cards);
        workspace.add(Box.createVerticalStrut(UITheme.SPACING_LG));
        workspace.add(buildTrendSection());
        workspace.add(Box.createVerticalGlue());
        add(workspace, BorderLayout.CENTER);

        new DashboardController(this);
    }

    private JComponent buildTrendSection() {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setOpaque(false);
        JPanel heading = new JPanel(new BorderLayout());
        heading.setOpaque(false);
        JPanel text = new JPanel(); text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS)); text.setOpaque(false);
        JLabel title = new JLabel("Business activity"); title.setFont(UITheme.FONT_BUTTON); title.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        JLabel note = new JLabel("Scheduled work and expected net revenue from your first recorded job onward."); note.setFont(UITheme.FONT_LABEL); note.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        text.add(title); text.add(Box.createVerticalStrut(4)); text.add(note);
        activityRange = new JComboBox<>(new String[]{"Monthly", "Weekly", "Yearly"});
        activityRange.setFont(UITheme.FONT_BODY);
        activityRange.setPreferredSize(new Dimension(130, 36));
        heading.add(text, BorderLayout.WEST); heading.add(activityRange, BorderLayout.EAST);
        JPanel charts = new JPanel(new GridLayout(1, 2, UITheme.SPACING_MD, 0)); charts.setOpaque(false);
        workloadChart = new BusinessTrendChart(BusinessTrendChart.Metric.WORKLOAD);
        revenueChart = new BusinessTrendChart(BusinessTrendChart.Metric.REVENUE);
        charts.add(trendCard("Workload Trend", "Scheduled jobs per period", workloadChart));
        charts.add(trendCard("Expected Revenue Trend", "Expected net revenue per period", revenueChart));
        section.add(heading); section.add(Box.createVerticalStrut(UITheme.SPACING_MD)); section.add(charts);
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 380));
        return section;
    }

    private JComponent trendCard(String title, String note, JComponent chart) {
        RoundedPanel card = new RoundedPanel(new BorderLayout(0, 8), 14, true);
        card.setBackground(UITheme.COLOR_CARD_BG); card.setBorder(new EmptyBorder(16, 18, 14, 18));
        JPanel heading = new JPanel(); heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS)); heading.setOpaque(false);
        JLabel titleLabel = new JLabel(title); titleLabel.setFont(UITheme.FONT_BUTTON); titleLabel.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        JLabel noteLabel = new JLabel(note); noteLabel.setFont(UITheme.FONT_LABEL); noteLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        heading.add(titleLabel); heading.add(Box.createVerticalStrut(3)); heading.add(noteLabel);
        card.add(heading, BorderLayout.NORTH); card.add(chart, BorderLayout.CENTER);
        return card;
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel title = new JPanel();
        title.setLayout(new BoxLayout(title, BoxLayout.Y_AXIS));
        title.setOpaque(false);
        title.add(UITheme.createSectionTitle("Business Overview"));
        title.add(Box.createVerticalStrut(5));
        JLabel subtitle = new JLabel("Prioritize scheduled work, outstanding client payments, and technician obligations.");
        subtitle.setFont(UITheme.FONT_SUBTITLE);
        subtitle.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        title.add(subtitle);

        refresh = UITheme.createPrimaryButton("Refresh");
        refresh.setPreferredSize(new Dimension(105, 38));
        header.add(title, BorderLayout.WEST);
        header.add(refresh, BorderLayout.EAST);
        return header;
    }

    private JLabel metricCard(JPanel parent, String title) {
        return metricCard(parent, title, null);
    }

    private JLabel metricCard(JPanel parent, String title, String subtext) {
        RoundedPanel card = new RoundedPanel(new BorderLayout(), 14, true);
        card.setBackground(UITheme.COLOR_CARD_BG);
        card.setBorder(new EmptyBorder(18, 22, 22, 22));

        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.setOpaque(false);
        JLabel caption = new JLabel(title);
        caption.setFont(UITheme.FONT_LABEL);
        caption.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        JLabel value = new JLabel("—");
        value.setFont(UITheme.FONT_CARD_VALUE);
        value.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        value.setBorder(new EmptyBorder(14, 0, 0, 0));
        text.add(caption);
        text.add(value);
        if (subtext != null) {
            JLabel note = new JLabel(subtext);
            note.setFont(UITheme.FONT_LABEL.deriveFont(11f));
            note.setForeground(UITheme.COLOR_TEXT_SECONDARY);
            note.setBorder(new EmptyBorder(5, 0, 0, 0));
            text.add(note);
        }

        card.add(text, BorderLayout.CENTER);
        parent.add(card);
        return value;
    }

    private JLabel clickableMetricCard(JPanel parent, String title) {
        RoundedPanel card = new RoundedPanel(new BorderLayout(), 14, true);
        card.setBackground(UITheme.COLOR_CARD_BG);
        card.setBorder(new EmptyBorder(18, 22, 22, 22));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.setOpaque(false);
        text.setCursor(card.getCursor());
        JLabel caption = new JLabel(title);
        caption.setFont(UITheme.FONT_LABEL);
        caption.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        JLabel value = new JLabel("—");
        value.setFont(UITheme.FONT_CARD_VALUE);
        value.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        value.setBorder(new EmptyBorder(14, 0, 0, 0));
        pendingPayoutsNote = new JLabel("Click to review pending payout records");
        pendingPayoutsNote.setFont(UITheme.FONT_LABEL.deriveFont(11f));
        pendingPayoutsNote.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        pendingPayoutsNote.setBorder(new EmptyBorder(5, 0, 0, 0));
        text.add(caption); text.add(value); text.add(pendingPayoutsNote); card.add(text, BorderLayout.CENTER);
        java.awt.event.MouseAdapter click = new java.awt.event.MouseAdapter() { @Override public void mouseClicked(java.awt.event.MouseEvent e) { if (pendingPayoutsAction != null) pendingPayoutsAction.run(); } };
        card.addMouseListener(click); text.addMouseListener(click); caption.addMouseListener(click); value.addMouseListener(click); pendingPayoutsNote.addMouseListener(click);
        parent.add(card);
        return value;
    }

    public JButton getRefreshButton() { return refresh; }
    public void setPendingPayoutsAction(Runnable action) { pendingPayoutsAction = action; }

    public void setMetrics(double businessEarnings, double receivable, double cleanReceivableAmount, int unpaidJobCount, int payoutCount, double payoutAmount, int upcomingJobCount) {
        totalBusinessEarnings.setText(money(businessEarnings));
        totalReceivable.setText(money(receivable));
        cleanReceivable.setText(money(cleanReceivableAmount));
        unpaidJobs.setText(String.valueOf(unpaidJobCount));
        pendingPayouts.setText(money(payoutAmount));
        pendingPayoutsNote.setText("Across " + payoutCount + " pending payout" + (payoutCount == 1 ? "" : "s"));
        upcomingJobs.setText(String.valueOf(upcomingJobCount));
    }

    public JComboBox<String> getActivityRangeSelector() { return activityRange; }
    public com.familyhvac.dao.AnalyticsDAO.ActivityRange getActivityRange() { return com.familyhvac.dao.AnalyticsDAO.ActivityRange.valueOf(((String) activityRange.getSelectedItem()).toUpperCase()); }
    public void setActivityTrend(java.util.List<com.familyhvac.dao.AnalyticsDAO.ActivityPoint> trend) { workloadChart.setPoints(trend); revenueChart.setPoints(trend); }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Dashboard", JOptionPane.ERROR_MESSAGE);
    }

    private String money(double value) { return String.format("₱%,.2f", value); }
}
