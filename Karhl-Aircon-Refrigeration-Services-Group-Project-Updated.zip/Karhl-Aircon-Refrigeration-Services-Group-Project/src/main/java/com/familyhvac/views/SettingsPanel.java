package com.familyhvac.views;

import com.familyhvac.controllers.SettingsController;
import com.familyhvac.utils.AppConstants;
import com.familyhvac.utils.RoundedPanel;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Business identity, local storage information, and a safe database backup action. */
public class SettingsPanel extends JPanel {
    private JButton backupButton;
    private JButton restoreButton;
    private JLabel backupStatus;
    private JComboBox<UITheme.ThemeMode> themeMode;
    private JLabel themeStatus;

    public SettingsPanel() {
        buildUI();
        new SettingsController(this);
    }

    private void buildUI() {
        setLayout(new BorderLayout());
        setBackground(UITheme.COLOR_BACKGROUND);
        setBorder(PageLayoutSupport.pagePadding());
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);
        content.add(PageLayoutSupport.titleBlock("Settings", "Review your business workspace and protect its locally stored records."));
        content.add(Box.createVerticalStrut(22));
        content.add(card("Business Profile", AppConstants.APP_NAME, "Davao, Philippines", "Job-based contractor management system"));
        content.add(Box.createVerticalStrut(16));
        content.add(card("Data Storage", "Database: " + AppConstants.DB_FILE_NAME, "Location: " + AppConstants.DB_DIRECTORY));
        content.add(Box.createVerticalStrut(16));
        content.add(themeCard());
        content.add(Box.createVerticalStrut(16));
        content.add(backupCard());
        add(content, BorderLayout.NORTH);
    }

    private JComponent themeCard() {
        RoundedPanel card = new RoundedPanel(new BorderLayout(16, 0), 14, false);
        card.setBackground(UITheme.COLOR_CARD_BG); card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130)); card.setBorder(new EmptyBorder(18, 20, 18, 20));
        JPanel text = new JPanel(); text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS)); text.setOpaque(false);
        JLabel title = new JLabel("Appearance"); title.setFont(UITheme.FONT_BUTTON);
        JLabel detail = new JLabel("Choose Light, Gray, or Dark mode. Restart the app after saving your choice."); detail.setFont(UITheme.FONT_BODY); detail.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        themeStatus = new JLabel("Current mode: " + UITheme.getThemeMode()); themeStatus.setFont(UITheme.FONT_LABEL); themeStatus.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        text.add(title); text.add(Box.createVerticalStrut(7)); text.add(detail); text.add(Box.createVerticalStrut(7)); text.add(themeStatus);
        themeMode = new JComboBox<>(UITheme.ThemeMode.values()); themeMode.setSelectedItem(UITheme.getThemeMode()); themeMode.setPreferredSize(new Dimension(130, 36));
        card.add(text, BorderLayout.WEST); card.add(themeMode, BorderLayout.EAST); return card;
    }

    private JComponent card(String heading, String... details) {
        RoundedPanel card = new RoundedPanel(new BorderLayout(), 14, false);
        card.setBackground(UITheme.COLOR_CARD_BG);
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150));
        card.setBorder(new EmptyBorder(18, 20, 18, 20));
        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.setOpaque(false);
        JLabel title = new JLabel(heading);
        title.setFont(UITheme.FONT_BUTTON);
        text.add(title);
        text.add(Box.createVerticalStrut(8));
        for (String detail : details) {
            JLabel label = new JLabel(detail);
            label.setFont(UITheme.FONT_BODY);
            label.setForeground(UITheme.COLOR_TEXT_SECONDARY);
            text.add(label);
        }
        card.add(text, BorderLayout.WEST);
        return card;
    }

    private JComponent backupCard() {
        RoundedPanel card = new RoundedPanel(new BorderLayout(), 14, false);
        card.setBackground(UITheme.COLOR_CARD_BG);
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 185));
        card.setBorder(new EmptyBorder(18, 20, 18, 20));
        JPanel text = new JPanel();
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.setOpaque(false);
        JLabel title = new JLabel("Data Backup");
        title.setFont(UITheme.FONT_BUTTON);
        JLabel description = new JLabel("<html>Create dated backups and restore a selected backup when needed.<br>Restoring creates a safety copy first and requires a restart.</html>");
        description.setFont(UITheme.FONT_BODY);
        description.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        backupStatus = new JLabel(" ");
        backupStatus.setFont(UITheme.FONT_LABEL);
        text.add(title); text.add(Box.createVerticalStrut(8)); text.add(description); text.add(Box.createVerticalStrut(8)); text.add(backupStatus);
        backupButton = UITheme.createPrimaryButton("Create Database Backup");
        restoreButton = UITheme.createSecondaryButton("Restore Backup...");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); actions.setOpaque(false); actions.setBorder(new EmptyBorder(18, 0, 18, 0)); actions.add(restoreButton); actions.add(backupButton);
        card.add(text, BorderLayout.WEST);
        card.add(actions, BorderLayout.EAST);
        return card;
    }

    public JButton getBackupButton() { return backupButton; }
    public JButton getRestoreButton() { return restoreButton; }
    public JComboBox<UITheme.ThemeMode> getThemeMode() { return themeMode; }
    public void setThemeStatus(String text) { themeStatus.setText(text); }
    public void setBackupStatus(String text, boolean error) { backupStatus.setText(text); backupStatus.setForeground(error ? UITheme.COLOR_DANGER : UITheme.COLOR_SUCCESS); }
    public boolean confirmRestore(String message) { return JOptionPane.showConfirmDialog(this, message, "Restore Database Backup", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION; }
    public void showError(String message) { JOptionPane.showMessageDialog(this, message, "Settings", JOptionPane.ERROR_MESSAGE); }
}
