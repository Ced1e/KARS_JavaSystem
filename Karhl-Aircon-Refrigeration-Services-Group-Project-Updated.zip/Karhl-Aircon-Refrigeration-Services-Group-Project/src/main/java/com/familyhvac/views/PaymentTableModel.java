package com.familyhvac.views;

import com.familyhvac.models.Payment;
import com.familyhvac.utils.DateSupport;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/**
 * Adapts a list of {@link Payment} objects for display in a JTable. Kept
 * read-only - all edits happen through {@link PaymentFormDialog}.
 */
public class PaymentTableModel extends AbstractTableModel {

    private static final String[] COLUMN_NAMES = {
            "Date", "Type", "Reference", "Amount"
    };

    private List<Payment> payments = new ArrayList<>();

    public void setPayments(List<Payment> payments) {
        this.payments = payments != null ? payments : new ArrayList<>();
        fireTableDataChanged();
    }

    public Payment getPaymentAt(int rowIndex) {
        return payments.get(rowIndex);
    }

    @Override
    public int getRowCount() {
        return payments.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return COLUMN_NAMES[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Payment payment = payments.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> DateSupport.display(payment.getPaymentDate());
            case 1 -> payment.getPaymentType().getDisplayLabel();
            case 2 -> nullToDash(payment.getReferenceNumber());
            case 3 -> "\u20B1" + String.format("%,.2f", payment.getAmount());
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    private String nullToDash(String value) {
        return (value == null || value.isBlank()) ? "-" : value;
    }
}
