package com.familyhvac.views;

import com.familyhvac.controllers.TechnicianFormController;
import com.familyhvac.models.Technician;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Add/Edit form for a technician. Contains no business logic and no SQL -
 * it only exposes getters for its fields and a showError/closeDialog
 * pair. All behavior lives in {@link TechnicianFormController}.
 *
 * When constructed with a null {@code existingTechnician}, this is an
 * "Add" dialog; otherwise it's an "Edit" dialog pre-populated from that
 * technician.
 */
public class TechnicianFormDialog extends JDialog {

    private final Technician existingTechnician;

    private JTextField nameField;
    private JTextField phoneField;
    private JTextArea notesArea;
    private JLabel errorLabel;
    private JButton saveButton;
    private JButton cancelButton;

    public TechnicianFormDialog(Frame owner, Technician existingTechnician) {
        super(owner, existingTechnician == null ? "Add Technician" : "Edit Technician", true);
        this.existingTechnician = existingTechnician;
        buildUI();
        populateFieldsIfEditing();
        new TechnicianFormController(this, existingTechnician);
    }

    private void buildUI() {
        setSize(500, 470);
        setMinimumSize(new Dimension(440, 410));
        setLocationRelativeTo(getOwner());

        errorLabel = FormDialogSupport.errorLabel();

        nameField = new JTextField();
        phoneField = new JTextField();

        addClearValidationOnEdit(nameField);

        notesArea = new JTextArea(4, 20);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);

        JPanel body = FormDialogSupport.formStack(errorLabel,
                FormDialogSupport.field("Technician name *", nameField),
                FormDialogSupport.field("Phone", phoneField), labeledArea("Notes", notesArea));
        setContentPane(FormDialogSupport.dialogRoot(existingTechnician == null ? "Add technician" : "Edit technician",
                "Maintain the technician's profile and contact details.", body, buildButtonRow()));
    }

    private JPanel labeledField(String label, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(UITheme.FONT_LABEL);
        labelComponent.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        labelComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        field.setFont(UITheme.FONT_BODY);
        if (field instanceof JTextField textField) {
            textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                    new EmptyBorder(4, 8, 4, 8)
            ));
        }

        panel.add(labelComponent);
        panel.add(Box.createVerticalStrut(4));
        panel.add(field);
        return panel;
    }

    private JPanel labeledArea(String label, JTextArea area) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(UITheme.FONT_LABEL);
        labelComponent.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        labelComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

        area.setFont(UITheme.FONT_BODY);
        area.setBorder(new EmptyBorder(4, 8, 4, 8));

        JScrollPane scrollPane = new JScrollPane(area);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true));

        panel.add(labelComponent);
        panel.add(Box.createVerticalStrut(4));
        panel.add(scrollPane);
        return panel;
    }

    private JPanel buildButtonRow() {
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        saveButton = UITheme.createPrimaryButton("Save");
        return FormDialogSupport.actionRow(cancelButton, saveButton);
    }

    private void populateFieldsIfEditing() {
        if (existingTechnician == null) {
            return;
        }
        nameField.setText(existingTechnician.getName());
        phoneField.setText(existingTechnician.getPhoneNumber());
        notesArea.setText(existingTechnician.getNotes());
    }

    /** Puts a red border on the given field to flag it as invalid. */
    public void markFieldInvalid(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_DANGER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }

    /** Restores the given field's border to its normal (non-error) style. */
    public void clearFieldValidation(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }

    /** Clears a field's red "invalid" border as soon as the user edits it again. */
    private void addClearValidationOnEdit(JTextField field) {
        field.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }
        });
    }

    /**
     * Shows a non-blocking "a similar technician may already exist"
     * warning listing up to 5 matches, and asks the user whether to
     * continue saving anyway. Returns true if the user chooses to proceed.
     */
    public boolean confirmDespiteSimilarTechnicians(java.util.List<Technician> similarTechnicians) {
        StringBuilder message = new StringBuilder(
                "A technician with a similar name may already exist:\n\n");
        int shown = 0;
        for (Technician similar : similarTechnicians) {
            if (shown >= 5) {
                message.append("...and ").append(similarTechnicians.size() - shown).append(" more\n");
                break;
            }
            message.append("  \u2022 ").append(similar.getTechnicianCode())
                    .append(" - ").append(similar.getName()).append('\n');
            shown++;
        }
        message.append("\nDo you want to continue saving this technician anyway?");

        int result = JOptionPane.showConfirmDialog(
                this, message.toString(), "Possible Duplicate Technician",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }

    public JTextField getNameField() {
        return nameField;
    }

    public String getNameInput() {
        return nameField.getText();
    }

    public String getPhoneInput() {
        return phoneField.getText();
    }

    public String getNotesInput() {
        return notesArea.getText();
    }

    public JButton getSaveButton() {
        return saveButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public void showError(String message) {
        errorLabel.setText(message);
    }

    public void closeDialog() {
        dispose();
    }
}
