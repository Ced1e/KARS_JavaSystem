package com.familyhvac.views;

import com.familyhvac.controllers.TechnicianPayoutFormController;
import com.familyhvac.models.Technician;
import com.familyhvac.models.TechnicianPayout;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Form for a job assignment and its manually negotiated payout. */
public class TechnicianPayoutFormDialog extends JDialog {
    private JComboBox<Technician> technician;
    private JCheckBox lead;
    private JComboBox<TechnicianPayout.PayoutMethod> method;
    private JTextField percentage, approved, remarks;
    private DatePickerField date;
    private JLabel error;
    private JButton save;

    public TechnicianPayoutFormDialog(Dialog owner, int jobId, TechnicianPayout existing) {
        super(owner, existing == null ? "Assign Technician" : "Edit Technician Payout", true);
        build(existing == null);
        fill(existing);
        new TechnicianPayoutFormController(this, jobId, existing);
    }

    private void build(boolean isNew) {
        setSize(540, 600);
        setMinimumSize(new Dimension(470, 520));
        setLocationRelativeTo(getOwner());

        error = FormDialogSupport.errorLabel();
        technician = new JComboBox<>();
        lead = new JCheckBox("Lead technician on this job");
        lead.setBackground(UITheme.COLOR_CARD_BG);
        lead.setFont(UITheme.FONT_BODY);
        method = new JComboBox<>(TechnicianPayout.PayoutMethod.values());
        percentage = new JTextField();
        approved = new JTextField();
        date = new DatePickerField(false);
        remarks = new JTextField();

        JLabel guidance = new JLabel("The share amount increases the technician's outstanding payout; releases reduce it.");
        guidance.setFont(UITheme.FONT_LABEL);
        guidance.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        guidance.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel body = FormDialogSupport.formStack(error,
                FormDialogSupport.field("Technician *", technician),
                FormDialogSupport.field("", lead),
                FormDialogSupport.field("Discussed method", method),
                FormDialogSupport.field("Discussed percentage (reference only)", percentage),
                FormDialogSupport.field("Technician share amount *", approved),
                FormDialogSupport.field("Negotiated date (DD-MM-YYYY)", date),
                FormDialogSupport.field("Remarks", remarks), guidance);

        JButton cancel = new JButton("Cancel");
        cancel.addActionListener(e -> dispose());
        save = UITheme.createPrimaryButton(isNew ? "Assign" : "Save Changes");
        setContentPane(FormDialogSupport.dialogRoot(isNew ? "Assign technician" : "Edit technician payout",
                "Record the agreed share for this specific job.", body, FormDialogSupport.actionRow(cancel, save)));
    }

    private void fill(TechnicianPayout payout) {
        if (payout == null) return;
        lead.setSelected(payout.isLead());
        method.setSelectedItem(payout.getPayoutMethod());
        percentage.setText(payout.getPercentageValue() == null ? "" : payout.getPercentageValue().toString());
        approved.setText(payout.getApprovedAmount() == null ? "" : payout.getApprovedAmount().toString());
        date.setStoredDate(payout.getNegotiatedAt());
        remarks.setText(payout.getRemarks());
    }

    public void setTechnicians(List<Technician> list) {
        DefaultComboBoxModel<Technician> model = new DefaultComboBoxModel<>();
        for (Technician item : list) model.addElement(item);
        technician.setModel(model);
    }
    public void selectTechnician(int id) { for (int i = 0; i < technician.getItemCount(); i++) if (technician.getItemAt(i).getId() == id) technician.setSelectedIndex(i); }
    public Technician getTechnician() { return (Technician) technician.getSelectedItem(); }
    public boolean isLead() { return lead.isSelected(); }
    public TechnicianPayout.PayoutMethod getMethod() { return (TechnicianPayout.PayoutMethod) method.getSelectedItem(); }
    public String getPercentage() { return percentage.getText(); }
    public String getApproved() { return approved.getText(); }
    public java.time.LocalDate getDate() { return date.getDate(); }
    public String getRemarks() { return remarks.getText(); }
    public JButton getSaveButton() { return save; }
    public void showError(String value) { error.setText(value); }
    public void closeDialog() { dispose(); }
}
