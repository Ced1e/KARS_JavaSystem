package com.familyhvac.views;

import com.familyhvac.utils.RoundedPanel;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/** Reusable visual structure for the application's main list screens. */
final class PageLayoutSupport {
    private PageLayoutSupport() { }

    /** Shared page spacing keeps every tab aligned to the same content grid. */
    static EmptyBorder pagePadding() { return new EmptyBorder(36, 38, 32, 38); }

    static JPanel titleBlock(String title, String subtitle) {
        JPanel block = new JPanel();
        block.setLayout(new BoxLayout(block, BoxLayout.Y_AXIS));
        block.setOpaque(false);
        block.setAlignmentX(Component.LEFT_ALIGNMENT);
        block.setMaximumSize(new Dimension(Integer.MAX_VALUE, 72));
        JLabel heading = UITheme.createSectionTitle(title);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        block.add(heading);
        block.add(Box.createVerticalStrut(7));
        JLabel description = new JLabel(subtitle);
        description.setFont(UITheme.FONT_SUBTITLE);
        description.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        description.setAlignmentX(Component.LEFT_ALIGNMENT);
        block.add(description);
        return block;
    }

    static RoundedPanel toolbarSurface() {
        RoundedPanel panel = new RoundedPanel(new BorderLayout(), 14, false);
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setBorder(new EmptyBorder(10, 12, 10, 12));
        return panel;
    }

    static JScrollPane tableSurface(JTable table) {
        centerTableContents(table);
        table.setRowHeight(36);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.getTableHeader().setPreferredSize(new Dimension(0, 38));
        JScrollPane pane = new JScrollPane(table);
        pane.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true));
        pane.getViewport().setBackground(UITheme.COLOR_CARD_BG);
        return pane;
    }

    /** Consistent centered presentation for data tables throughout the application. */
    static void centerTableContents(JTable table) {
        DefaultTableCellRenderer body = new DefaultTableCellRenderer();
        body.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, body);
        table.setDefaultRenderer(String.class, body);
        table.setDefaultRenderer(Number.class, body);
        table.setDefaultRenderer(Integer.class, body);
        table.setDefaultRenderer(Double.class, body);
        DefaultTableCellRenderer header = new DefaultTableCellRenderer();
        header.setHorizontalAlignment(SwingConstants.CENTER);
        header.setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD));
        header.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        header.setBackground(UITheme.COLOR_CARD_BG);
        table.getTableHeader().setDefaultRenderer(header);
    }

    static JTextField searchField(String hint) {
        JTextField field = new JTextField(22);
        field.setFont(UITheme.FONT_BODY);
        field.setToolTipText(hint);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                new EmptyBorder(7, 11, 7, 11)));
        return field;
    }
}
