package com.familyhvac.views;

import com.familyhvac.models.Job;
import com.familyhvac.utils.DateSupport;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Adapts a list of {@link Job} objects for display in a JTable. A Job
 * only stores client_id/service_category_id, not names, so the
 * controller supplies name-lookup maps (built from ClientService and
 * ServiceCategoryService) alongside the jobs themselves. Kept read-only -
 * all edits happen through {@link JobFormDialog}.
 */
public class JobTableModel extends AbstractTableModel {

    private static final String[] COLUMN_NAMES = {
            "Job Code", "Client", "Date", "Category", "Status", "Expenses", "Payouts"
    };

    private List<Job> jobs = new ArrayList<>();
    private Map<Integer, String> clientNamesById = new HashMap<>();
    private Map<Integer, String> categoryNamesById = new HashMap<>();
    private Map<Integer, Double> expensesByJob = new HashMap<>();
    private Map<Integer, Double> payoutsByJob = new HashMap<>();

    public void setJobs(List<Job> jobs, Map<Integer, String> clientNamesById, Map<Integer, String> categoryNamesById, Map<Integer, Double> expensesByJob, Map<Integer, Double> payoutsByJob) {
        this.jobs = jobs != null ? jobs : new ArrayList<>();
        this.clientNamesById = clientNamesById != null ? clientNamesById : new HashMap<>();
        this.categoryNamesById = categoryNamesById != null ? categoryNamesById : new HashMap<>();
        this.expensesByJob = expensesByJob != null ? expensesByJob : new HashMap<>();
        this.payoutsByJob = payoutsByJob != null ? payoutsByJob : new HashMap<>();
        fireTableDataChanged();
    }

    public Job getJobAt(int rowIndex) {
        return jobs.get(rowIndex);
    }

    @Override
    public int getRowCount() {
        return jobs.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return COLUMN_NAMES[column];
    }

    @Override public Class<?> getColumnClass(int column) { return column >= 5 ? Double.class : String.class; }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Job job = jobs.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> job.getJobCode();
            case 1 -> clientNamesById.getOrDefault(job.getClientId(), "Unknown");
            case 2 -> DateSupport.display(job.getJobDate());
            case 3 -> job.getServiceCategoryId() != null
                    ? categoryNamesById.getOrDefault(job.getServiceCategoryId(), "-")
                    : "-";
            case 4 -> formatStatus(job.getJobStatus());
            case 5 -> expensesByJob.getOrDefault(job.getId(), 0.0);
            case 6 -> payoutsByJob.getOrDefault(job.getId(), 0.0);
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    /** SCHEDULED -> "Scheduled", IN_PROGRESS -> "In Progress", etc. */
    private String formatStatus(Job.JobStatus status) {
        String[] words = status.name().split("_");
        StringBuilder builder = new StringBuilder();
        for (String word : words) {
            if (!word.isEmpty()) {
                builder.append(Character.toUpperCase(word.charAt(0)))
                        .append(word.substring(1).toLowerCase())
                        .append(' ');
            }
        }
        return builder.toString().trim();
    }
}
