package com.familyhvac.views;

import com.familyhvac.models.User;
import com.familyhvac.services.AuthService;
import com.familyhvac.utils.AppConstants;
import com.familyhvac.utils.SessionManager;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.RoundedButton;

import javax.swing.*;
import javax.imageio.ImageIO;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The main application window: a sidebar for navigation plus a content
 * area on the right that swaps panels via CardLayout.
 *
 * This class is intentionally a "shell" for now. Each future module
 * (Dashboard, Clients, Jobs, Payments, Expenses, Technicians, Reports,
 * Settings) will register its own panel with {@link #registerPage} and be
 * wired into a sidebar button - no changes to this class's structure will
 * be needed, only additions.
 */
public class MainFrame extends JFrame {

    private static final String NAV_DASHBOARD   = "Dashboard";
    private static final String NAV_CLIENTS     = "Clients";
    private static final String NAV_JOBS        = "Jobs";
    private static final String NAV_SCHEDULE    = "Schedule";
    private static final String NAV_PAYMENTS    = "Payments";
    private static final String NAV_EXPENSES    = "Expenses";
    private static final String NAV_TECHNICIANS = "Technicians";
    private static final String NAV_REPORTS     = "Reports";
    private static final String NAV_SETTINGS    = "Settings";

    private final CardLayout contentLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(contentLayout);
    private final Map<String, JButton> navButtons = new LinkedHashMap<>();

    public MainFrame() {
        super(AppConstants.APP_NAME);
        try (var logo = MainFrame.class.getResourceAsStream("/karhl-logo.png")) {
            java.awt.Image image = ImageIO.read(logo);
            if (image != null) setIconImage(image);
        } catch (Exception ignored) { }
        buildUI();
    }

    private void buildUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1220, 760);
        setMinimumSize(new Dimension(1000, 640));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.add(buildSidebar(), BorderLayout.WEST);
        root.add(buildContentArea(), BorderLayout.CENTER);

        setContentPane(root);

        // Register placeholder pages. Later steps replace these
        // "coming soon" panels with real module panels one at a time.
        DashboardPanel dashboard = new DashboardPanel();
        dashboard.setPendingPayoutsAction(() -> new PendingPayoutsDialog(this).setVisible(true));
        registerPage(NAV_DASHBOARD, dashboard);
        registerPage(NAV_CLIENTS, new ClientPanel());
        registerPage(NAV_JOBS, new JobPanel());
        registerPage(NAV_SCHEDULE, new SchedulePanel());
        registerPage(NAV_PAYMENTS, new PaymentsPanel());
        registerPage(NAV_TECHNICIANS, new TechnicianPanel());
        registerPage(NAV_REPORTS, new ReportsPanel());
        registerPage(NAV_SETTINGS, new SettingsPanel());

        showPage(NAV_DASHBOARD);
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UITheme.COLOR_SIDEBAR_BG);
        sidebar.setPreferredSize(new Dimension(230, 0));
        sidebar.setBorder(new EmptyBorder(22, 14, 20, 14));

        JLabel appName = new JLabel("<html>Karhl Aircon &amp;<br>Refrigeration Services</html>");
        appName.setFont(UITheme.FONT_TITLE.deriveFont(16f));
        appName.setForeground(Color.WHITE);
        appName.setAlignmentX(Component.LEFT_ALIGNMENT);
        appName.setBorder(new EmptyBorder(8, 10, 30, 0));
        sidebar.add(appName);

        String[] navItems = {
                NAV_DASHBOARD, NAV_CLIENTS, NAV_JOBS, NAV_SCHEDULE, NAV_PAYMENTS,
                NAV_TECHNICIANS, NAV_REPORTS, NAV_SETTINGS
        };

        for (String item : navItems) {
            JButton navButton = createNavButton(item);
            navButtons.put(item, navButton);
            sidebar.add(navButton);
            sidebar.add(Box.createVerticalStrut(7));
        }

        sidebar.add(Box.createVerticalGlue());

        User currentUser = SessionManager.getInstance().getCurrentUser();
        String displayName = currentUser != null ? currentUser.getUsername() : "Unknown";

        JLabel userLabel = new JLabel("  Signed in as: " + displayName);
        userLabel.setFont(UITheme.FONT_LABEL);
        userLabel.setForeground(UITheme.COLOR_SIDEBAR_TEXT);
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        userLabel.setBorder(new EmptyBorder(8, 8, 8, 0));
        sidebar.add(userLabel);

        JButton logoutButton = new JButton("Log Out");
        logoutButton.setFont(UITheme.FONT_SIDEBAR);
        logoutButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        logoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        logoutButton.setFocusPainted(false);
        logoutButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutButton.addActionListener(e -> handleLogout());
        sidebar.add(logoutButton);

        return sidebar;
    }

    private JButton createNavButton(String label) {
        JButton button = new RoundedButton(label, 12);
        button.setFont(UITheme.FONT_SIDEBAR);
        button.setForeground(UITheme.COLOR_SIDEBAR_TEXT);
        button.setBackground(UITheme.COLOR_SIDEBAR_BG);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(0, 14, 0, 12));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.addActionListener(e -> showPage(label));
        return button;
    }

    /**
     * The pages already contain their own table/form scrolling. Wrapping the
     * entire CardLayout in another scroll pane created a hidden wider canvas,
     * which pushed right-aligned actions against (or beyond) the visible edge.
     */
    private JPanel buildContentArea() {
        contentPanel.setBackground(UITheme.COLOR_BACKGROUND);
        return contentPanel;
    }

    /**
     * Adds a panel to the content area under the given navigation key.
     * Future modules call this from MainFrame (or MainFrame calls into
     * them) to install their real UI in place of a placeholder.
     */
    public void registerPage(String navKey, JComponent page) {
        contentPanel.add(page, navKey);
    }

    public void showPage(String navKey) {
        contentLayout.show(contentPanel, navKey);
        highlightActiveNav(navKey);
    }

    private void highlightActiveNav(String activeKey) {
        for (Map.Entry<String, JButton> entry : navButtons.entrySet()) {
            boolean isActive = entry.getKey().equals(activeKey);
            entry.getValue().setBackground(isActive ? UITheme.COLOR_SIDEBAR_ACTIVE : UITheme.COLOR_SIDEBAR_BG);
        }
    }

    private JPanel buildPlaceholderPage(String title, String description) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_BACKGROUND);
        panel.setBorder(new EmptyBorder(UITheme.SPACING_LG, UITheme.SPACING_LG, UITheme.SPACING_LG, UITheme.SPACING_LG));

        JLabel titleLabel = UITheme.createSectionTitle(title);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel descLabel = new JLabel(description);
        descLabel.setFont(UITheme.FONT_SUBTITLE);
        descLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        descLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        descLabel.setBorder(new EmptyBorder(8, 0, 0, 0));

        JLabel comingSoon = new JLabel("This module will be built in an upcoming step.");
        comingSoon.setFont(UITheme.FONT_LABEL);
        comingSoon.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        comingSoon.setAlignmentX(Component.LEFT_ALIGNMENT);
        comingSoon.setBorder(new EmptyBorder(16, 0, 0, 0));

        panel.add(titleLabel);
        panel.add(descLabel);
        panel.add(comingSoon);
        return panel;
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(
                this, "Are you sure you want to log out?", "Confirm Logout",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            new AuthService().logout();
            dispose();
            SwingUtilities.invokeLater(() -> new LoginView().setVisible(true));
        }
    }
}
