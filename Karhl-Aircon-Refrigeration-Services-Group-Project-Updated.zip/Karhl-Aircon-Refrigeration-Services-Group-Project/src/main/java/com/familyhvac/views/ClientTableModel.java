package com.familyhvac.views;

import com.familyhvac.models.Client;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/**
 * Adapts a list of {@link Client} objects for display in a JTable. Kept
 * read-only (isCellEditable always false) - all edits happen through
 * {@link ClientFormDialog}, never inline in the table.
 */
public class ClientTableModel extends AbstractTableModel {

    private static final String[] COLUMN_NAMES = {
            "Client Code", "Client Name", "Contact Person", "Phone", "Email", "Payment Method", "Status"
    };

    private List<Client> clients = new ArrayList<>();

    public void setClients(List<Client> clients) {
        this.clients = clients != null ? clients : new ArrayList<>();
        fireTableDataChanged();
    }

    public Client getClientAt(int rowIndex) {
        return clients.get(rowIndex);
    }

    @Override
    public int getRowCount() {
        return clients.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return COLUMN_NAMES[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Client client = clients.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> client.getClientCode();
            case 1 -> client.getClientName();
            case 2 -> nullToDash(client.getContactPerson());
            case 3 -> nullToDash(client.getPhoneNumber());
            case 4 -> nullToDash(client.getEmail());
            case 5 -> client.getPreferredPaymentMethod() != null ? client.getPreferredPaymentMethod().getDisplayLabel() : "-";
            case 6 -> client.isActive() ? "Active" : "Archived";
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    private String nullToDash(String value) {
        return (value == null || value.isBlank()) ? "-" : value;
    }
}
