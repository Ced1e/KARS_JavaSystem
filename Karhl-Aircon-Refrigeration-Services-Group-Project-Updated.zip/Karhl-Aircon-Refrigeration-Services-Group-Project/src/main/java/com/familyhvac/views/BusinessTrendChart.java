package com.familyhvac.views;

import com.familyhvac.dao.AnalyticsDAO.ActivityPoint;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.util.List;

/** A compact, single-metric business chart used by the dashboard. */
final class BusinessTrendChart extends JPanel {
    enum Metric { WORKLOAD, REVENUE }

    private static final Color WORKLOAD_COLOR = new Color(0x25, 0x6D, 0xD7);
    private static final Color REVENUE_COLOR = new Color(0x18, 0x8A, 0x4C);
    private final Metric metric;
    private List<ActivityPoint> points = List.of();

    BusinessTrendChart(Metric metric) {
        this.metric = metric;
        setOpaque(false);
        setPreferredSize(new Dimension(420, 245));
        setToolTipText(" ");
    }

    void setPoints(List<ActivityPoint> values) {
        points = values == null ? List.of() : List.copyOf(values);
        repaint();
    }

    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int width = getWidth(), height = getHeight();
            int left = 46, right = 14, top = 14, bottom = 42;
            int plotWidth = Math.max(1, width - left - right), plotHeight = Math.max(1, height - top - bottom);
            if (points.isEmpty()) { drawEmpty(g, width, height); return; }

            double maximum = metric == Metric.WORKLOAD
                    ? points.stream().mapToInt(ActivityPoint::scheduledJobs).max().orElse(0)
                    : points.stream().mapToDouble(ActivityPoint::expectedEarnings).max().orElse(0);
            maximum = metric == Metric.WORKLOAD ? Math.max(4, Math.ceil(maximum / 4d) * 4d) : roundedMoneyMaximum(maximum);
            drawGrid(g, left, width - right, top, plotHeight, maximum);
            if (metric == Metric.WORKLOAD) drawBars(g, left, top, plotWidth, plotHeight, maximum);
            else drawLine(g, left, top, plotWidth, plotHeight, maximum);
            drawLabels(g, left, width - right, height, plotWidth);
        } finally { g.dispose(); }
    }

    private void drawGrid(Graphics2D g, int left, int right, int top, int plotHeight, double maximum) {
        g.setFont(UITheme.FONT_LABEL.deriveFont(10f));
        for (int step = 0; step <= 4; step++) {
            int y = top + plotHeight * step / 4;
            g.setColor(UITheme.COLOR_BORDER);
            g.drawLine(left, y, right, y);
            g.setColor(UITheme.COLOR_TEXT_SECONDARY);
            double value = maximum * (4 - step) / 4d;
            String label = metric == Metric.WORKLOAD ? String.valueOf((int) Math.round(value)) : shortPeso(value);
            g.drawString(label, left - 8 - g.getFontMetrics().stringWidth(label), y + 4);
        }
    }

    private void drawBars(Graphics2D g, int left, int top, int plotWidth, int plotHeight, double maximum) {
        double slot = plotWidth / (double) points.size();
        int barWidth = Math.max(5, (int) Math.min(28, slot * .62));
        for (int i = 0; i < points.size(); i++) {
            int value = points.get(i).scheduledJobs();
            int barHeight = (int) Math.round(value / maximum * plotHeight);
            int x = (int) Math.round(left + slot * i + (slot - barWidth) / 2d);
            int y = top + plotHeight - barHeight;
            g.setColor(WORKLOAD_COLOR);
            g.fillRoundRect(x, y, barWidth, Math.max(1, barHeight), 7, 7);
        }
    }

    private void drawLine(Graphics2D g, int left, int top, int plotWidth, int plotHeight, double maximum) {
        Path2D line = new Path2D.Double();
        for (int i = 0; i < points.size(); i++) {
            double x = xFor(i, left, plotWidth);
            double y = top + plotHeight - points.get(i).expectedEarnings() / maximum * plotHeight;
            if (i == 0) line.moveTo(x, y); else line.lineTo(x, y);
        }
        g.setColor(REVENUE_COLOR);
        g.setStroke(new BasicStroke(2.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(line);
        for (int i = 0; i < points.size(); i++) {
            int x = (int) Math.round(xFor(i, left, plotWidth));
            int y = (int) Math.round(top + plotHeight - points.get(i).expectedEarnings() / maximum * plotHeight);
            g.setColor(UITheme.COLOR_CARD_BG); g.fillOval(x - 4, y - 4, 8, 8);
            g.setColor(REVENUE_COLOR); g.fillOval(x - 3, y - 3, 6, 6);
        }
    }

    private void drawLabels(Graphics2D g, int left, int right, int height, int plotWidth) {
        g.setColor(UITheme.COLOR_TEXT_SECONDARY);
        g.setFont(UITheme.FONT_LABEL.deriveFont(10f));
        int every = Math.max(1, (points.size() - 1) / 4);
        for (int i = 0; i < points.size(); i++) {
            if (i % every != 0 && i != points.size() - 1) continue;
            String label = points.get(i).label();
            int x = (int) Math.round(xFor(i, left, plotWidth));
            FontMetrics metrics = g.getFontMetrics();
            int bounded = Math.max(left, Math.min(right - metrics.stringWidth(label), x - metrics.stringWidth(label) / 2));
            g.drawString(label, bounded, height - 17);
        }
    }

    @Override public String getToolTipText(MouseEvent event) {
        if (points.isEmpty()) return null;
        int left = 46, right = 14, plotWidth = Math.max(1, getWidth() - left - right);
        int index = points.size() == 1 ? 0 : Math.max(0, Math.min(points.size() - 1,
                (int) Math.round((event.getX() - left) * (points.size() - 1d) / plotWidth)));
        ActivityPoint point = points.get(index);
        return metric == Metric.WORKLOAD
                ? point.label() + " — " + point.scheduledJobs() + " scheduled job" + (point.scheduledJobs() == 1 ? "" : "s")
                : point.label() + " — Expected net revenue ₱" + String.format("%,.2f", point.expectedEarnings());
    }

    private double xFor(int index, int left, int plotWidth) { return points.size() <= 1 ? left + plotWidth / 2d : left + index * plotWidth / (double) (points.size() - 1); }
    private double roundedMoneyMaximum(double value) { if (value <= 0) return 1; double unit = Math.pow(10, Math.floor(Math.log10(value))); return Math.ceil(value / unit) * unit; }
    private String shortPeso(double value) { return value >= 1000 ? "₱" + String.format("%.0fk", value / 1000d) : "₱" + String.format("%.0f", value); }
    private void drawEmpty(Graphics2D g, int width, int height) { g.setColor(UITheme.COLOR_TEXT_SECONDARY); g.setFont(UITheme.FONT_BODY); String text = "No scheduled job activity yet."; FontMetrics metrics = g.getFontMetrics(); g.drawString(text, (width - metrics.stringWidth(text)) / 2, height / 2); }
}
