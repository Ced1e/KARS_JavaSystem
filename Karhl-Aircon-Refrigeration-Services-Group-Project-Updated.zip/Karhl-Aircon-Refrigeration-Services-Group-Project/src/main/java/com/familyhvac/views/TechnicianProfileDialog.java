package com.familyhvac.views;

import com.familyhvac.controllers.TechnicianProfileController;
import com.familyhvac.models.Technician;
import com.familyhvac.models.TechnicianPayout;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.Map;

/** Ledger-backed technician profile with a direct payout release action. */
public class TechnicianProfileDialog extends JDialog {
    private JTable table;
    private TechnicianProfilePayoutTableModel model;
    private JLabel summary;
    private JButton settle, refresh;

    public TechnicianProfileDialog(Frame owner, Technician technician) {
        super(owner, technician.getName() + " Profile", true);
        build(technician);
        new TechnicianProfileController(this, technician);
    }

    private void build(Technician technician) {
        setSize(940, 630);
        setMinimumSize(new Dimension(760, 520));
        setLocationRelativeTo(getOwner());
        JPanel root = new JPanel(new BorderLayout(0, 18));
        root.setBorder(new EmptyBorder(30, 30, 24, 30));
        root.setBackground(UITheme.COLOR_BACKGROUND);

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setOpaque(false);
        header.add(UITheme.createSectionTitle(technician.getName()));
        header.add(Box.createVerticalStrut(5));
        JLabel subtitle = new JLabel("Technician profile — review negotiated amounts, releases, and remaining obligations.");
        subtitle.setFont(UITheme.FONT_SUBTITLE);
        subtitle.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        header.add(subtitle);
        header.add(Box.createVerticalStrut(14));
        summary = new JLabel("Loading payout obligations...");
        summary.setFont(UITheme.FONT_BUTTON);
        summary.setForeground(UITheme.COLOR_PRIMARY);
        header.add(summary);
        root.add(header, BorderLayout.NORTH);

        model = new TechnicianProfilePayoutTableModel();
        table = new JTable(model);
        table.setFont(UITheme.FONT_BODY);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.setFillsViewportHeight(true);
        table.getTableHeader().setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD));
        PageLayoutSupport.centerTableContents(table);
        table.getColumnModel().getColumn(4).setCellRenderer(new StatusBadgeRenderer());
        root.add(PageLayoutSupport.tableSurface(table), BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        footer.setOpaque(false);
        refresh = UITheme.createSecondaryButton("Refresh");
        settle = UITheme.createPrimaryButton("Release Selected Payout");
        footer.add(refresh);
        footer.add(settle);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
    }

    public JButton getSettleButton() { return settle; }
    public JButton getRefreshButton() { return refresh; }
    public JTable getTable() { return table; }
    public TechnicianProfilePayoutTableModel getModel() { return model; }
    public void setPayouts(List<TechnicianPayout> payouts, Map<Integer, Double> paid, double pending) {
        model.set(payouts, paid);
        summary.setText("Pending payout obligation: ₱" + String.format("%,.2f", pending));
    }
    public void showError(String message) { JOptionPane.showMessageDialog(this, message, "Technician Profile", JOptionPane.ERROR_MESSAGE); }
}
