package com.familyhvac.views;

import com.familyhvac.dao.AnalyticsDAO;
import com.familyhvac.utils.DateSupport;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/** Table model for a date-scoped, detailed job activity report. */
public class JobReportTableModel extends AbstractTableModel {
    private static final String[] COLUMNS = {"Job", "Date", "Client", "Category", "Status", "Gross Total", "Tax Reduction", "Net Total", "Expenses", "Expense Details"};
    private List<AnalyticsDAO.JobReportRow> rows = new ArrayList<>();
    public void setRows(List<AnalyticsDAO.JobReportRow> rows) { this.rows = rows == null ? new ArrayList<>() : rows; fireTableDataChanged(); }
    public List<AnalyticsDAO.JobReportRow> getRows() { return rows; }
    @Override public int getRowCount() { return rows.size(); }
    @Override public int getColumnCount() { return COLUMNS.length; }
    @Override public String getColumnName(int column) { return COLUMNS[column]; }
    @Override public Object getValueAt(int row, int column) {
        AnalyticsDAO.JobReportRow item = rows.get(row);
        return switch (column) {
            case 0 -> item.jobCode(); case 1 -> DateSupport.display(item.jobDate()); case 2 -> item.clientName();
            case 3 -> item.category(); case 4 -> item.status(); case 5 -> money(item.grossTotal());
            case 6 -> item.taxPercent() + "% (" + money(item.taxAmount()) + ")"; case 7 -> money(item.netTotal());
            case 8 -> money(item.expenseTotal()); case 9 -> item.expenseDetails(); default -> "";
        };
    }
    @Override public boolean isCellEditable(int row, int column) { return false; }
    private String money(double amount) { return String.format("PHP %,.2f", amount); }
}
