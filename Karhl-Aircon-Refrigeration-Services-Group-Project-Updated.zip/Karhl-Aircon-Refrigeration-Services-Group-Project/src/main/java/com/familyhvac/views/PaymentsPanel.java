package com.familyhvac.views;

import com.familyhvac.controllers.PaymentsLedgerController;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.List;

/** Cross-job payment ledger; individual payment records remain attached to their jobs. */
public class PaymentsPanel extends JPanel {
    private final PaymentLedgerTableModel model = new PaymentLedgerTableModel();
    private final JTable table = new JTable(model);
    private JButton mark, record, refresh, clientHistory;
    private JTextField searchField;
    private JComboBox<String> statusFilter;

    public PaymentsPanel() {
        setLayout(new BorderLayout(0, 18));
        setBackground(UITheme.COLOR_BACKGROUND);
        setBorder(PageLayoutSupport.pagePadding());
        add(buildHeader(), BorderLayout.NORTH);
        configureTable();
        add(PageLayoutSupport.tableSurface(table), BorderLayout.CENTER);
        new PaymentsLedgerController(this);
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout(0, 18));
        header.setOpaque(false);
        header.add(PageLayoutSupport.titleBlock("Payments", "Review every job's balance and mark a completed payment with one action."), BorderLayout.NORTH);

        JPanel actions = PageLayoutSupport.toolbarSurface();
        JPanel line = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        line.setOpaque(false);
        searchField = PageLayoutSupport.searchField("Search job code or amount");
        statusFilter = new JComboBox<>(new String[]{"All Statuses", "Unpaid", "Partially Paid", "Paid", "Overpaid"});
        refresh = UITheme.createSecondaryButton("Refresh");
        clientHistory = UITheme.createSecondaryButton("Client History");
        mark = UITheme.createPrimaryButton("Mark Paid");
        record = UITheme.createSecondaryButton("Record Payment");
        mark.setEnabled(false);
        record.setEnabled(false);
        clientHistory.setEnabled(false);
        line.add(searchField); line.add(statusFilter); line.add(refresh); line.add(clientHistory); line.add(record); line.add(mark);
        actions.add(line, BorderLayout.CENTER);
        header.add(actions, BorderLayout.SOUTH);
        return header;
    }

    private void configureTable() {
        // Rebuild the visible columns from the current ledger model.
        // This clears any stale column left behind after a model refresh.
        table.setAutoCreateColumnsFromModel(false);
        table.createDefaultColumnsFromModel();
        table.setFont(UITheme.FONT_BODY);
        table.setRowHeight(36);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.setFillsViewportHeight(true);
        table.getTableHeader().setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD));
        table.getColumnModel().getColumn(6).setCellRenderer(new StatusRenderer());
        table.getColumnModel().getColumn(7).setCellRenderer(new AgeRenderer());
        TableRowSorter<PaymentLedgerTableModel> sorter = new TableRowSorter<>(model); table.setRowSorter(sorter);
        javax.swing.event.DocumentListener filterListener = new javax.swing.event.DocumentListener() { public void insertUpdate(javax.swing.event.DocumentEvent e){applyFilter(sorter);} public void removeUpdate(javax.swing.event.DocumentEvent e){applyFilter(sorter);} public void changedUpdate(javax.swing.event.DocumentEvent e){applyFilter(sorter);} };
        searchField.getDocument().addDocumentListener(filterListener); statusFilter.addActionListener(e -> applyFilter(sorter));
    }

    private void applyFilter(TableRowSorter<PaymentLedgerTableModel> sorter) { String search=searchField.getText().trim(); String status=(String)statusFilter.getSelectedItem(); java.util.List<RowFilter<Object,Object>> filters=new java.util.ArrayList<>(); if(!search.isEmpty()) filters.add(RowFilter.regexFilter("(?i)"+java.util.regex.Pattern.quote(search))); if(status!=null&&!status.equals("All Statuses")) filters.add(RowFilter.regexFilter(status.toUpperCase(),6)); sorter.setRowFilter(filters.isEmpty()?null:RowFilter.andFilter(filters)); }

    public JTable getTable() { return table; }
    public PaymentLedgerTableModel getModel() { return model; }
    public JButton getMarkButton() { return mark; }
    public JButton getRecordButton() { return record; }
    public JButton getClientHistoryButton() { return clientHistory; }
    public JButton getRefreshButton() { return refresh; }
    public void setRows(List<PaymentLedgerTableModel.Row> rows) { model.setRows(rows); }
    public void showError(String message) { JOptionPane.showMessageDialog(this, message, "Payments", JOptionPane.ERROR_MESSAGE); }

    private static class StatusRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                       boolean focused, int row, int column) {
            JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, selected, focused, row, column);
            label.setHorizontalAlignment(CENTER);
            label.setFont(UITheme.FONT_BUTTON);
            if (!selected) {
                String status = String.valueOf(value);
                label.setForeground(switch (status) {
                    case "PAID" -> UITheme.COLOR_SUCCESS;
                    case "OVERPAID", "PARTIALLY PAID" -> UITheme.COLOR_WARNING;
                    default -> UITheme.COLOR_DANGER;
                });
            }
            return label;
        }
    }

    private static class AgeRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int row, int column) {
            JLabel label=(JLabel)super.getTableCellRendererComponent(table, value==null?"–":value, selected, focused, row, column);
            label.setHorizontalAlignment(CENTER);
            if(!selected && value instanceof Integer age && age >= 30) label.setForeground(UITheme.COLOR_DANGER);
            else if(!selected && value instanceof Integer age && age >= 15) label.setForeground(UITheme.COLOR_WARNING);
            return label;
        }
    }
}
