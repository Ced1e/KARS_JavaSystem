package com.familyhvac.views;

import com.familyhvac.models.Client;
import com.familyhvac.models.Job;
import com.familyhvac.models.Payment;
import com.familyhvac.services.JobLineItemService;
import com.familyhvac.services.JobService;
import com.familyhvac.services.PaymentService;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.DateSupport;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/** Read-only customer transaction history: every past job and every payment received for it. */
public class ClientHistoryDialog extends JDialog {
    private final Client client;
    private final JobService jobs = new JobService();
    private final JobLineItemService lines = new JobLineItemService();
    private final PaymentService payments = new PaymentService();
    private final DefaultTableModel jobModel = new DefaultTableModel(new String[]{"Job", "Date", "Description", "Status", "Net Total", "Paid", "Balance"}, 0) { public boolean isCellEditable(int r,int c){return false;} };
    private final DefaultTableModel paymentModel = new DefaultTableModel(new String[]{"Job", "Date", "Method", "Reference", "Amount"}, 0) { public boolean isCellEditable(int r,int c){return false;} };
    private final JLabel totalLabel = new JLabel("Loading history...");
    public ClientHistoryDialog(Frame owner, Client client) {
        super(owner, "Customer Job History", true); this.client = client; build(); load();
    }
    private void build() {
        setSize(980, 610); setMinimumSize(new Dimension(760, 500)); setLocationRelativeTo(getOwner());
        JPanel root = new JPanel(new BorderLayout(0, 14)); root.setBackground(UITheme.COLOR_CARD_BG); root.setBorder(new EmptyBorder(22, 26, 22, 26));
        JLabel title = new JLabel("Job History - " + client.getClientName()); title.setFont(UITheme.FONT_TITLE); title.setForeground(UITheme.COLOR_TEXT_PRIMARY); root.add(title, BorderLayout.NORTH);
        JPanel content = new JPanel(); content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS)); content.setBackground(UITheme.COLOR_CARD_BG);
        content.add(section("Past Jobs", new JTable(jobModel), 245)); content.add(Box.createVerticalStrut(14)); content.add(section("Payment History", new JTable(paymentModel), 190));
        root.add(content, BorderLayout.CENTER);
        JPanel footer = new JPanel(new BorderLayout()); footer.setBackground(UITheme.COLOR_CARD_BG); totalLabel.setFont(UITheme.FONT_BUTTON); footer.add(totalLabel, BorderLayout.WEST); JButton close=UITheme.createSecondaryButton("Close"); close.addActionListener(e->dispose()); footer.add(close, BorderLayout.EAST); root.add(footer, BorderLayout.SOUTH); setContentPane(root);
    }
    private JPanel section(String title, JTable table, int height) { JPanel p=new JPanel(new BorderLayout(0,6)); p.setBackground(UITheme.COLOR_CARD_BG); JLabel h=new JLabel(title); h.setFont(UITheme.FONT_BUTTON); p.add(h,BorderLayout.NORTH); table.setFont(UITheme.FONT_BODY);table.setRowHeight(27);table.setFillsViewportHeight(true);table.setAutoCreateRowSorter(true);table.getTableHeader().setFont(UITheme.FONT_LABEL); PageLayoutSupport.centerTableContents(table); JScrollPane scroll=PageLayoutSupport.tableSurface(table);scroll.setPreferredSize(new Dimension(0,height));p.add(scroll,BorderLayout.CENTER);return p; }
    private void load() { new SwingWorker<List<Job>,Void>() { protected List<Job> doInBackground(){return jobs.listJobsForClient(client.getId());} protected void done(){try { double billed=0, received=0; for(Job j:get()){double gross=lines.calculateJobTotal(j.getId());double net=PaymentService.calculateExpectedNetAmount(gross,j.getTaxReductionPercent());double paid=payments.calculateTotalPaid(j.getId());billed+=net;received+=paid;jobModel.addRow(new Object[]{j.getJobCode(),DateSupport.display(j.getJobDate()),j.getDescription()==null?"-":j.getDescription(),j.getJobStatus(),money(net),money(paid),money(net-paid)});for(Payment p:payments.listPaymentsForJob(j.getId()))paymentModel.addRow(new Object[]{j.getJobCode(),DateSupport.display(p.getPaymentDate()),p.getPaymentType(),p.getReferenceNumber()==null?"-":p.getReferenceNumber(),money(p.getAmount())});} totalLabel.setText("Net billed: "+money(billed)+"     Received: "+money(received)+"     Outstanding: "+money(billed-received)); } catch(Exception e){totalLabel.setText("Could not load history: "+e.getMessage());}} }.execute(); }
    private String money(double value){return String.format("PHP %,.2f",value);}
}
