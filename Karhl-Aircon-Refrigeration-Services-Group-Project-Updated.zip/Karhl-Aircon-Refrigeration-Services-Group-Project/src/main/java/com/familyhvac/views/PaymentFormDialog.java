package com.familyhvac.views;

import com.familyhvac.controllers.PaymentFormController;
import com.familyhvac.models.Payment;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.LocalDate;

/**
 * Add/Edit form for one client payment against a job (date, amount, type,
 * reference number, remarks). Contains no business logic and no SQL. All
 * behavior lives in {@link PaymentFormController}.
 *
 * When constructed with a null {@code existingPayment}, this is an "Add"
 * dialog for the given job; otherwise it's an "Edit" dialog pre-populated
 * from that payment.
 */
public class PaymentFormDialog extends JDialog {

    private final int jobId;
    private final Payment existingPayment;

    private DatePickerField paymentDateField;
    private JTextField amountField;
    private JComboBox<Payment.PaymentType> paymentTypeCombo;
    private JTextField referenceNumberField;
    private JTextField remarksField;
    private JLabel errorLabel;
    private JButton saveButton;
    private JButton cancelButton;

    public PaymentFormDialog(Dialog owner, int jobId, Payment existingPayment) {
        super(owner, existingPayment == null ? "Add Payment" : "Edit Payment", true);
        this.jobId = jobId;
        this.existingPayment = existingPayment;
        buildUI();
        populateFieldsIfEditing();
        new PaymentFormController(this, jobId, existingPayment);
    }

    public PaymentFormDialog(Frame owner, int jobId, Payment existingPayment) {
        super(owner, existingPayment == null ? "Add Payment" : "Edit Payment", true);
        this.jobId = jobId;
        this.existingPayment = existingPayment;
        buildUI();
        populateFieldsIfEditing();
        new PaymentFormController(this, jobId, existingPayment);
    }

    private void buildUI() {
        setSize(500, 500);
        setMinimumSize(new Dimension(440, 440));
        setLocationRelativeTo(getOwner());

        errorLabel = FormDialogSupport.errorLabel();

        paymentDateField = new DatePickerField(true);

        amountField = new JTextField();

        paymentTypeCombo = new JComboBox<>(Payment.PaymentType.values());

        referenceNumberField = new JTextField();
        remarksField = new JTextField();

        addClearValidationOnEdit(paymentDateField);
        addClearValidationOnEdit(amountField);

        JPanel body = FormDialogSupport.formStack(errorLabel,
                FormDialogSupport.field("Payment Date * (DD-MM-YYYY)", paymentDateField),
                FormDialogSupport.field("Amount *", amountField),
                FormDialogSupport.field("Payment Type", paymentTypeCombo),
                FormDialogSupport.field("Reference Number", referenceNumberField),
                FormDialogSupport.field("Remarks", remarksField));
        setContentPane(FormDialogSupport.dialogRoot(existingPayment == null ? "Record payment" : "Edit payment",
                "Capture the client payment against this job.", body, buildButtonRow()));
    }

    private JPanel labeledField(String label, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(UITheme.FONT_LABEL);
        labelComponent.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        labelComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        field.setFont(UITheme.FONT_BODY);
        if (field instanceof JTextField textField) {
            textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                    new EmptyBorder(4, 8, 4, 8)
            ));
        }

        panel.add(labelComponent);
        panel.add(Box.createVerticalStrut(4));
        panel.add(field);
        return panel;
    }

    private JPanel buildButtonRow() {
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        saveButton = UITheme.createPrimaryButton("Save");
        return FormDialogSupport.actionRow(cancelButton, saveButton);
    }

    private void populateFieldsIfEditing() {
        if (existingPayment == null) {
            return;
        }
        paymentDateField.setStoredDate(existingPayment.getPaymentDate());
        amountField.setText(formatPlainNumber(existingPayment.getAmount()));
        paymentTypeCombo.setSelectedItem(existingPayment.getPaymentType());
        referenceNumberField.setText(existingPayment.getReferenceNumber());
        remarksField.setText(existingPayment.getRemarks());
    }

    private String formatPlainNumber(double value) {
        return (value == Math.floor(value))
                ? String.format(java.util.Locale.ROOT, "%.0f", value)
                : String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    /** Puts a red border on the given field to flag it as invalid. */
    public void markFieldInvalid(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_DANGER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }
    public void markFieldInvalid(DatePickerField field) { field.markInvalid(true); }

    /** Restores the given field's border to its normal (non-error) style. */
    public void clearFieldValidation(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }
    public void clearFieldValidation(DatePickerField field) { field.markInvalid(false); }

    /** Clears a field's red "invalid" border as soon as the user edits it again. */
    private void addClearValidationOnEdit(JTextField field) {
        field.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }
        });
    }
    private void addClearValidationOnEdit(DatePickerField field) { field.getTextField().getDocument().addDocumentListener(new javax.swing.event.DocumentListener() { public void insertUpdate(javax.swing.event.DocumentEvent e) { field.markInvalid(false); } public void removeUpdate(javax.swing.event.DocumentEvent e) { field.markInvalid(false); } public void changedUpdate(javax.swing.event.DocumentEvent e) { field.markInvalid(false); } }); }

    public int getJobId() {
        return jobId;
    }

    public LocalDate getPaymentDate() { return paymentDateField.getDate(); }

    public String getAmountInput() {
        return amountField.getText();
    }

    public Payment.PaymentType getSelectedPaymentType() {
        return (Payment.PaymentType) paymentTypeCombo.getSelectedItem();
    }

    public String getReferenceNumberInput() {
        return referenceNumberField.getText();
    }

    public String getRemarksInput() {
        return remarksField.getText();
    }

    public DatePickerField getPaymentDateField() {
        return paymentDateField;
    }

    public JTextField getAmountField() {
        return amountField;
    }

    public JButton getSaveButton() {
        return saveButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public void showError(String message) {
        errorLabel.setText(message);
    }

    /** Non-blocking confirmation dialog - used for warnings the user can choose to proceed past. */
    public boolean confirm(String message, String title) {
        int result = JOptionPane.showConfirmDialog(this, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }

    public void closeDialog() {
        dispose();
    }
}
