package com.familyhvac.views;

import com.familyhvac.controllers.JobCashAdvanceFormController;
import com.familyhvac.models.JobCashAdvanceTransaction;
import com.familyhvac.models.Technician;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Form for job-related cash float; this is separate from technician labor pay. */
public class JobCashAdvanceFormDialog extends JDialog {
    private JComboBox<Technician> technician;
    private JComboBox<JobCashAdvanceTransaction.TransactionType> type;
    private DatePickerField date;
    private JTextField amount, remarks;
    private JLabel error;
    private JButton save;

    public JobCashAdvanceFormDialog(Dialog owner, int jobId) {
        super(owner, "Record Cash Advance", true);
        build();
        new JobCashAdvanceFormController(this, jobId);
    }

    private void build() {
        setSize(520, 500);
        setMinimumSize(new Dimension(440, 430));
        setLocationRelativeTo(getOwner());
        error = FormDialogSupport.errorLabel();
        technician = new JComboBox<>();
        type = new JComboBox<>(JobCashAdvanceTransaction.TransactionType.values());
        date = new DatePickerField(true);
        amount = new JTextField();
        remarks = new JTextField();
        JLabel guidance = new JLabel("Use this for food, gas, or operating float—not technician labor payout.");
        guidance.setFont(UITheme.FONT_LABEL);
        guidance.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        JPanel body = FormDialogSupport.formStack(error,
                FormDialogSupport.field("Technician *", technician),
                FormDialogSupport.field("Transaction type", type),
                FormDialogSupport.field("Transaction date * (DD-MM-YYYY)", date),
                FormDialogSupport.field("Amount *", amount),
                FormDialogSupport.field("Remarks", remarks), guidance);
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener(e -> dispose());
        save = UITheme.createPrimaryButton("Record Advance");
        setContentPane(FormDialogSupport.dialogRoot("Record cash advance",
                "Track job float separately from the technician payout ledger.", body,
                FormDialogSupport.actionRow(cancel, save)));
    }

    public void setTechnicians(List<Technician> values) { DefaultComboBoxModel<Technician> model = new DefaultComboBoxModel<>(); for (Technician value : values) model.addElement(value); technician.setModel(model); }
    public Technician getTechnician() { return (Technician) technician.getSelectedItem(); }
    public JobCashAdvanceTransaction.TransactionType getSelectedTransactionType() { return (JobCashAdvanceTransaction.TransactionType) type.getSelectedItem(); }
    public java.time.LocalDate getDate() { return date.getDate(); }
    public String getAmount() { return amount.getText(); }
    public String getRemarks() { return remarks.getText(); }
    public JButton getSaveButton() { return save; }
    public void showError(String value) { error.setText(value); }
    public void closeDialog() { dispose(); }
}
