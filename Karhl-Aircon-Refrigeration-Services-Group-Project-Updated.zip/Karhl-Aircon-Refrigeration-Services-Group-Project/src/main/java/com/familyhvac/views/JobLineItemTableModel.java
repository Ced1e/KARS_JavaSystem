package com.familyhvac.views;

import com.familyhvac.models.JobLineItem;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/**
 * Adapts a list of {@link JobLineItem} objects for display in a JTable.
 * The Subtotal column is never a stored value - it calls
 * {@link JobLineItem#getSubtotal()}, which computes quantity * unitPrice
 * fresh every time. Kept read-only - all edits happen through
 * {@link LineItemFormDialog}.
 */
public class JobLineItemTableModel extends AbstractTableModel {

    private static final String[] COLUMN_NAMES = {
            "Description", "Quantity", "Unit Price", "Subtotal"
    };

    private List<JobLineItem> lineItems = new ArrayList<>();

    public void setLineItems(List<JobLineItem> lineItems) {
        this.lineItems = lineItems != null ? lineItems : new ArrayList<>();
        fireTableDataChanged();
    }

    public JobLineItem getLineItemAt(int rowIndex) {
        return lineItems.get(rowIndex);
    }

    @Override
    public int getRowCount() {
        return lineItems.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return COLUMN_NAMES[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        JobLineItem lineItem = lineItems.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> lineItem.getDescription();
            case 1 -> formatNumber(lineItem.getQuantity());
            case 2 -> formatMoney(lineItem.getUnitPrice());
            case 3 -> formatMoney(lineItem.getSubtotal());
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    private String formatNumber(double value) {
        return (value == Math.floor(value)) ? String.format("%,.0f", value) : String.format("%,.2f", value);
    }

    private String formatMoney(double value) {
        return String.format("\u20B1%,.2f", value);
    }
}
