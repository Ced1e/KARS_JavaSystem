package com.familyhvac.views;

import com.familyhvac.controllers.LoginController;
import com.familyhvac.utils.AppConstants;
import com.familyhvac.utils.RoundedPanel;
import com.familyhvac.utils.UITheme;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** A compact, practical sign-in screen. Authentication behavior is in LoginController. */
public class LoginView extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel errorLabel;
    private JLabel statusLabel;

    public LoginView() { super(AppConstants.APP_NAME + " - Login"); buildUI(); new LoginController(this); }

    private void buildUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 410); setMinimumSize(new Dimension(520, 410)); setResizable(false);
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(UITheme.COLOR_BACKGROUND); root.setBorder(new EmptyBorder(28, 48, 28, 48));

        JPanel card = new RoundedPanel(new BorderLayout(), 14, true);
        card.setBackground(UITheme.COLOR_CARD_BG); card.setPreferredSize(new Dimension(424, 330));
        JPanel masthead = new JPanel(); masthead.setLayout(new BoxLayout(masthead, BoxLayout.Y_AXIS));
        masthead.setBackground(UITheme.COLOR_SIDEBAR_BG); masthead.setBorder(new EmptyBorder(18, 24, 16, 24));
        JLabel company = new JLabel("KARHL AIRCON & REFRIGERATION SERVICES");
        company.setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD, 12f)); company.setForeground(UITheme.COLOR_SIDEBAR_TEXT); company.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel product = new JLabel("Business Manager");
        product.setFont(UITheme.FONT_SUBTITLE.deriveFont(16f)); product.setForeground(UITheme.COLOR_SIDEBAR_TEXT); product.setAlignmentX(Component.LEFT_ALIGNMENT);
        masthead.add(company); masthead.add(Box.createVerticalStrut(4)); masthead.add(product); card.add(masthead, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(UITheme.COLOR_CARD_BG); form.setBorder(new EmptyBorder(20, 30, 20, 30));
        GridBagConstraints c = new GridBagConstraints(); c.gridx = 0; c.weightx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.anchor = GridBagConstraints.WEST;
        JLabel title = new JLabel("Sign in to your account"); title.setFont(UITheme.FONT_BUTTON.deriveFont(18f)); title.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        c.gridy = 0; c.insets = new Insets(0, 0, 12, 0); form.add(title, c);
        c.gridy = 1; c.insets = new Insets(0, 0, 4, 0); form.add(createFieldLabel("Username"), c);
        usernameField = new JTextField(); styleTextField(usernameField); c.gridy = 2; c.insets = new Insets(0, 0, 12, 0); form.add(usernameField, c);
        c.gridy = 3; c.insets = new Insets(0, 0, 4, 0); form.add(createFieldLabel("Password"), c);
        passwordField = new JPasswordField(); styleTextField(passwordField); c.gridy = 4; c.insets = new Insets(0, 0, 8, 0); form.add(passwordField, c);
        errorLabel = new JLabel(" "); errorLabel.setFont(UITheme.FONT_LABEL); errorLabel.setForeground(UITheme.COLOR_DANGER); c.gridy = 5; c.insets = new Insets(0, 0, 6, 0); form.add(errorLabel, c);
        loginButton = UITheme.createPrimaryButton("Sign In"); loginButton.setPreferredSize(new Dimension(0, 40)); c.gridy = 6; c.insets = new Insets(0, 0, 0, 0); form.add(loginButton, c);
        statusLabel = new JLabel(" "); statusLabel.setFont(UITheme.FONT_LABEL); statusLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY); c.gridy = 7; c.insets = new Insets(7, 0, 0, 0); form.add(statusLabel, c);
        card.add(form, BorderLayout.CENTER); root.add(card); setContentPane(root); setLocationRelativeTo(null);
    }
    private JLabel createFieldLabel(String text) { JLabel label = new JLabel(text); label.setFont(UITheme.FONT_LABEL); label.setForeground(UITheme.COLOR_TEXT_SECONDARY); return label; }
    private void styleTextField(JTextField field) { field.setFont(UITheme.FONT_BODY); field.setPreferredSize(new Dimension(0, 34)); field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true), new EmptyBorder(5, 9, 5, 9))); }
    public void showError(String message) { errorLabel.setText(message); }
    public void setLoading(boolean loading) { loginButton.setEnabled(!loading); loginButton.setText(loading ? "Signing in..." : "Sign In"); statusLabel.setText(loading ? "Please wait..." : " "); }
    public String getUsername() { return usernameField.getText(); }
    public String getPassword() { return new String(passwordField.getPassword()); }
    public JTextField getUsernameField() { return usernameField; }
    public JPasswordField getPasswordField() { return passwordField; }
    public JButton getLoginButton() { return loginButton; }
}
