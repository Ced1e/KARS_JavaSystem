package com.familyhvac.views;

import com.familyhvac.controllers.JobDetailsController;
import com.familyhvac.models.Job;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Read-only job workspace. Operational, financial, and technician records are grouped by purpose. */
public class JobDetailsDialog extends JDialog {
    private final Map<String, JTextArea> tabs = new LinkedHashMap<>();
    private JLabel title;

    public JobDetailsDialog(Frame owner, Job job) {
        super(owner, "Job Details", true);
        build(job);
        new JobDetailsController(this, job.getId());
    }

    private void build(Job job) {
        setSize(1080, 760);
        setMinimumSize(new Dimension(920, 640));
        setLocationRelativeTo(getOwner());
        JPanel root = new JPanel(new BorderLayout(0, 18));
        root.setBorder(new EmptyBorder(30, 30, 24, 30));
        root.setBackground(UITheme.COLOR_BACKGROUND);
        root.add(buildHeader(job), BorderLayout.NORTH);

        JTabbedPane pane = new JTabbedPane();
        pane.setFont(UITheme.FONT_BUTTON);
        for (String name : List.of("Overview", "Pricing Summary", "Technicians", "Cash Advances", "Expenses", "Activity")) {
            JTextArea area = new JTextArea();
            area.setEditable(false);
            area.setFont(UITheme.FONT_BODY);
            area.setForeground(UITheme.COLOR_TEXT_PRIMARY);
            area.setBackground(UITheme.COLOR_CARD_BG);
            area.setLineWrap(true);
            area.setWrapStyleWord(true);
            area.setBorder(new EmptyBorder(22, 24, 22, 24));
            tabs.put(name, area);
            JScrollPane scroll = new JScrollPane(area);
            scroll.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true));
            scroll.getViewport().setBackground(UITheme.COLOR_CARD_BG);
            pane.addTab(name, scroll);
        }
        root.add(pane, BorderLayout.CENTER);

        JButton close = UITheme.createSecondaryButton("Close Workspace");
        close.addActionListener(e -> dispose());
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        footer.setOpaque(false);
        footer.add(close);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private JComponent buildHeader(Job job) {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JPanel headings = new JPanel();
        headings.setLayout(new BoxLayout(headings, BoxLayout.Y_AXIS));
        headings.setOpaque(false);
        title = UITheme.createSectionTitle(job.getJobCode());
        headings.add(title);
        headings.add(Box.createVerticalStrut(5));
        JLabel subtitle = new JLabel("Job workspace — review operational, financial, and technician records in one place.");
        subtitle.setFont(UITheme.FONT_SUBTITLE);
        subtitle.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        headings.add(subtitle);
        header.add(headings, BorderLayout.WEST);

        JLabel badge = new JLabel(formatStatus(job.getJobStatus()), SwingConstants.CENTER);
        badge.setOpaque(true);
        badge.setBorder(new EmptyBorder(8, 14, 8, 14));
        badge.setForeground(Color.WHITE);
        badge.setBackground(statusColor(job.getJobStatus()));
        badge.setFont(UITheme.FONT_BUTTON);
        header.add(badge, BorderLayout.EAST);
        return header;
    }

    public void setTabText(String tab, String text) { tabs.get(tab).setText(text); }
    public void showError(String text) { title.setText(text); }
    private String formatStatus(Job.JobStatus status) { return status.name().replace('_', ' '); }
    private Color statusColor(Job.JobStatus status) { return switch (status) { case COMPLETED -> UITheme.COLOR_SUCCESS; case CANCELLED -> UITheme.COLOR_DANGER; case IN_PROGRESS -> UITheme.COLOR_PRIMARY; case SCHEDULED -> UITheme.COLOR_WARNING; }; }
}
