package com.familyhvac.views;

import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

/** Compact, color-coded status treatment for jobs and payment-ledger tables. */
final class StatusBadgeRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                   boolean focused, int row, int column) {
        JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, selected, focused, row, column);
        String status = String.valueOf(value).toUpperCase().replace(' ', '_');
        Color color = switch (status) {
            case "COMPLETED", "PAID", "RELEASED" -> UITheme.COLOR_SUCCESS;
            case "CANCELLED", "UNPAID" -> UITheme.COLOR_DANGER;
            case "IN_PROGRESS", "PARTIAL", "OVERPAID" -> UITheme.COLOR_PRIMARY;
            default -> UITheme.COLOR_WARNING;
        };
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD));
        label.setBorder(new EmptyBorder(5, 10, 5, 10));
        if (selected) {
            label.setForeground(UITheme.COLOR_TEXT_PRIMARY);
            label.setBackground(UITheme.COLOR_TABLE_SELECTION);
        } else {
            label.setForeground(color);
            label.setBackground(new Color(color.getRed(), color.getGreen(), color.getBlue(), 22));
        }
        label.setOpaque(true);
        return label;
    }
}
