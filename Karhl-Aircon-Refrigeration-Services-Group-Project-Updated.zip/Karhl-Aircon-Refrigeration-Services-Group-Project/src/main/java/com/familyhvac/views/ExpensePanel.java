package com.familyhvac.views;
import com.familyhvac.controllers.ExpenseListController;
import com.familyhvac.utils.UITheme;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableRowSorter;
import java.awt.*;

/** Searchable general and job-linked expense ledger. */
public class ExpensePanel extends JPanel {
    private JTable table; private ExpenseTableModel model; private JButton add,edit,remove,refresh; private JTextField search;
    public ExpensePanel(){setLayout(new BorderLayout(0,18));setBackground(UITheme.COLOR_BACKGROUND);setBorder(PageLayoutSupport.pagePadding());add(header(),BorderLayout.NORTH);add(table(),BorderLayout.CENTER);new ExpenseListController(this);}
    private JPanel header(){JPanel outer=new JPanel();outer.setLayout(new BoxLayout(outer,BoxLayout.Y_AXIS));outer.setOpaque(false);outer.add(PageLayoutSupport.titleBlock("Expenses","Review all business costs and filter by category, job, receipt, or description."));outer.add(Box.createVerticalStrut(18));JPanel h=PageLayoutSupport.toolbarSurface();search=PageLayoutSupport.searchField("Search expenses");h.add(search,BorderLayout.WEST);JPanel b=new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0));b.setOpaque(false);refresh=UITheme.createSecondaryButton("Refresh");edit=UITheme.createSecondaryButton("Edit");remove=UITheme.createSecondaryButton("Remove");add=UITheme.createPrimaryButton("Add Expense");edit.setEnabled(false);remove.setEnabled(false);b.add(refresh);b.add(edit);b.add(remove);b.add(add);h.add(b,BorderLayout.EAST);outer.add(h);return outer;}
    private JScrollPane table(){model=new ExpenseTableModel();table=new JTable(model);table.setFont(UITheme.FONT_BODY);table.setRowHeight(30);table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);table.getTableHeader().setFont(UITheme.FONT_LABEL);TableRowSorter<ExpenseTableModel> sorter=new TableRowSorter<>(model);table.setRowSorter(sorter);search.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){public void insertUpdate(javax.swing.event.DocumentEvent e){f();}public void removeUpdate(javax.swing.event.DocumentEvent e){f();}public void changedUpdate(javax.swing.event.DocumentEvent e){f();}private void f(){String q=search.getText().trim();sorter.setRowFilter(q.isEmpty()?null:RowFilter.regexFilter("(?i)"+java.util.regex.Pattern.quote(q)));}});return PageLayoutSupport.tableSurface(table);}
    public JTable getTable(){return table;}public ExpenseTableModel getModel(){return model;}public JButton getAddButton(){return add;}public JButton getEditButton(){return edit;}public JButton getRemoveButton(){return remove;}public JButton getRefreshButton(){return refresh;}public void showError(String s){JOptionPane.showMessageDialog(this,s,"Expenses",JOptionPane.ERROR_MESSAGE);}public boolean confirm(String s,String t){return JOptionPane.showConfirmDialog(this,s,t,JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE)==JOptionPane.YES_OPTION;}
}
