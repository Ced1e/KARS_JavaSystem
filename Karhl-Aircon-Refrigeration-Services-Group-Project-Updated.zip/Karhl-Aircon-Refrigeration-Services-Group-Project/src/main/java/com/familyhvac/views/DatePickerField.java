package com.familyhvac.views;

import com.familyhvac.utils.DateSupport;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

/** Reusable manual-entry field with a themed popup calendar. */
public final class DatePickerField extends JPanel {
    private static final String PLACEHOLDER = "Select a date";
    private static final DateTimeFormatter MONTH = DateTimeFormatter.ofPattern("MMMM yyyy");
    private final JTextField text = new JTextField();
    private final JButton calendarButton = new JButton();
    private final boolean defaultToToday;
    private boolean showingPlaceholder;
    private YearMonth displayedMonth = YearMonth.now();
    private JPopupMenu popup;

    public DatePickerField(boolean defaultToToday) {
        super(new BorderLayout(0, 0));
        this.defaultToToday = defaultToToday;
        setOpaque(false);
        text.setFont(UITheme.FONT_BODY);
        text.setToolTipText("Example: August 8, 2026 (DD-MM-YYYY is also accepted)");
        text.setBorder(new EmptyBorder(4, 8, 4, 8));
        calendarButton.setFont(UITheme.FONT_BUTTON);
        calendarButton.setIcon(new CalendarIcon());
        calendarButton.setToolTipText("Choose a date");
        calendarButton.setFocusPainted(false);
        calendarButton.setBackground(UITheme.COLOR_SECONDARY);
        calendarButton.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        calendarButton.setBorder(new EmptyBorder(3, 10, 3, 10));
        calendarButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true));
        add(text, BorderLayout.CENTER);
        add(calendarButton, BorderLayout.EAST);
        calendarButton.addActionListener(e -> showCalendar());
        text.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { if (showingPlaceholder) clearPlaceholder(); }
            @Override public void focusLost(FocusEvent e) { if (text.getText().isBlank()) showPlaceholder(); }
        });
        if (defaultToToday) setDate(LocalDate.now()); else showPlaceholder();
    }

    public LocalDate getDate() { return showingPlaceholder || text.getText().isBlank() ? null : DateSupport.parseDisplay(text.getText()); }
    public void setDate(LocalDate date) {
        if (date == null) { showPlaceholder(); return; }
        showingPlaceholder = false;
        text.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        text.setText(date.format(DateSupport.DISPLAY));
        displayedMonth = YearMonth.from(date);
    }
    public void setStoredDate(String storedDate) { setDate(storedDate == null || storedDate.isBlank() ? null : LocalDate.parse(storedDate)); }
    public boolean isBlank() { return showingPlaceholder || text.getText().isBlank(); }
    public void markInvalid(boolean invalid) { setBorder(BorderFactory.createLineBorder(invalid ? UITheme.COLOR_DANGER : UITheme.COLOR_BORDER, 1, true)); }
    public JTextField getTextField() { return text; }

    private void clearPlaceholder() {
        if (!showingPlaceholder) return;
        showingPlaceholder = false;
        text.setText("");
        text.setForeground(UITheme.COLOR_TEXT_PRIMARY);
    }
    private void showPlaceholder() {
        showingPlaceholder = true;
        text.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        text.setText(PLACEHOLDER);
    }
    private void showCalendar() { showCalendar(true); }
    /** Reopens the popup without resetting month navigation when requested by its arrows. */
    private void showCalendar(boolean syncToFieldDate) {
        if (syncToFieldDate) {
            try { LocalDate typed = getDate(); if (typed != null) displayedMonth = YearMonth.from(typed); }
            catch (RuntimeException ignored) { }
        }
        popup = new JPopupMenu();
        popup.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER));
        popup.add(buildCalendar());
        popup.show(this, 0, getHeight());
    }
    private JPanel buildCalendar() {
        JPanel root = new JPanel(new BorderLayout(0, 8));
        root.setBackground(UITheme.COLOR_CARD_BG);
        root.setBorder(new EmptyBorder(10, 10, 10, 10));
        JPanel controls = new JPanel(new BorderLayout()); controls.setOpaque(false);
        JButton previous = navButton("<"); JButton next = navButton(">");
        JLabel title = new JLabel(displayedMonth.format(MONTH), SwingConstants.CENTER);
        title.setFont(UITheme.FONT_BUTTON); title.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        previous.addActionListener(e -> { displayedMonth = displayedMonth.minusMonths(1); popup.setVisible(false); showCalendar(false); });
        next.addActionListener(e -> { displayedMonth = displayedMonth.plusMonths(1); popup.setVisible(false); showCalendar(false); });
        controls.add(previous, BorderLayout.WEST); controls.add(title, BorderLayout.CENTER); controls.add(next, BorderLayout.EAST);
        root.add(controls, BorderLayout.NORTH);
        JPanel days = new JPanel(new GridLayout(0, 7, 3, 3)); days.setOpaque(false);
        for (String day : new String[]{"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}) {
            JLabel label = new JLabel(day, SwingConstants.CENTER); label.setFont(UITheme.FONT_LABEL); label.setForeground(UITheme.COLOR_TEXT_SECONDARY); days.add(label);
        }
        int blanks = displayedMonth.atDay(1).getDayOfWeek().getValue() - DayOfWeek.MONDAY.getValue();
        for (int i = 0; i < blanks; i++) days.add(new JLabel());
        LocalDate selected = safeCurrentDate();
        for (int day = 1; day <= displayedMonth.lengthOfMonth(); day++) {
            LocalDate date = displayedMonth.atDay(day);
            JButton button = new JButton(String.valueOf(day)); button.setFont(UITheme.FONT_LABEL); button.setFocusPainted(false);
            button.setMargin(new Insets(3, 3, 3, 3)); button.setBorderPainted(false);
            button.setBackground(date.equals(selected) ? UITheme.COLOR_PRIMARY : UITheme.COLOR_SECONDARY);
            button.setForeground(date.equals(selected) ? Color.WHITE : UITheme.COLOR_TEXT_PRIMARY);
            button.addActionListener(e -> { setDate(date); popup.setVisible(false); }); days.add(button);
        }
        root.add(days, BorderLayout.CENTER);
        JButton today = UITheme.createSecondaryButton("Today");
        today.addActionListener(e -> { setDate(LocalDate.now()); popup.setVisible(false); });
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0)); footer.setOpaque(false); footer.add(today); root.add(footer, BorderLayout.SOUTH);
        return root;
    }
    private LocalDate safeCurrentDate() { try { return getDate(); } catch (RuntimeException ignored) { return null; } }
    private JButton navButton(String label) { JButton button = new JButton(label); button.setFont(UITheme.FONT_BUTTON); button.setFocusPainted(false); button.setBackground(UITheme.COLOR_SECONDARY); button.setForeground(UITheme.COLOR_TEXT_PRIMARY); button.setBorder(new EmptyBorder(3, 8, 3, 8)); return button; }
    private static final class CalendarIcon implements Icon {
        @Override public int getIconWidth() { return 16; }
        @Override public int getIconHeight() { return 16; }
        @Override public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(UITheme.COLOR_TEXT_PRIMARY); g2.drawRoundRect(x + 2, y + 3, 12, 11, 2, 2);
            g2.drawLine(x + 2, y + 7, x + 14, y + 7); g2.drawLine(x + 5, y + 1, x + 5, y + 5); g2.drawLine(x + 11, y + 1, x + 11, y + 5);
            g2.dispose();
        }
    }
}
