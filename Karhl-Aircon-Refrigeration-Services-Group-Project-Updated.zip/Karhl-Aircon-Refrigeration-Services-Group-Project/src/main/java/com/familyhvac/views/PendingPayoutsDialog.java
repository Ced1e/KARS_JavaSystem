package com.familyhvac.views;

import com.familyhvac.controllers.PendingPayoutsController;
import com.familyhvac.models.TechnicianPayout;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Map;

/** Dashboard drill-down for technician obligations that have not been fully released. */
public class PendingPayoutsDialog extends JDialog {
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Technician", "Job", "Approved", "Released", "Remaining"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel summary = new JLabel("Loading pending payouts...");
    private final JButton release = UITheme.createPrimaryButton("Release Selected Payout");
    private final JButton refresh = UITheme.createSecondaryButton("Refresh");
    private List<TechnicianPayout> payouts = List.of();

    public PendingPayoutsDialog(Frame owner) {
        super(owner, "Pending Technician Payouts", true);
        build();
        new PendingPayoutsController(this);
    }

    private void build() {
        setSize(820, 520); setMinimumSize(new Dimension(690, 430)); setLocationRelativeTo(getOwner());
        JPanel root = new JPanel(new BorderLayout(0, 16));
        root.setBackground(UITheme.COLOR_BACKGROUND); root.setBorder(new EmptyBorder(26, 28, 22, 28));
        JPanel header = new JPanel(); header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS)); header.setOpaque(false);
        header.add(UITheme.createSectionTitle("Pending Technician Payouts")); header.add(Box.createVerticalStrut(5));
        JLabel note = new JLabel("Select a payout to release its remaining agreed amount."); note.setFont(UITheme.FONT_SUBTITLE); note.setForeground(UITheme.COLOR_TEXT_SECONDARY); header.add(note);
        header.add(Box.createVerticalStrut(12)); summary.setFont(UITheme.FONT_BUTTON); summary.setForeground(UITheme.COLOR_PRIMARY); header.add(summary);
        root.add(header, BorderLayout.NORTH);
        table.setFont(UITheme.FONT_BODY); table.setRowHeight(34); table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); table.setAutoCreateRowSorter(true); table.setFillsViewportHeight(true); table.getTableHeader().setFont(UITheme.FONT_LABEL.deriveFont(Font.BOLD)); PageLayoutSupport.centerTableContents(table);
        root.add(PageLayoutSupport.tableSurface(table), BorderLayout.CENTER);
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); footer.setOpaque(false); footer.add(refresh); footer.add(release); root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
    }

    public JTable getTable() { return table; }
    public JButton getReleaseButton() { return release; }
    public JButton getRefreshButton() { return refresh; }
    public TechnicianPayout getSelectedPayout() { int row=table.getSelectedRow(); return row < 0 ? null : payouts.get(table.convertRowIndexToModel(row)); }
    public void setPayouts(List<TechnicianPayout> values, Map<Integer, Double> released, double totalRemaining) {
        payouts = values; model.setRowCount(0);
        for (TechnicianPayout payout : values) { double approved=payout.getApprovedAmount()==null?0:payout.getApprovedAmount(); double paid=released.getOrDefault(payout.getId(),0.0); model.addRow(new Object[]{payout.getTechnicianName(), String.format("JOB-%05d", payout.getJobId()), money(approved), money(paid), money(approved-paid)}); }
        summary.setText("Total to release: " + money(totalRemaining) + " across " + values.size() + " payout" + (values.size()==1?"":"s"));
    }
    public void showError(String message) { JOptionPane.showMessageDialog(this, message, "Pending Payouts", JOptionPane.ERROR_MESSAGE); }
    private String money(double amount) { return String.format("₱%,.2f", amount); }
}
