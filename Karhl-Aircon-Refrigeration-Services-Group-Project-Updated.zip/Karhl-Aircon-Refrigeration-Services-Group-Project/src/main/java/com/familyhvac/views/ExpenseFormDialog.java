package com.familyhvac.views;

import com.familyhvac.controllers.ExpenseFormController;
import com.familyhvac.models.Expense;
import com.familyhvac.models.ExpenseCategory;
import com.familyhvac.models.Job;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/** Records a cost against the selected job while keeping its audit fields clear. */
public class ExpenseFormDialog extends JDialog {
    private JComboBox<ExpenseCategory> category;
    private JComboBox<Job> job;
    private DatePickerField date;
    private JTextField description, amount, receipt, remarks;
    private JLabel error;
    private JButton save;

    public ExpenseFormDialog(Frame owner, Expense existing, Integer fixedJobId) {
        super(owner, existing == null ? "Record Job Expense" : "Edit Job Expense", true);
        build(existing == null);
        fill(existing);
        new ExpenseFormController(this, existing, fixedJobId);
    }

    private void build(boolean isNew) {
        setSize(560, 610);
        setMinimumSize(new Dimension(470, 520));
        setLocationRelativeTo(getOwner());
        error = FormDialogSupport.errorLabel();
        category = new JComboBox<>();
        job = new JComboBox<>();
        date = new DatePickerField(true);
        description = new JTextField();
        amount = new JTextField();
        receipt = new JTextField();
        remarks = new JTextField();
        JPanel body = FormDialogSupport.formStack(error,
                FormDialogSupport.field("Expense date * (DD-MM-YYYY)", date),
                FormDialogSupport.field("Expense category *", category),
                FormDialogSupport.field("Related job", job),
                FormDialogSupport.field("Description", description),
                FormDialogSupport.field("Amount *", amount),
                FormDialogSupport.field("Receipt or reference number", receipt),
                FormDialogSupport.field("Remarks", remarks));
        JButton cancel = new JButton("Cancel");
        cancel.addActionListener(e -> dispose());
        save = UITheme.createPrimaryButton(isNew ? "Record Expense" : "Save Changes");
        setContentPane(FormDialogSupport.dialogRoot(isNew ? "Record job expense" : "Edit job expense",
                "Attach the cost to the appropriate job for accurate profitability reporting.",
                body, FormDialogSupport.actionRow(cancel, save)));
    }

    private void fill(Expense expense) {
        if (expense == null) return;
        date.setStoredDate(expense.getExpenseDate());
        description.setText(expense.getDescription());
        amount.setText(Double.toString(expense.getAmount()));
        receipt.setText(expense.getReceiptNumber());
        remarks.setText(expense.getRemarks());
    }

    public void setCategories(List<ExpenseCategory> values) { DefaultComboBoxModel<ExpenseCategory> model = new DefaultComboBoxModel<>(); for (ExpenseCategory value : values) model.addElement(value); category.setModel(model); }
    public void setJobs(List<Job> values) { DefaultComboBoxModel<Job> model = new DefaultComboBoxModel<>(); model.addElement(null); for (Job value : values) model.addElement(value); job.setModel(model); }
    public void selectCategory(int id) { for (int i = 0; i < category.getItemCount(); i++) if (category.getItemAt(i).getId() == id) category.setSelectedIndex(i); }
    public void selectJob(Integer id) { if (id == null) { job.setSelectedItem(null); return; } for (int i = 0; i < job.getItemCount(); i++) { Job value = job.getItemAt(i); if (value != null && value.getId() == id) job.setSelectedIndex(i); } }
    public ExpenseCategory getCategory() { return (ExpenseCategory) category.getSelectedItem(); }
    public Job getJob() { return (Job) job.getSelectedItem(); }
    public java.time.LocalDate getDate() { return date.getDate(); }
    public String getDescription() { return description.getText(); }
    public String getAmount() { return amount.getText(); }
    public String getReceipt() { return receipt.getText(); }
    public String getRemarks() { return remarks.getText(); }
    public JButton getSaveButton() { return save; }
    public void showError(String message) { error.setText(message); }
    public void closeDialog() { dispose(); }
}
