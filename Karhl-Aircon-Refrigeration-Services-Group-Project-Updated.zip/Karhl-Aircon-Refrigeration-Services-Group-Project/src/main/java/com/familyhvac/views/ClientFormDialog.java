package com.familyhvac.views;

import com.familyhvac.controllers.ClientFormController;
import com.familyhvac.models.Client;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Add/Edit form for a client. Contains no business logic and no SQL - it
 * only exposes getters for its fields and a showError/closeDialog pair.
 * All behavior lives in {@link ClientFormController}.
 *
 * When constructed with a null {@code existingClient}, this is an "Add"
 * dialog; otherwise it's an "Edit" dialog pre-populated from that client.
 */
public class ClientFormDialog extends JDialog {

    private final Client existingClient;

    private JTextField clientNameField;
    private JTextField contactPersonField;
    private JTextField phoneField;
    private JTextField emailField;
    private JTextField tinField;
    private JTextArea addressArea;
    private JComboBox<Client.PreferredPaymentMethod> preferredPaymentCombo;
    private JTextArea notesArea;
    private JLabel errorLabel;
    private JButton saveButton;
    private JButton cancelButton;

    public ClientFormDialog(Frame owner, Client existingClient) {
        super(owner, existingClient == null ? "Add Client" : "Edit Client", true);
        this.existingClient = existingClient;
        buildUI();
        populateFieldsIfEditing();
        new ClientFormController(this, existingClient);
    }

    private void buildUI() {
        setSize(820, 620);
        setMinimumSize(new Dimension(720, 540));
        setLocationRelativeTo(getOwner());

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.COLOR_CARD_BG);
        root.setBorder(new EmptyBorder(0, 0, 20, 0));

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(UITheme.COLOR_CARD_BG);
        header.setBorder(new EmptyBorder(24, 28, 14, 28));
        header.add(UITheme.createSectionTitle(existingClient == null ? "Add client" : "Edit client"));
        header.add(Box.createVerticalStrut(5));
        JLabel subtitle = new JLabel("Maintain complete contact and billing details for this client.");
        subtitle.setFont(UITheme.FONT_SUBTITLE);
        subtitle.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        header.add(subtitle);
        root.add(header, BorderLayout.NORTH);

        errorLabel = new JLabel(" ");
        errorLabel.setFont(UITheme.FONT_LABEL);
        errorLabel.setForeground(UITheme.COLOR_DANGER);
        errorLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        errorLabel.setBorder(new EmptyBorder(0, 0, 12, 0));

        clientNameField = new JTextField();
        contactPersonField = new JTextField();
        phoneField = new JTextField();
        emailField = new JTextField();
        tinField = new JTextField();

        addClearValidationOnEdit(clientNameField);
        addClearValidationOnEdit(emailField);

        addressArea = new JTextArea(2, 20);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);

        preferredPaymentCombo = new JComboBox<>(Client.PreferredPaymentMethod.values());

        notesArea = new JTextArea(3, 20);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);

        JPanel body = new JPanel(new BorderLayout(0, 14));
        body.setBackground(UITheme.COLOR_CARD_BG);
        body.setBorder(new EmptyBorder(18, 28, 14, 28));
        body.add(errorLabel, BorderLayout.NORTH);
        JPanel columns = new JPanel(new GridLayout(1, 2, 24, 0));
        columns.setBackground(UITheme.COLOR_CARD_BG);
        columns.add(formColumn(labeledField("Client Name *", clientNameField),
                labeledField("Contact Person", contactPersonField), labeledField("Phone", phoneField),
                labeledArea("Address", addressArea)));
        columns.add(formColumn(labeledField("Email", emailField), labeledField("TIN", tinField),
                labeledField("Payment Method", preferredPaymentCombo), labeledArea("Notes", notesArea)));
        body.add(columns, BorderLayout.CENTER);

        JScrollPane scrollPane = new JScrollPane(body);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        root.add(scrollPane, BorderLayout.CENTER);
        JPanel footer = buildButtonRow();
        footer.setBorder(new EmptyBorder(12, 28, 0, 28));
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private JPanel formColumn(JComponent... fields) {
        JPanel column = new JPanel();
        column.setLayout(new BoxLayout(column, BoxLayout.Y_AXIS));
        column.setBackground(UITheme.COLOR_CARD_BG);
        for (int i = 0; i < fields.length; i++) {
            column.add(fields[i]);
            if (i < fields.length - 1) column.add(Box.createVerticalStrut(14));
        }
        column.add(Box.createVerticalGlue());
        return column;
    }

    private JPanel labeledField(String label, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(UITheme.FONT_LABEL);
        labelComponent.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        labelComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        field.setFont(UITheme.FONT_BODY);
        if (field instanceof JTextField textField) {
            textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                    new EmptyBorder(4, 8, 4, 8)
            ));
        }

        panel.add(labelComponent);
        panel.add(Box.createVerticalStrut(4));
        panel.add(field);
        return panel;
    }

    private JPanel labeledArea(String label, JTextArea area) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(UITheme.FONT_LABEL);
        labelComponent.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        labelComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

        area.setFont(UITheme.FONT_BODY);
        area.setBorder(new EmptyBorder(4, 8, 4, 8));

        JScrollPane scrollPane = new JScrollPane(area);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true));

        panel.add(labelComponent);
        panel.add(Box.createVerticalStrut(4));
        panel.add(scrollPane);
        return panel;
    }

    private JPanel buildButtonRow() {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        row.setBackground(UITheme.COLOR_CARD_BG);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

        cancelButton = new JButton("Cancel");
        cancelButton.setFont(UITheme.FONT_BODY);
        cancelButton.setFocusPainted(false);
        cancelButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cancelButton.addActionListener(e -> dispose());

        saveButton = UITheme.createPrimaryButton("Save");

        row.add(cancelButton);
        row.add(saveButton);
        return row;
    }

    private void populateFieldsIfEditing() {
        if (existingClient == null) {
            return;
        }
        clientNameField.setText(existingClient.getClientName());
        contactPersonField.setText(existingClient.getContactPerson());
        phoneField.setText(existingClient.getPhoneNumber());
        emailField.setText(existingClient.getEmail());
        tinField.setText(existingClient.getTin());
        addressArea.setText(existingClient.getAddress());
        preferredPaymentCombo.setSelectedItem(existingClient.getPreferredPaymentMethod());
        notesArea.setText(existingClient.getNotes());
    }

    /** Puts a red border on the given field to flag it as invalid. */
    public void markFieldInvalid(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_DANGER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }

    /** Restores the given field's border to its normal (non-error) style. */
    public void clearFieldValidation(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }

    /** Clears a field's red "invalid" border as soon as the user edits it again. */
    private void addClearValidationOnEdit(JTextField field) {
        field.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }
        });
    }

    /**
     * Shows a non-blocking "a similar client may already exist" warning
     * listing up to 5 matches, and asks the user whether to continue
     * saving anyway. Returns true if the user chooses to proceed.
     */
    public boolean confirmDespiteSimilarClients(java.util.List<Client> similarClients) {
        StringBuilder message = new StringBuilder(
                "A client with a similar name may already exist:\n\n");
        int shown = 0;
        for (Client similar : similarClients) {
            if (shown >= 5) {
                message.append("...and ").append(similarClients.size() - shown).append(" more\n");
                break;
            }
            message.append("  \u2022 ").append(similar.getClientCode())
                    .append(" - ").append(similar.getClientName()).append('\n');
            shown++;
        }
        message.append("\nDo you want to continue saving this client anyway?");

        int result = JOptionPane.showConfirmDialog(
                this, message.toString(), "Possible Duplicate Client",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }

    public JTextField getClientNameField() {
        return clientNameField;
    }

    public JTextField getEmailField() {
        return emailField;
    }

    public String getClientNameInput() {
        return clientNameField.getText();
    }

    public String getContactPersonInput() {
        return contactPersonField.getText();
    }

    public String getPhoneInput() {
        return phoneField.getText();
    }

    public String getEmailInput() {
        return emailField.getText();
    }

    public String getTinInput() {
        return tinField.getText();
    }

    public String getAddressInput() {
        return addressArea.getText();
    }

    public Client.PreferredPaymentMethod getPreferredPaymentMethodInput() {
        return (Client.PreferredPaymentMethod) preferredPaymentCombo.getSelectedItem();
    }

    public String getNotesInput() {
        return notesArea.getText();
    }

    public JButton getSaveButton() {
        return saveButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public void showError(String message) {
        errorLabel.setText(message);
    }

    public void closeDialog() {
        dispose();
    }
}
