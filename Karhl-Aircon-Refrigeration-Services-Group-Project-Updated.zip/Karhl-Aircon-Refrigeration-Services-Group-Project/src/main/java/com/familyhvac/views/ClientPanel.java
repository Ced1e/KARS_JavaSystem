package com.familyhvac.views;

import com.familyhvac.controllers.ClientListController;
import com.familyhvac.utils.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Client list screen shown under the "Clients" sidebar item. Contains no
 * business logic and no SQL - it only exposes getters for its
 * table/buttons. All behavior lives in {@link ClientListController}.
 */
public class ClientPanel extends JPanel {

    private JTable clientTable;
    private ClientTableModel tableModel;
    private JTextField searchField;
    private JCheckBox showArchivedCheckBox;
    private JButton addButton;
    private JButton editButton;
    private JButton archiveButton;
    private JButton refreshButton;
    private JButton historyButton;

    public ClientPanel() {
        buildUI();
        new ClientListController(this);
    }

    private void buildUI() {
        setLayout(new BorderLayout());
        setBackground(UITheme.COLOR_BACKGROUND);
        setBorder(PageLayoutSupport.pagePadding());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTable(), BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(UITheme.COLOR_BACKGROUND);
        header.setBorder(new EmptyBorder(0, 0, UITheme.SPACING_MD, 0));

        JPanel title = PageLayoutSupport.titleBlock("Clients", "Manage customer records, contact details, and payment preferences.");
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel toolbar = buildToolbar();
        toolbar.setAlignmentX(Component.LEFT_ALIGNMENT);
        toolbar.setBorder(new EmptyBorder(UITheme.SPACING_MD, 0, 0, 0));

        header.add(title);
        header.add(toolbar);
        return header;
    }

    private JPanel buildToolbar() {
        JPanel toolbar = PageLayoutSupport.toolbarSurface();

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        searchPanel.setOpaque(false);

        searchField = PageLayoutSupport.searchField("Search by name, contact person, phone, or address");

        showArchivedCheckBox = new JCheckBox("Show Archived");
        showArchivedCheckBox.setFont(UITheme.FONT_LABEL);
        showArchivedCheckBox.setOpaque(false);
        showArchivedCheckBox.setFocusPainted(false);
        showArchivedCheckBox.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        searchPanel.add(searchField);
        searchPanel.add(showArchivedCheckBox);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttonPanel.setOpaque(false);

        refreshButton = createSecondaryButton("Refresh");
        historyButton = createSecondaryButton("Job History");
        historyButton.setEnabled(false);
        editButton = createSecondaryButton("Edit");
        editButton.setEnabled(false);
        archiveButton = createSecondaryButton("Archive");
        archiveButton.setEnabled(false);
        addButton = UITheme.createPrimaryButton("+ Add Client");

        buttonPanel.add(refreshButton);
        buttonPanel.add(historyButton);
        buttonPanel.add(editButton);
        buttonPanel.add(archiveButton);
        buttonPanel.add(addButton);

        toolbar.add(searchPanel, BorderLayout.WEST);
        toolbar.add(buttonPanel, BorderLayout.EAST);
        return toolbar;
    }

    private JButton createSecondaryButton(String text) {
        return UITheme.createSecondaryButton(text);
    }

    private JScrollPane buildTable() {
        tableModel = new ClientTableModel();
        clientTable = new JTable(tableModel) {
            @Override public String getToolTipText(java.awt.event.MouseEvent event) {
                int row = rowAtPoint(event.getPoint());
                int column = columnAtPoint(event.getPoint());
                if (row < 0 || column < 0) return null;
                Object value = getValueAt(row, column);
                String text = value == null ? "" : value.toString();
                return text.equals("-") || text.isBlank() ? null : text;
            }
        };
        clientTable.setFont(UITheme.FONT_BODY);
        clientTable.setRowHeight(36);
        clientTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        clientTable.setAutoCreateRowSorter(true);
        clientTable.getTableHeader().setFont(UITheme.FONT_LABEL);
        clientTable.setFillsViewportHeight(true);

        return PageLayoutSupport.tableSurface(clientTable);
    }

    public JTable getClientTable() {
        return clientTable;
    }

    public ClientTableModel getTableModel() {
        return tableModel;
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public JCheckBox getShowArchivedCheckBox() {
        return showArchivedCheckBox;
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getEditButton() {
        return editButton;
    }

    public JButton getArchiveButton() {
        return archiveButton;
    }

    public JButton getRefreshButton() {
        return refreshButton;
    }
    public JButton getHistoryButton() { return historyButton; }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public boolean confirm(String message, String title) {
        int result = JOptionPane.showConfirmDialog(this, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }
}
