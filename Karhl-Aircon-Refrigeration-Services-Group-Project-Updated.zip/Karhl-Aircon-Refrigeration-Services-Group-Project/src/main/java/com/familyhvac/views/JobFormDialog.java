package com.familyhvac.views;

import com.familyhvac.controllers.JobFormController;
import com.familyhvac.models.Client;
import com.familyhvac.models.Job;
import com.familyhvac.models.JobLineItem;
import com.familyhvac.models.Payment;
import com.familyhvac.models.ServiceCategory;
import com.familyhvac.models.TechnicianPayout;
import com.familyhvac.models.TechnicianPayoutDisbursement;
import com.familyhvac.models.JobCashAdvanceTransaction;
import com.familyhvac.models.Expense;
import com.familyhvac.utils.UITheme;
import com.familyhvac.utils.DateSupport;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

/**
 * Add/Edit form for a job's header fields (client, category, date,
 * location, description, payment due date, notes, status), plus line-item
 * management once the job exists. Contains no business logic and no SQL -
 * it only exposes getters/setters for its fields. All behavior, including
 * fetching clients/categories and line items, lives in
 * {@link JobFormController}.
 *
 * Line items require a real job_id, so that section is only functional in
 * Edit mode - see {@link #buildLineItemsSection()}. Still deliberately
 * does NOT include payments, technician payouts, cash advances, or
 * expenses - those belong to later phases (Job Details).
 *
 * When constructed with a null {@code existingJob}, this is an "Add"
 * dialog; otherwise it's an "Edit" dialog pre-populated from that job.
 */
public class JobFormDialog extends JDialog {

    private final Job existingJob;

    private JComboBox<Client> clientCombo;
    private JComboBox<ServiceCategory> categoryCombo;
    private DatePickerField jobDateField;
    private JTextField locationField;
    private JTextField poNumberField;
    private JTextArea descriptionArea;
    private JTextField taxReductionPercentField;
    private JTextArea notesArea;
    private JComboBox<Job.JobStatus> statusCombo;
    private DatePickerField completionDateField;
    private JComponent completionDateRow;
    private JLabel errorLabel;
    private JButton saveButton;
    private JButton cancelButton;

    private JTable lineItemTable;
    private JobLineItemTableModel lineItemTableModel;
    private JButton addLineItemButton;
    private JButton editLineItemButton;
    private JButton removeLineItemButton;
    private JLabel jobTotalValueLabel;
    private JLabel taxAmountValueLabel;
    private JLabel netJobTotalValueLabel;

    private JTable paymentTable;
    private PaymentTableModel paymentTableModel;
    private JButton addPaymentButton;
    private JButton editPaymentButton;
    private JLabel totalPaidValueLabel;
    private JLabel remainingBalanceValueLabel;
    private JTable payoutTable, disbursementTable;
    private TechnicianPayoutTableModel payoutTableModel;
    private TechnicianPayoutDisbursementTableModel disbursementTableModel;
    private JButton addPayoutButton, editPayoutButton, removePayoutButton, addDisbursementButton;
    private JLabel payoutSummaryValueLabel;
    private JTable cashAdvanceTable;
    private JobCashAdvanceTableModel cashAdvanceTableModel;
    private JButton addCashAdvanceButton;
    private JLabel cashAdvanceBalanceValueLabel;
    private JButton addJobExpenseButton, editJobExpenseButton, removeJobExpenseButton;
    private JLabel jobExpenseTotalValueLabel;
    private JTable jobExpenseTable;
    private ExpenseTableModel jobExpenseTableModel;
    private JButton markBilledButton;
    private JLabel billingStatusValueLabel;

    public JobFormDialog(Frame owner, Job existingJob) {
        super(owner, existingJob == null ? "Add Job" : "Edit Job", true);
        this.existingJob = existingJob;
        buildUI();
        populateScalarFieldsIfEditing();
        new JobFormController(this, existingJob);
    }

    private void buildUI() {
        setSize(1060, 760);
        setMinimumSize(new Dimension(860, 620));
        setLocationRelativeTo(getOwner());

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(UITheme.COLOR_CARD_BG);
        root.setBorder(new EmptyBorder(0, 0, 20, 0));

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(UITheme.COLOR_CARD_BG);
        header.setBorder(new EmptyBorder(24, 28, 14, 28));
        JLabel title = UITheme.createSectionTitle(existingJob == null ? "Create job" : "Edit job");
        JLabel subtitle = new JLabel(existingJob == null
                ? "Add the job information first. Financial and technician records can be added after saving."
                : "Keep job information, client billing, and technician records clearly separated.");
        subtitle.setFont(UITheme.FONT_SUBTITLE);
        subtitle.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        header.add(title);
        header.add(Box.createVerticalStrut(5));
        header.add(subtitle);
        root.add(header, BorderLayout.NORTH);

        errorLabel = new JLabel(" ");
        errorLabel.setFont(UITheme.FONT_LABEL);
        errorLabel.setForeground(UITheme.COLOR_DANGER);
        errorLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        errorLabel.setBorder(new EmptyBorder(0, 0, 12, 0));

        clientCombo = new JComboBox<>();
        categoryCombo = new JComboBox<>();
        categoryCombo.setRenderer(new CategoryCellRenderer());

        jobDateField = new DatePickerField(false);
        locationField = new JTextField();
        poNumberField = new JTextField();

        descriptionArea = new JTextArea(3, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);

        taxReductionPercentField = new JTextField("0");
        taxReductionPercentField.setToolTipText("Example: 5 for a 5% tax reduction");

        addClearValidationOnEdit(jobDateField);
        addClearValidationOnEdit(taxReductionPercentField);

        notesArea = new JTextArea(3, 20);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);

        statusCombo = new JComboBox<>(Job.JobStatus.values());
        statusCombo.setEnabled(existingJob != null); // a new job always starts SCHEDULED
        completionDateField = new DatePickerField(true);
        completionDateField.setToolTipText("Actual completion date; defaults to today.");
        completionDateRow = labeledField("Actual Completion Date (DD-MM-YYYY)", completionDateField);
        completionDateRow.setVisible(existingJob != null && existingJob.getJobStatus() == Job.JobStatus.COMPLETED);
        statusCombo.addActionListener(e -> { completionDateRow.setVisible(statusCombo.getSelectedItem() == Job.JobStatus.COMPLETED); revalidate(); repaint(); });

        JPanel details = new JPanel(new BorderLayout(0, 16));
        details.setBackground(UITheme.COLOR_CARD_BG);
        details.setBorder(new EmptyBorder(18, 24, 24, 24));
        details.add(errorLabel, BorderLayout.NORTH);
        JPanel columns = new JPanel(new GridLayout(1, 2, 24, 0));
        columns.setBackground(UITheme.COLOR_CARD_BG);
        JPanel left = formColumn(labeledField("Client *", clientCombo),
                labeledField("Job Date * (DD-MM-YYYY)", jobDateField),
                labeledArea("Description", descriptionArea));
        JPanel right = formColumn(labeledField("Service Category", categoryCombo),
                labeledField("Location", locationField),
                labeledField("PO Number", poNumberField),
                labeledField("Tax Reduction (%)", taxReductionPercentField),
                labeledField("Status", statusCombo), completionDateRow, labeledArea("Internal Notes", notesArea));
        columns.add(left);
        columns.add(right);
        details.add(columns, BorderLayout.CENTER);

        JPanel billing = buildWorkExpensesTab();
        JPanel technicians = tabContent(buildPayoutsSection(), buildCashAdvancesSection());

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(UITheme.FONT_BUTTON);
        tabs.addTab("Job Details", details);
        tabs.addTab("Work & Expenses", tabScroll(billing));
        tabs.addTab("Technicians & Advances", tabScroll(technicians));
        root.add(tabs, BorderLayout.CENTER);

        JPanel footer = buildButtonRow();
        footer.setBorder(new EmptyBorder(16, 28, 0, 28));
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private JPanel formColumn(JComponent... fields) {
        JPanel column = new JPanel();
        column.setLayout(new BoxLayout(column, BoxLayout.Y_AXIS));
        column.setBackground(UITheme.COLOR_CARD_BG);
        for (int i = 0; i < fields.length; i++) {
            column.add(fields[i]);
            if (i < fields.length - 1) column.add(Box.createVerticalStrut(14));
        }
        column.add(Box.createVerticalGlue());
        return column;
    }

    private JPanel tabContent(JComponent... sections) {
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(UITheme.COLOR_CARD_BG);
        content.setBorder(new EmptyBorder(22, 24, 24, 24));
        for (int i = 0; i < sections.length; i++) {
            content.add(sections[i]);
            if (i < sections.length - 1) content.add(Box.createVerticalStrut(20));
        }
        return content;
    }

    /** Keeps the work tables pinned to the full available width instead of centred by BoxLayout. */
    private JPanel buildWorkExpensesTab() {
        JPanel content = new JPanel(new BorderLayout(0, 20));
        content.setBackground(UITheme.COLOR_CARD_BG);
        content.setBorder(new EmptyBorder(22, 24, 24, 24));
        content.add(buildLineItemsSection(), BorderLayout.NORTH);
        content.add(buildJobExpensesSection(), BorderLayout.CENTER);
        return content;
    }

    private JScrollPane tabScroll(JComponent content) {
        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        return scrollPane;
    }

    private JPanel labeledField(String label, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(UITheme.FONT_LABEL);
        labelComponent.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        labelComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        field.setFont(UITheme.FONT_BODY);
        if (field instanceof JTextField textField) {
            textField.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                    new EmptyBorder(4, 8, 4, 8)
            ));
        }

        panel.add(labelComponent);
        panel.add(Box.createVerticalStrut(4));
        panel.add(field);
        return panel;
    }

    private JPanel labeledArea(String label, JTextArea area) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(UITheme.COLOR_CARD_BG);
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(UITheme.FONT_LABEL);
        labelComponent.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        labelComponent.setAlignmentX(Component.LEFT_ALIGNMENT);

        area.setFont(UITheme.FONT_BODY);
        area.setBorder(new EmptyBorder(4, 8, 4, 8));

        JScrollPane scrollPane = new JScrollPane(area);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        scrollPane.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true));

        panel.add(labelComponent);
        panel.add(Box.createVerticalStrut(4));
        panel.add(scrollPane);
        return panel;
    }

    private JPanel buildButtonRow() {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        row.setBackground(UITheme.COLOR_CARD_BG);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

        cancelButton = new JButton("Cancel");
        cancelButton.setFont(UITheme.FONT_BODY);
        cancelButton.setFocusPainted(false);
        cancelButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cancelButton.addActionListener(e -> dispose());

        saveButton = UITheme.createPrimaryButton("Save");

        row.add(cancelButton);
        row.add(saveButton);
        return row;
    }

    /**
     * Line items require a real job_id (NOT NULL foreign key), so this
     * section is only functional in Edit mode. In Add mode it shows a
     * short note instead - the job must be saved once before it has an id
     * to attach line items to.
     */
    private JPanel buildLineItemsSection() {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setBackground(UITheme.COLOR_CARD_BG);
        section.setAlignmentX(Component.LEFT_ALIGNMENT);
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 430));

        JLabel sectionLabel = new JLabel("Line Items");
        sectionLabel.setFont(UITheme.FONT_LABEL);
        sectionLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        sectionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        section.add(sectionLabel);
        section.add(Box.createVerticalStrut(4));

        if (existingJob == null) {
            JPanel notice = new JPanel(new FlowLayout(FlowLayout.LEFT));
            notice.setBackground(UITheme.COLOR_CARD_BG);
            notice.setAlignmentX(Component.LEFT_ALIGNMENT);
            notice.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true));
            notice.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

            JLabel noticeLabel = new JLabel("Save this job first, then reopen it to add line items.");
            noticeLabel.setFont(UITheme.FONT_LABEL);
            noticeLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);
            notice.add(noticeLabel);

            section.add(notice);
            return section;
        }

        lineItemTableModel = new JobLineItemTableModel();
        lineItemTable = new JTable(lineItemTableModel);
        lineItemTable.setFont(UITheme.FONT_BODY);
        lineItemTable.setRowHeight(26);
        lineItemTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lineItemTable.getTableHeader().setFont(UITheme.FONT_LABEL);
        lineItemTable.setFillsViewportHeight(true);

        JScrollPane tableScrollPane = new JScrollPane(lineItemTable);
        tableScrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        tableScrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));
        tableScrollPane.setPreferredSize(new Dimension(480, 140));
        tableScrollPane.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER));

        JPanel lineItemButtonRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        lineItemButtonRow.setBackground(UITheme.COLOR_CARD_BG);
        lineItemButtonRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        lineItemButtonRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        addLineItemButton = createSecondaryButton("+ Add Line Item");
        editLineItemButton = createSecondaryButton("Edit");
        editLineItemButton.setEnabled(false);
        removeLineItemButton = createSecondaryButton("Remove");
        removeLineItemButton.setEnabled(false);

        lineItemButtonRow.add(addLineItemButton);
        lineItemButtonRow.add(editLineItemButton);
        lineItemButtonRow.add(removeLineItemButton);

        section.add(tableScrollPane);
        section.add(lineItemButtonRow);
        JPanel summary = new JPanel(new GridLayout(3, 2, 8, 6));
        summary.setBackground(UITheme.COLOR_CARD_BG);
        summary.setBorder(new EmptyBorder(10, 0, 0, 0));
        summary.setMaximumSize(new Dimension(Integer.MAX_VALUE, 92));
        summary.add(summaryLabel("Gross job total"));
        jobTotalValueLabel = summaryValueLabel(); summary.add(jobTotalValueLabel);
        summary.add(summaryLabel("Tax reduction"));
        taxAmountValueLabel = summaryValueLabel(); summary.add(taxAmountValueLabel);
        summary.add(summaryLabel("Net job total"));
        netJobTotalValueLabel = summaryValueLabel(); netJobTotalValueLabel.setFont(UITheme.FONT_BUTTON); summary.add(netJobTotalValueLabel);
        section.add(summary);
        return section;
    }

    private JLabel summaryLabel(String text) { JLabel label = new JLabel(text); label.setFont(UITheme.FONT_LABEL); label.setForeground(UITheme.COLOR_TEXT_SECONDARY); return label; }
    private JLabel summaryValueLabel() { JLabel label = new JLabel("PHP 0.00", SwingConstants.RIGHT); label.setFont(UITheme.FONT_LABEL); label.setForeground(UITheme.COLOR_TEXT_PRIMARY); return label; }

    /**
     * Payments also require a real job_id, so - like line items - this
     * section is only functional in Edit mode.
     */
    private JPanel buildPaymentsSection() {
        JPanel section = new JPanel();
        section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS));
        section.setBackground(UITheme.COLOR_CARD_BG);
        section.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sectionLabel = new JLabel("Client Payments");
        sectionLabel.setFont(UITheme.FONT_LABEL);
        sectionLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        sectionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        section.add(sectionLabel);
        section.add(Box.createVerticalStrut(4));

        if (existingJob == null) {
            JPanel notice = new JPanel(new FlowLayout(FlowLayout.LEFT));
            notice.setBackground(UITheme.COLOR_CARD_BG);
            notice.setAlignmentX(Component.LEFT_ALIGNMENT);
            notice.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true));
            notice.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

            JLabel noticeLabel = new JLabel("Save this job first, then reopen it to record payments.");
            noticeLabel.setFont(UITheme.FONT_LABEL);
            noticeLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);
            notice.add(noticeLabel);

            section.add(notice);
            return section;
        }

        paymentTableModel = new PaymentTableModel();
        paymentTable = new JTable(paymentTableModel);
        paymentTable.setFont(UITheme.FONT_BODY);
        paymentTable.setRowHeight(26);
        paymentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        paymentTable.getTableHeader().setFont(UITheme.FONT_LABEL);
        paymentTable.setFillsViewportHeight(true);

        JScrollPane tableScrollPane = new JScrollPane(paymentTable);
        tableScrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        tableScrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));
        tableScrollPane.setPreferredSize(new Dimension(480, 140));
        tableScrollPane.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER));

        JPanel paymentButtonRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        paymentButtonRow.setBackground(UITheme.COLOR_CARD_BG);
        paymentButtonRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        paymentButtonRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        addPaymentButton = createSecondaryButton("+ Add Payment");
        editPaymentButton = createSecondaryButton("Edit");
        editPaymentButton.setEnabled(false);

        paymentButtonRow.add(addPaymentButton);
        paymentButtonRow.add(editPaymentButton);

        JPanel summaryPanel = new JPanel();
        summaryPanel.setLayout(new BoxLayout(summaryPanel, BoxLayout.Y_AXIS));
        summaryPanel.setBackground(UITheme.COLOR_CARD_BG);
        summaryPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        summaryPanel.setBorder(new EmptyBorder(4, 0, 0, 0));

        JPanel jobTotalRow = new JPanel(new BorderLayout());
        jobTotalRow.setBackground(UITheme.COLOR_CARD_BG);
        JLabel jobTotalLabel = new JLabel("Job Total"); jobTotalLabel.setFont(UITheme.FONT_LABEL); jobTotalLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);
        jobTotalValueLabel = new JLabel("\u20B10.00"); jobTotalValueLabel.setFont(UITheme.FONT_LABEL); jobTotalValueLabel.setForeground(UITheme.COLOR_TEXT_PRIMARY);
        jobTotalRow.add(jobTotalLabel, BorderLayout.WEST); jobTotalRow.add(jobTotalValueLabel, BorderLayout.EAST);

        JPanel totalPaidRow = new JPanel(new BorderLayout());
        totalPaidRow.setBackground(UITheme.COLOR_CARD_BG);
        totalPaidRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        totalPaidRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));

        JLabel totalPaidLabel = new JLabel("Total Paid");
        totalPaidLabel.setFont(UITheme.FONT_LABEL);
        totalPaidLabel.setForeground(UITheme.COLOR_TEXT_SECONDARY);

        totalPaidValueLabel = new JLabel("\u20B10.00");
        totalPaidValueLabel.setFont(UITheme.FONT_LABEL);
        totalPaidValueLabel.setForeground(UITheme.COLOR_TEXT_PRIMARY);

        totalPaidRow.add(totalPaidLabel, BorderLayout.WEST);
        totalPaidRow.add(totalPaidValueLabel, BorderLayout.EAST);

        JPanel remainingBalanceRow = new JPanel(new BorderLayout());
        remainingBalanceRow.setBackground(UITheme.COLOR_CARD_BG);
        remainingBalanceRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        remainingBalanceRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));

        JLabel remainingBalanceLabel = new JLabel("Remaining Balance");
        remainingBalanceLabel.setFont(UITheme.FONT_BUTTON);
        remainingBalanceLabel.setForeground(UITheme.COLOR_TEXT_PRIMARY);

        remainingBalanceValueLabel = new JLabel("\u20B10.00");
        remainingBalanceValueLabel.setFont(UITheme.FONT_BUTTON);
        remainingBalanceValueLabel.setForeground(UITheme.COLOR_TEXT_PRIMARY);

        remainingBalanceRow.add(remainingBalanceLabel, BorderLayout.WEST);
        remainingBalanceRow.add(remainingBalanceValueLabel, BorderLayout.EAST);

        summaryPanel.add(jobTotalRow);
        summaryPanel.add(totalPaidRow);
        summaryPanel.add(remainingBalanceRow);

        section.add(tableScrollPane);
        section.add(paymentButtonRow);
        section.add(summaryPanel);
        return section;
    }

    private JPanel buildPayoutsSection() {
        JPanel section = new JPanel(); section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS)); section.setBackground(UITheme.COLOR_CARD_BG); section.setAlignmentX(Component.LEFT_ALIGNMENT); section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 480));
        JLabel label = sectionHeading("Technicians & Payouts"); section.add(label); section.add(Box.createVerticalStrut(8));
        if (existingJob == null) { section.add(sectionNotice("Save this job first, then reopen it to assign technicians.")); return section; }
        payoutTableModel = new TechnicianPayoutTableModel(); payoutTable = new JTable(payoutTableModel); configureCompactTable(payoutTable); section.add(compactScroll(payoutTable, 135));
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8)); buttons.setBackground(UITheme.COLOR_CARD_BG); buttons.setAlignmentX(Component.LEFT_ALIGNMENT); buttons.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48)); addPayoutButton=createSecondaryButton("Add Technician"); editPayoutButton=createSecondaryButton("Edit"); removePayoutButton=createSecondaryButton("Remove"); addDisbursementButton=createSecondaryButton("Record Disbursement"); editPayoutButton.setEnabled(false); removePayoutButton.setEnabled(false); addDisbursementButton.setEnabled(false); buttons.add(addPayoutButton); buttons.add(editPayoutButton); buttons.add(removePayoutButton); buttons.add(addDisbursementButton); section.add(buttons);
        section.add(Box.createVerticalStrut(12)); JLabel ledger = sectionHeading("Selected Technician Disbursements"); section.add(ledger); section.add(Box.createVerticalStrut(8)); disbursementTableModel = new TechnicianPayoutDisbursementTableModel(); disbursementTable = new JTable(disbursementTableModel); configureCompactTable(disbursementTable); section.add(compactScroll(disbursementTable, 120));
        payoutSummaryValueLabel = new JLabel("Select a technician to see payout details."); payoutSummaryValueLabel.setFont(UITheme.FONT_LABEL); payoutSummaryValueLabel.setAlignmentX(Component.LEFT_ALIGNMENT); payoutSummaryValueLabel.setBorder(new EmptyBorder(8, 0, 0, 0)); section.add(payoutSummaryValueLabel); return section;
    }

    private JPanel buildCashAdvancesSection() {
        JPanel section=new JPanel(); section.setLayout(new BoxLayout(section,BoxLayout.Y_AXIS)); section.setBackground(UITheme.COLOR_CARD_BG); section.setAlignmentX(Component.LEFT_ALIGNMENT); section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 320));
        JLabel title=sectionHeading("Job Cash Advances"); section.add(title); section.add(Box.createVerticalStrut(8));
        if(existingJob==null){section.add(new JLabel("Save this job first, then reopen it to record cash advances."));return section;}
        JLabel explanation=new JLabel("Food and fuel float only. This is separate from technician labor payout and job expenses."); explanation.setFont(UITheme.FONT_LABEL); explanation.setForeground(UITheme.COLOR_TEXT_SECONDARY); explanation.setAlignmentX(Component.LEFT_ALIGNMENT); section.add(explanation); section.add(Box.createVerticalStrut(8));
        cashAdvanceTableModel=new JobCashAdvanceTableModel(); cashAdvanceTable=new JTable(cashAdvanceTableModel); configureCompactTable(cashAdvanceTable); section.add(compactScroll(cashAdvanceTable,120));
        JPanel buttons=new JPanel(new FlowLayout(FlowLayout.LEFT,8,8));buttons.setBackground(UITheme.COLOR_CARD_BG);buttons.setAlignmentX(Component.LEFT_ALIGNMENT);buttons.setMaximumSize(new Dimension(Integer.MAX_VALUE,48));addCashAdvanceButton=createSecondaryButton("Record Release or Return");buttons.add(addCashAdvanceButton);section.add(buttons);
        cashAdvanceBalanceValueLabel=new JLabel("Job cash-advance balance: PHP 0.00");cashAdvanceBalanceValueLabel.setFont(UITheme.FONT_BUTTON);cashAdvanceBalanceValueLabel.setAlignmentX(Component.LEFT_ALIGNMENT);section.add(cashAdvanceBalanceValueLabel);return section;
    }

    private JPanel buildJobExpensesSection() {
        JPanel section=new JPanel(); section.setLayout(new BoxLayout(section, BoxLayout.Y_AXIS)); section.setBackground(UITheme.COLOR_CARD_BG); section.setAlignmentX(Component.LEFT_ALIGNMENT); section.setMaximumSize(new Dimension(Integer.MAX_VALUE,360));
        JLabel title=sectionHeading("Job Expenses"); section.add(title); section.add(Box.createVerticalStrut(5));
        JLabel description=new JLabel("Record materials, travel, and other costs that belong to this job."); description.setFont(UITheme.FONT_LABEL); description.setForeground(UITheme.COLOR_TEXT_SECONDARY); description.setAlignmentX(Component.LEFT_ALIGNMENT); section.add(description); section.add(Box.createVerticalStrut(10));
        if(existingJob==null){section.add(sectionNotice("Save this job first, then reopen it to record job expenses."));return section;}
        jobExpenseTableModel=new ExpenseTableModel(); jobExpenseTable=new JTable(jobExpenseTableModel); configureCompactTable(jobExpenseTable); section.add(compactScroll(jobExpenseTable,150)); section.add(Box.createVerticalStrut(8));
        JPanel actions=new JPanel(new BorderLayout()); actions.setBackground(UITheme.COLOR_CARD_BG); actions.setAlignmentX(Component.LEFT_ALIGNMENT); actions.setMaximumSize(new Dimension(Integer.MAX_VALUE,42)); JPanel buttons=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0)); buttons.setOpaque(false); addJobExpenseButton=createSecondaryButton("Record Job Expense"); editJobExpenseButton=createSecondaryButton("Edit"); removeJobExpenseButton=createSecondaryButton("Remove"); editJobExpenseButton.setEnabled(false); removeJobExpenseButton.setEnabled(false); buttons.add(addJobExpenseButton); buttons.add(editJobExpenseButton); buttons.add(removeJobExpenseButton); actions.add(buttons,BorderLayout.WEST); jobExpenseTotalValueLabel=new JLabel("Total: PHP 0.00");jobExpenseTotalValueLabel.setFont(UITheme.FONT_BUTTON); actions.add(jobExpenseTotalValueLabel,BorderLayout.EAST); section.add(actions); return section;
    }

    private JLabel sectionHeading(String text) { JLabel label = new JLabel(text); label.setFont(UITheme.FONT_BUTTON); label.setForeground(UITheme.COLOR_TEXT_PRIMARY); label.setAlignmentX(Component.LEFT_ALIGNMENT); return label; }
    private JComponent sectionNotice(String text) { JLabel label = new JLabel(text); label.setFont(UITheme.FONT_LABEL); label.setForeground(UITheme.COLOR_TEXT_SECONDARY); label.setAlignmentX(Component.LEFT_ALIGNMENT); return label; }

    private JPanel buildBillingSection() {
        JPanel section=new JPanel(new FlowLayout(FlowLayout.LEFT,8,4)); section.setBackground(UITheme.COLOR_CARD_BG); section.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel title=new JLabel("Billing"); title.setFont(UITheme.FONT_LABEL); section.add(title);
        if(existingJob==null){section.add(new JLabel("Save this job first, then reopen it to mark it billed."));return section;}
        markBilledButton=createSecondaryButton("Mark as Billed"); billingStatusValueLabel=new JLabel(existingJob.getBilledAt()==null?"Not billed":"Billed: "+existingJob.getBilledAt()); billingStatusValueLabel.setFont(UITheme.FONT_LABEL); if(existingJob.getBilledAt()!=null)markBilledButton.setEnabled(false); section.add(markBilledButton);section.add(billingStatusValueLabel);return section;
    }

    private void configureCompactTable(JTable table) { table.setFont(UITheme.FONT_BODY); table.setRowHeight(26); table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); table.getTableHeader().setFont(UITheme.FONT_LABEL); table.setFillsViewportHeight(true); PageLayoutSupport.centerTableContents(table); }
    private JScrollPane compactScroll(JTable table, int height) { JScrollPane pane=new JScrollPane(table); pane.setAlignmentX(Component.LEFT_ALIGNMENT); pane.setMaximumSize(new Dimension(Integer.MAX_VALUE,height)); pane.setPreferredSize(new Dimension(480,height)); pane.setBorder(BorderFactory.createLineBorder(UITheme.COLOR_BORDER)); return pane; }

    private JButton createSecondaryButton(String text) {
        JButton button = new JButton(text);
        button.setFont(UITheme.FONT_BODY);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    /** Replaces the line items table's contents. No-op in Add mode (the table doesn't exist yet). */
    public void setLineItems(List<JobLineItem> lineItems) {
        if (lineItemTableModel != null) {
            lineItemTableModel.setLineItems(lineItems);
        }
    }

    /** Updates the Job Total label. No-op in Add mode. */
    public void setJobTotal(double total) {
        if (jobTotalValueLabel != null) {
            double taxAmount = total * (getTaxReductionPercent() / 100.0);
            jobTotalValueLabel.setText(money(total));
            if (taxAmountValueLabel != null) taxAmountValueLabel.setText(money(taxAmount));
            if (netJobTotalValueLabel != null) netJobTotalValueLabel.setText(money(total - taxAmount));
        }
    }

    private double getTaxReductionPercent() {
        try { return Math.max(0, Math.min(100, Double.parseDouble(taxReductionPercentField.getText().trim()))); }
        catch (NumberFormatException e) { return 0; }
    }

    private String money(double amount) { return String.format("PHP %,.2f", amount); }

    public JTable getLineItemTable() {
        return lineItemTable;
    }

    public JobLineItemTableModel getLineItemTableModel() {
        return lineItemTableModel;
    }

    public JButton getAddLineItemButton() {
        return addLineItemButton;
    }

    public JButton getEditLineItemButton() {
        return editLineItemButton;
    }

    public JButton getRemoveLineItemButton() {
        return removeLineItemButton;
    }

    /** Replaces the payments table's contents. No-op in Add mode (the table doesn't exist yet). */
    public void setPayments(List<Payment> payments) {
        if (paymentTableModel != null) {
            paymentTableModel.setPayments(payments);
        }
    }

    /** Updates the Total Paid and Remaining Balance labels. No-op in Add mode. */
    public void setPaymentSummary(double totalPaid, double remainingBalance) {
        if (totalPaidValueLabel != null) {
            totalPaidValueLabel.setText(String.format("\u20B1%,.2f", totalPaid));
        }
        if (remainingBalanceValueLabel != null) {
            remainingBalanceValueLabel.setText(String.format("\u20B1%,.2f", remainingBalance));
        }
    }

    public JTable getPaymentTable() {
        return paymentTable;
    }

    public PaymentTableModel getPaymentTableModel() {
        return paymentTableModel;
    }

    public JButton getAddPaymentButton() {
        return addPaymentButton;
    }

    public JButton getEditPaymentButton() {
        return editPaymentButton;
    }

    public void setPayouts(List<TechnicianPayout> payouts, java.util.Map<Integer, Double> disbursed) { if (payoutTableModel != null) payoutTableModel.setPayouts(payouts, disbursed); }
    public void setDisbursements(List<TechnicianPayoutDisbursement> disbursements) { if (disbursementTableModel != null) disbursementTableModel.setItems(disbursements); }
    public void setPayoutSummary(Double approved, double disbursed) { if (payoutSummaryValueLabel != null) payoutSummaryValueLabel.setText(approved == null ? "Payout not negotiated yet." : String.format("Approved: ₱%,.2f   Disbursed: ₱%,.2f   Remaining: ₱%,.2f", approved, disbursed, approved - disbursed)); }
    public JTable getPayoutTable() { return payoutTable; } public TechnicianPayoutTableModel getPayoutTableModel() { return payoutTableModel; } public JButton getAddPayoutButton() { return addPayoutButton; } public JButton getEditPayoutButton() { return editPayoutButton; } public JButton getRemovePayoutButton() { return removePayoutButton; } public JButton getAddDisbursementButton() { return addDisbursementButton; }
    public void setCashAdvanceTransactions(List<JobCashAdvanceTransaction> transactions) { if(cashAdvanceTableModel!=null) cashAdvanceTableModel.setItems(transactions); }
    public void setCashAdvanceBalance(double balance) { if(cashAdvanceBalanceValueLabel!=null) cashAdvanceBalanceValueLabel.setText(String.format("Job cash-advance balance: ₱%,.2f",balance)); }
    public JButton getAddCashAdvanceButton() { return addCashAdvanceButton; }
    public JButton getAddJobExpenseButton() { return addJobExpenseButton; }
    public JButton getEditJobExpenseButton() { return editJobExpenseButton; }
    public JButton getRemoveJobExpenseButton() { return removeJobExpenseButton; }
    public JTable getJobExpenseTable() { return jobExpenseTable; }
    public ExpenseTableModel getJobExpenseTableModel() { return jobExpenseTableModel; }
    public void setJobExpenseTotal(double total) { if(jobExpenseTotalValueLabel!=null) jobExpenseTotalValueLabel.setText(String.format("Total: ₱%,.2f",total)); }
    /** Shows every recorded job expense alongside the running total for an auditable job cost ledger. */
    public void setJobExpenses(List<Expense> expenses, double total) { if(jobExpenseTableModel!=null) jobExpenseTableModel.setExpenses(expenses); setJobExpenseTotal(total); }
    public JButton getMarkBilledButton() { return markBilledButton; }
    public void setBillingStatus(String billedAt, String dueDate) { if(billingStatusValueLabel!=null) billingStatusValueLabel.setText("Billed: "+billedAt+"  Due: "+dueDate); if(markBilledButton!=null) markBilledButton.setEnabled(false); }

    public boolean confirm(String message, String title) {
        int result = JOptionPane.showConfirmDialog(this, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }

    /**
     * Populates the fields that don't depend on an asynchronously-fetched
     * list (everything except client/category selection, which
     * {@link JobFormController} handles once it has fetched the options).
     */
    private void populateScalarFieldsIfEditing() {
        if (existingJob == null) {
            return;
        }
        jobDateField.setStoredDate(existingJob.getJobDate());
        locationField.setText(existingJob.getLocation());
        descriptionArea.setText(existingJob.getDescription());
        poNumberField.setText(existingJob.getPoNumber());
        taxReductionPercentField.setText(String.format(java.util.Locale.ROOT, "%.2f", existingJob.getTaxReductionPercent()));
        notesArea.setText(existingJob.getNotes());
        statusCombo.setSelectedItem(existingJob.getJobStatus());
        if (existingJob.getCompletedAt() != null && existingJob.getCompletedAt().length() >= 10) completionDateField.setStoredDate(existingJob.getCompletedAt().substring(0, 10));
    }

    /** Replaces the client dropdown's contents. Called by the controller once clients are fetched. */
    public void setClientOptions(List<Client> clients) {
        DefaultComboBoxModel<Client> model = new DefaultComboBoxModel<>();
        for (Client client : clients) {
            model.addElement(client);
        }
        clientCombo.setModel(model);
    }

    /** Replaces the category dropdown's contents with a leading "None" (null) entry. */
    public void setServiceCategoryOptions(List<ServiceCategory> categories) {
        DefaultComboBoxModel<ServiceCategory> model = new DefaultComboBoxModel<>();
        model.addElement(null);
        for (ServiceCategory category : categories) {
            model.addElement(category);
        }
        categoryCombo.setModel(model);
    }

    /** Selects the client with the given id, if present in the current options. */
    public void selectClientById(int clientId) {
        for (int i = 0; i < clientCombo.getItemCount(); i++) {
            Client client = clientCombo.getItemAt(i);
            if (client != null && client.getId() == clientId) {
                clientCombo.setSelectedIndex(i);
                return;
            }
        }
    }

    /** Selects the category with the given id (or "None" if categoryId is null), if present. */
    public void selectServiceCategoryById(Integer categoryId) {
        if (categoryId == null) {
            categoryCombo.setSelectedItem(null);
            return;
        }
        for (int i = 0; i < categoryCombo.getItemCount(); i++) {
            ServiceCategory category = categoryCombo.getItemAt(i);
            if (category != null && category.getId() == categoryId) {
                categoryCombo.setSelectedIndex(i);
                return;
            }
        }
    }

    public Client getSelectedClient() {
        return (Client) clientCombo.getSelectedItem();
    }

    public ServiceCategory getSelectedServiceCategory() {
        return (ServiceCategory) categoryCombo.getSelectedItem();
    }

    public Job.JobStatus getSelectedStatus() {
        return (Job.JobStatus) statusCombo.getSelectedItem();
    }

    public java.time.LocalDate getJobDate() { return jobDateField.getDate(); }
    public java.time.LocalDate getActualCompletionDate() { return completionDateField.getDate(); }

    public String getLocationInput() {
        return locationField.getText();
    }

    public String getDescriptionInput() {
        return descriptionArea.getText();
    }

    public String getPoNumberInput() { return poNumberField.getText(); }

    public String getTaxReductionPercentInput() { return taxReductionPercentField.getText(); }

    public String getNotesInput() {
        return notesArea.getText();
    }

    /** Puts a red border on the given field to flag it as invalid. */
    public void markFieldInvalid(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_DANGER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }
    public void markFieldInvalid(DatePickerField field) { field.markInvalid(true); }

    /** Restores the given field's border to its normal (non-error) style. */
    public void clearFieldValidation(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDER, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));
    }
    public void clearFieldValidation(DatePickerField field) { field.markInvalid(false); }

    /** Clears a field's red "invalid" border as soon as the user edits it again. */
    private void addClearValidationOnEdit(JTextField field) {
        field.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                clearFieldValidation(field);
            }
        });
    }
    private void addClearValidationOnEdit(DatePickerField field) { field.getTextField().getDocument().addDocumentListener(new javax.swing.event.DocumentListener() { public void insertUpdate(javax.swing.event.DocumentEvent e) { field.markInvalid(false); } public void removeUpdate(javax.swing.event.DocumentEvent e) { field.markInvalid(false); } public void changedUpdate(javax.swing.event.DocumentEvent e) { field.markInvalid(false); } }); }

    public DatePickerField getJobDateField() {
        return jobDateField;
    }

    public JTextField getTaxReductionPercentField() { return taxReductionPercentField; }

    public JButton getSaveButton() {
        return saveButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public void showError(String message) {
        errorLabel.setText(message);
    }

    public void closeDialog() {
        dispose();
    }

    /** Renders a null category as "— None —" instead of the word "null". */
    private static class CategoryCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                        boolean isSelected, boolean cellHasFocus) {
            String display = (value == null) ? "\u2014 None \u2014" : value.toString();
            return super.getListCellRendererComponent(list, display, index, isSelected, cellHasFocus);
        }
    }
}
