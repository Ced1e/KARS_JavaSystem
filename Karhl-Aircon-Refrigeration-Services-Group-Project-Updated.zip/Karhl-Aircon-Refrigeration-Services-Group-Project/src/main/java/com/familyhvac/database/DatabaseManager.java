package com.familyhvac.database;

import com.familyhvac.utils.AppConstants;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Central point for obtaining JDBC connections to the application's SQLite
 * database file. Kept deliberately small: everything database-shaped
 * (schema creation, backup/restore) lives in its own class so this one
 * class has a single responsibility - handing out connections.
 *
 * SQLite connections are cheap, so rather than sharing one long-lived
 * Connection across the whole app (which causes locking headaches with
 * Swing background threads), each caller asks for a fresh connection and
 * is responsible for closing it (try-with-resources).
 */
public final class DatabaseManager {

    private static final String DB_URL = "jdbc:sqlite:" + AppConstants.DB_DIRECTORY + File.separator + AppConstants.DB_FILE_NAME;

    private static DatabaseManager instance;

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError("SQLite JDBC driver not found on classpath: " + e.getMessage());
        }
    }

    private DatabaseManager() {
        ensureDataDirectoryExists();
        migrateLegacyDatabaseFileIfPresent();
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    private void ensureDataDirectoryExists() {
        File dir = new File(AppConstants.DB_DIRECTORY);
        if (!dir.exists()) {
            boolean created = dir.mkdirs();
            if (!created) {
                throw new IllegalStateException("Unable to create database directory: " + dir.getAbsolutePath());
            }
        }
    }

    /**
     * The application used to be called "Family HVAC Business Manager" and
     * stored its data in a differently-named file. If that old file exists
     * and the new one doesn't yet, rename it in place so nobody's existing
     * clients/jobs/payments get "lost" just because the app was renamed.
     */
    private void migrateLegacyDatabaseFileIfPresent() {
        File newFile = new File(AppConstants.DB_DIRECTORY, AppConstants.DB_FILE_NAME);
        File legacyFile = new File(AppConstants.DB_DIRECTORY, AppConstants.LEGACY_DB_FILE_NAME);

        if (!newFile.exists() && legacyFile.exists()) {
            boolean renamed = legacyFile.renameTo(newFile);
            if (renamed) {
                System.out.println("Migrated existing database file '" + AppConstants.LEGACY_DB_FILE_NAME +
                        "' to '" + AppConstants.DB_FILE_NAME + "'.");
            } else {
                System.err.println("Found a legacy database file '" + AppConstants.LEGACY_DB_FILE_NAME +
                        "' but could not rename it automatically. Please rename it to '" +
                        AppConstants.DB_FILE_NAME + "' manually.");
            }
        }
    }

    /**
     * Returns a new connection with foreign key constraint enforcement turned on.
     * SQLite disables FK enforcement by default per-connection, so every
     * connection handed out must explicitly enable it.
     */
    public Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(DB_URL);
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON;");
        }
        return connection;
    }

    public String getDatabaseFilePath() {
        return AppConstants.DB_DIRECTORY + File.separator + AppConstants.DB_FILE_NAME;
    }
}

