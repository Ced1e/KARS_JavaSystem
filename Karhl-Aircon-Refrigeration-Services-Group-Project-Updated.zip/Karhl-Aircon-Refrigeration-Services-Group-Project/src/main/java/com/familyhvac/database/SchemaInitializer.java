package com.familyhvac.database;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Creates the database schema on application startup by executing
 * src/main/resources/schema.sql, then runs any column-level migrations
 * needed to bring an existing (older) database up to date.
 *
 * CREATE TABLE IF NOT EXISTS in schema.sql only helps on a brand new
 * database file - it does nothing for a table that already exists but is
 * missing a column a newer version of the app expects (e.g. adding
 * is_active to clients after people already have data). The migration
 * step below handles that case by checking PRAGMA table_info and issuing
 * ALTER TABLE ... ADD COLUMN only when the column is actually missing, so
 * it's always safe to run on every startup.
 */
public final class SchemaInitializer {

    private static final String SCHEMA_RESOURCE_PATH = "/schema.sql";

    private final DatabaseManager databaseManager;

    public SchemaInitializer(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    public void initialize() {
        runSchemaScript();
        runColumnMigrations();
    }

    private void runSchemaScript() {
        String schemaSql = readSchemaResource();
        String[] statements = schemaSql.split(";\\s*(\\r?\\n|$)");

        try (Connection connection = databaseManager.getConnection();
             Statement statement = connection.createStatement()) {

            for (String rawStatement : statements) {
                String sql = rawStatement.trim();
                if (sql.isEmpty()) {
                    continue;
                }
                statement.execute(sql);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to initialize database schema: " + e.getMessage(), e);
        }
    }

    /**
     * Column migrations for tables that may already exist from an earlier
     * version of the app. Each entry is safe to run repeatedly - it only
     * acts when the column is actually missing (or present, for drops).
     */
    private void runColumnMigrations() {
        try (Connection connection = databaseManager.getConnection()) {
            migrateClientsTable(connection);
            migrateTechniciansTable(connection);
            migrateForJobModule(connection);
            addColumnIfMissing(connection, "jobs", "ewt_2307_status", "TEXT NOT NULL DEFAULT 'NOT_YET'");
            addColumnIfMissing(connection, "jobs", "po_number", "TEXT");
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to run database migrations: " + e.getMessage(), e);
        }
    }

    /**
     * Brings the clients table up to the current field design:
     *   - is_active     : added if this DB predates soft delete
     *   - remarks       : renamed to notes (or notes added fresh if neither exists)
     *   - tin           : added
     *   - payment_terms : added, defaulting to COD
     *   - preferred_payment_method : added, defaulting to CASH
     *   - company_name  : dropped - no longer part of the client field design
     */
    private void migrateClientsTable(Connection connection) throws SQLException {
        addColumnIfMissing(connection, "clients", "is_active", "INTEGER NOT NULL DEFAULT 1");

        if (columnExists(connection, "clients", "remarks") && !columnExists(connection, "clients", "notes")) {
            renameColumn(connection, "clients", "remarks", "notes");
        }
        addColumnIfMissing(connection, "clients", "notes", "TEXT");

        addColumnIfMissing(connection, "clients", "tin", "TEXT");
        addColumnIfMissing(connection, "clients", "payment_terms", "TEXT NOT NULL DEFAULT 'COD'");
        addColumnIfMissing(connection, "clients", "preferred_payment_method", "TEXT NOT NULL DEFAULT 'CASH'");

        dropColumnIfExists(connection, "clients", "company_name");
    }

    /**
     * Brings the technicians table up to the current field design:
     *   - is_active : added if this DB predates soft delete
     *   - status    : legacy free-text ('ACTIVE'/'INACTIVE') values are
     *                 converted into is_active BEFORE the column is
     *                 dropped, so no archived/active state is lost
     *   - remarks   : renamed to notes (or notes added fresh if neither exists)
     */
    private void migrateTechniciansTable(Connection connection) throws SQLException {
        addColumnIfMissing(connection, "technicians", "is_active", "INTEGER NOT NULL DEFAULT 1");

        if (columnExists(connection, "technicians", "status")) {
            try (Statement statement = connection.createStatement()) {
                statement.execute(
                        "UPDATE technicians SET is_active = CASE WHEN UPPER(status) = 'ACTIVE' THEN 1 ELSE 0 END"
                );
                System.out.println("Migration: converted technicians.status values into is_active.");
            }
        }

        if (columnExists(connection, "technicians", "remarks") && !columnExists(connection, "technicians", "notes")) {
            renameColumn(connection, "technicians", "remarks", "notes");
        }
        addColumnIfMissing(connection, "technicians", "notes", "TEXT");

        dropColumnIfExists(connection, "technicians", "status");
    }

    /**
     * Phase 6A migration for the Job module. Three tables in the CURRENT
     * on-disk schema still need to be brought forward to the shape the
     * Job module requires:
     *
     *   - technician_payouts still has NOT NULL payout_amount / payout_date
     *     and none of is_lead / payout_method / percentage_value /
     *     negotiated_at / updated_at. SQLite cannot drop a NOT NULL
     *     constraint via ALTER TABLE, so this table is rebuilt.
     *   - jobs still has job_number (UNIQUE) and lead_technician_id on any
     *     database created before this migration existed. SQLite cannot
     *     drop a UNIQUE-constrained column via ALTER TABLE DROP COLUMN, so
     *     this table is rebuilt too. Any existing lead_technician_id value
     *     is preserved as an is_lead technician_payouts row FIRST, before
     *     the column carrying it is dropped.
     *   - job_line_items.subtotal is a plain, unconstrained column and can
     *     be dropped directly.
     *
     * Order matters: technician_payouts must be rebuilt (to gain is_lead)
     * before jobs' lead_technician_id data can be migrated into it, which
     * in turn must happen before jobs is rebuilt (which drops that
     * column). Each step is independently idempotent and skips work
     * already done, so this is safe to run on every startup.
     */
    private void migrateForJobModule(Connection connection) throws SQLException {
        rebuildTechnicianPayoutsTable(connection);
        migrateLeadTechnicianDataIntoPayouts(connection);
        rebuildJobsTable(connection);
        addColumnIfMissing(connection, "jobs", "tax_reduction_percent", "REAL NOT NULL DEFAULT 0");
        dropColumnIfExists(connection, "job_line_items", "subtotal");
    }

    /**
     * Rebuilds technician_payouts: payout_amount (NOT NULL) -> approved_amount
     * (nullable, so a technician can be assigned to a job before payout is
     * negotiated), adds is_lead/payout_method/percentage_value/negotiated_at/
     * updated_at. Skipped entirely if approved_amount already exists (a
     * fresh install already gets this shape straight from schema.sql).
     */
    private void rebuildTechnicianPayoutsTable(Connection connection) throws SQLException {
        if (columnExists(connection, "technician_payouts", "approved_amount")) {
            return;
        }

        boolean originalAutoCommit = connection.getAutoCommit();
        try (Statement pragma = connection.createStatement()) {
            pragma.execute("PRAGMA foreign_keys = OFF;");
        }
        connection.setAutoCommit(false);
        try (Statement statement = connection.createStatement()) {
            statement.execute(
                    "CREATE TABLE technician_payouts_new (" +
                    "    id                INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "    job_id            INTEGER NOT NULL," +
                    "    technician_id     INTEGER NOT NULL," +
                    "    is_lead           INTEGER NOT NULL DEFAULT 0," +
                    "    payout_method     TEXT CHECK (payout_method IS NULL OR payout_method IN ('PERCENTAGE','FIXED_AMOUNT'))," +
                    "    percentage_value  REAL," +
                    "    approved_amount   REAL," +
                    "    negotiated_at     TEXT," +
                    "    remarks           TEXT," +
                    "    created_at        TEXT NOT NULL DEFAULT (datetime('now'))," +
                    "    updated_at        TEXT NOT NULL DEFAULT (datetime('now'))," +
                    "    FOREIGN KEY (job_id)        REFERENCES jobs(id)        ON DELETE CASCADE," +
                    "    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE RESTRICT" +
                    ")"
            );
            statement.execute(
                    "INSERT INTO technician_payouts_new " +
                    "(id, job_id, technician_id, approved_amount, negotiated_at, remarks, created_at, updated_at) " +
                    "SELECT id, job_id, technician_id, payout_amount, payout_date, remarks, created_at, created_at " +
                    "FROM technician_payouts"
            );
            statement.execute("DROP TABLE technician_payouts");
            statement.execute("ALTER TABLE technician_payouts_new RENAME TO technician_payouts");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_payouts_job ON technician_payouts(job_id)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_payouts_technician ON technician_payouts(technician_id)");

            connection.commit();
            System.out.println("Migration: rebuilt technician_payouts (payout_amount -> nullable approved_amount; " +
                    "added is_lead, payout_method, percentage_value, negotiated_at, updated_at). Existing payout " +
                    "amounts and dates were preserved into approved_amount/negotiated_at.");
        } catch (SQLException e) {
            connection.rollback();
            throw new SQLException("Failed to migrate technician_payouts - existing data was NOT modified: " + e.getMessage(), e);
        } finally {
            connection.setAutoCommit(originalAutoCommit);
            try (Statement pragma = connection.createStatement()) {
                pragma.execute("PRAGMA foreign_keys = ON;");
            }
        }
    }

    /**
     * Preserves any existing jobs.lead_technician_id value as an is_lead
     * technician_payouts row before that column is dropped by
     * {@link #rebuildJobsTable}. Must run after technician_payouts has
     * been rebuilt (needs is_lead to exist) and before jobs is rebuilt
     * (needs lead_technician_id to still exist to read from). No-op if
     * jobs.lead_technician_id was already dropped by a previous run.
     */
    private void migrateLeadTechnicianDataIntoPayouts(Connection connection) throws SQLException {
        if (!columnExists(connection, "jobs", "lead_technician_id")) {
            return;
        }
        try (Statement statement = connection.createStatement()) {
            int migrated = statement.executeUpdate(
                    "INSERT INTO technician_payouts (job_id, technician_id, is_lead, created_at, updated_at) " +
                    "SELECT id, lead_technician_id, 1, datetime('now'), datetime('now') " +
                    "FROM jobs " +
                    "WHERE lead_technician_id IS NOT NULL " +
                    "AND NOT EXISTS (" +
                    "    SELECT 1 FROM technician_payouts tp " +
                    "    WHERE tp.job_id = jobs.id AND tp.technician_id = jobs.lead_technician_id" +
                    ")"
            );
            if (migrated > 0) {
                System.out.println("Migration: preserved " + migrated +
                        " existing lead-technician assignment(s) from jobs.lead_technician_id into technician_payouts.is_lead.");
            }
        }
    }

    /**
     * Rebuilds jobs: drops job_number (UNIQUE - can't be dropped via plain
     * ALTER TABLE) and lead_technician_id (its data was already preserved
     * by {@link #migrateLeadTechnicianDataIntoPayouts}), renames remarks
     * to notes, adds completed_at/billed_at, and tightens job_status to a
     * CHECK-constrained SCHEDULED/IN_PROGRESS/COMPLETED/CANCELLED
     * vocabulary (any pre-existing 'PENDING' or unrecognized value maps to
     * SCHEDULED). Skipped entirely if job_number no longer exists (a fresh
     * install already gets this shape straight from schema.sql).
     */
    private void rebuildJobsTable(Connection connection) throws SQLException {
        if (!columnExists(connection, "jobs", "job_number")) {
            return;
        }

        boolean originalAutoCommit = connection.getAutoCommit();
        try (Statement pragma = connection.createStatement()) {
            pragma.execute("PRAGMA foreign_keys = OFF;");
        }
        connection.setAutoCommit(false);
        try (Statement statement = connection.createStatement()) {
            statement.execute("DROP INDEX IF EXISTS idx_jobs_technician");
            statement.execute(
                    "CREATE TABLE jobs_new (" +
                    "    id                    INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "    client_id             INTEGER NOT NULL," +
                    "    service_category_id   INTEGER," +
                    "    job_date              TEXT NOT NULL," +
                    "    location              TEXT," +
                    "    description           TEXT," +
                    "    job_status            TEXT NOT NULL DEFAULT 'SCHEDULED' " +
                    "                              CHECK (job_status IN ('SCHEDULED','IN_PROGRESS','COMPLETED','CANCELLED'))," +
                    "    completed_at          TEXT," +
                    "    billed_at             TEXT," +
                    "    payment_due_date      TEXT," +
                    "    tax_reduction_percent REAL NOT NULL DEFAULT 0," +
                    "    notes                 TEXT," +
                    "    created_at            TEXT NOT NULL DEFAULT (datetime('now'))," +
                    "    updated_at            TEXT NOT NULL DEFAULT (datetime('now'))," +
                    "    FOREIGN KEY (client_id)           REFERENCES clients(id)             ON DELETE RESTRICT," +
                    "    FOREIGN KEY (service_category_id) REFERENCES service_categories(id)  ON DELETE SET NULL" +
                    ")"
            );
            statement.execute(
                    "INSERT INTO jobs_new " +
                    "(id, client_id, service_category_id, job_date, location, description, job_status, " +
                    " payment_due_date, tax_reduction_percent, notes, created_at, updated_at) " +
                    "SELECT id, client_id, service_category_id, job_date, location, description, " +
                    "       CASE WHEN job_status IN ('SCHEDULED','IN_PROGRESS','COMPLETED','CANCELLED') " +
                    "            THEN job_status ELSE 'SCHEDULED' END, " +
                    "       payment_due_date, 0, remarks, created_at, updated_at " +
                    "FROM jobs"
            );
            statement.execute("DROP TABLE jobs");
            statement.execute("ALTER TABLE jobs_new RENAME TO jobs");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_jobs_client ON jobs(client_id)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(job_status)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_jobs_date ON jobs(job_date)");

            connection.commit();
            System.out.println("Migration: rebuilt jobs (dropped job_number and lead_technician_id, renamed " +
                    "remarks -> notes, added completed_at/billed_at, constrained job_status to " +
                    "SCHEDULED/IN_PROGRESS/COMPLETED/CANCELLED - any legacy 'PENDING' value was mapped to SCHEDULED).");
        } catch (SQLException e) {
            connection.rollback();
            throw new SQLException("Failed to migrate jobs table - existing data was NOT modified: " + e.getMessage(), e);
        } finally {
            connection.setAutoCommit(originalAutoCommit);
            try (Statement pragma = connection.createStatement()) {
                pragma.execute("PRAGMA foreign_keys = ON;");
            }
        }
    }

    private void addColumnIfMissing(Connection connection, String table, String column, String columnDefinition) throws SQLException {
        if (columnExists(connection, table, column)) {
            return;
        }
        // Table/column names here are fixed internal strings controlled by this class,
        // never user input, so string-building the DDL is safe. JDBC cannot parameterize
        // identifiers in ALTER TABLE statements regardless.
        try (Statement statement = connection.createStatement()) {
            statement.execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + columnDefinition);
            System.out.println("Migration: added column '" + column + "' to table '" + table + "'.");
        }
    }

    private void renameColumn(Connection connection, String table, String oldName, String newName) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.execute("ALTER TABLE " + table + " RENAME COLUMN " + oldName + " TO " + newName);
            System.out.println("Migration: renamed column '" + oldName + "' to '" + newName + "' on table '" + table + "'.");
        }
    }

    private void dropColumnIfExists(Connection connection, String table, String column) throws SQLException {
        if (!columnExists(connection, table, column)) {
            return;
        }
        try (Statement statement = connection.createStatement()) {
            statement.execute("ALTER TABLE " + table + " DROP COLUMN " + column);
            System.out.println("Migration: dropped column '" + column + "' from table '" + table + "'.");
        } catch (SQLException e) {
            // Older SQLite builds (pre-3.35) don't support DROP COLUMN. Non-fatal:
            // the column just becomes an unused legacy field that nothing reads or writes.
            System.err.println("Could not drop column '" + column + "' from table '" + table +
                    "' (" + e.getMessage() + "). Leaving it in place; the application no longer uses it.");
        }
    }

    private boolean columnExists(Connection connection, String table, String column) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("PRAGMA table_info(" + table + ")")) {
            while (resultSet.next()) {
                if (resultSet.getString("name").equalsIgnoreCase(column)) {
                    return true;
                }
            }
        }
        return false;
    }

    private String readSchemaResource() {
        try (InputStream inputStream = SchemaInitializer.class.getResourceAsStream(SCHEMA_RESOURCE_PATH)) {
            if (inputStream == null) {
                throw new IllegalStateException("Could not find " + SCHEMA_RESOURCE_PATH + " on the classpath.");
            }
            StringBuilder builder = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // Strip full-line SQL comments so they don't interfere with statement splitting
                    String trimmedLine = line.trim();
                    if (trimmedLine.startsWith("--")) {
                        continue;
                    }
                    builder.append(line).append('\n');
                }
            }
            return builder.toString();
        } catch (IOException e) {
            throw new IllegalStateException("Failed to read schema.sql: " + e.getMessage(), e);
        }
    }
}
