package com.familyhvac.services;

import com.familyhvac.dao.ServiceCategoryDAO;
import com.familyhvac.models.ServiceCategory;

import java.util.List;
import java.util.Optional;

/**
 * Read-only service over service categories, used to populate a Job's
 * category dropdown and resolve category names for display. No
 * create/edit/archive here - see {@link ServiceCategoryDAO}.
 */
public class ServiceCategoryService {

    private final ServiceCategoryDAO serviceCategoryDAO;

    public ServiceCategoryService() {
        this.serviceCategoryDAO = new ServiceCategoryDAO();
    }

    public List<ServiceCategory> listActiveCategories() {
        return serviceCategoryDAO.findAllActive();
    }

    public List<ServiceCategory> listAllCategories() {
        return serviceCategoryDAO.findAll();
    }

    public Optional<ServiceCategory> getCategoryById(int id) {
        return serviceCategoryDAO.findById(id);
    }
}
