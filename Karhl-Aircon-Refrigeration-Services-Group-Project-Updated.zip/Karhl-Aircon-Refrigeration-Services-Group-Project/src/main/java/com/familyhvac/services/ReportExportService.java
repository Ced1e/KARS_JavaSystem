package com.familyhvac.services;

import com.familyhvac.dao.AnalyticsDAO;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Creates ink-friendly PDF and DOCX Work Reports without external libraries. */
public class ReportExportService {
    public void exportDocx(Path target, String title, String period, String summary,
                           List<AnalyticsDAO.JobReportRow> jobs,
                           List<AnalyticsDAO.ExpenseReportRow> expenses) throws IOException {
        try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(target))) {
            put(zip, "[Content_Types].xml", "<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>");
            put(zip, "_rels/.rels", "<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");

            StringBuilder document = new StringBuilder("<?xml version=\"1.0\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
            document.append(p("Karhl Aircon & Refrigeration Services", true));
            document.append(p("806-A Marfori Street, DDF Village, Buhangin District, Davao City", false));
            document.append(p("Contact No. GLOBE: 0905396594", false));
            document.append(p(title, true)).append(p(period, false));
            for (String item : summary.split(" \\| ")) document.append(p(item, false));
            document.append(p("Job Revenue and Direct Expenses", true));
            document.append(jobTable(jobs));
            document.append(p("Operating Expense Details", true));
            document.append(expenseTable(expenses));
            document.append("<w:sectPr><w:pgSz w:w=\"15840\" w:h=\"12240\" w:orient=\"landscape\"/><w:pgMar w:left=\"540\" w:right=\"540\" w:top=\"540\" w:bottom=\"540\"/></w:sectPr></w:body></w:document>");
            put(zip, "word/document.xml", document.toString());
        }
    }

    /** Landscape, black-and-gray PDF designed to be economical to print. */
    public void exportPdf(Path target, String title, String period, String summary,
                          List<AnalyticsDAO.JobReportRow> jobs,
                          List<AnalyticsDAO.ExpenseReportRow> expenses) throws IOException {
        List<String> pages = new ArrayList<>();
        int jobRowsPerPage = 14;
        int jobPages = Math.max(1, (int) Math.ceil(jobs.size() / (double) jobRowsPerPage));
        for (int offset = 0; offset < Math.max(1, jobs.size()); offset += jobRowsPerPage) {
            int end = Math.min(jobs.size(), offset + jobRowsPerPage);
            pages.add(jobPage(title, period, summary, jobs.subList(offset, end), offset / jobRowsPerPage + 1, jobPages));
        }
        List<List<AnalyticsDAO.ExpenseReportRow>> expensePages = paginateExpenses(expenses);
        for (int index = 0; index < expensePages.size(); index++) {
            pages.add(expensePage(period, expensePages.get(index), index + 1, expensePages.size()));
        }
        writePdf(target, pages);
    }

    private String jobPage(String title, String period, String summary, List<AnalyticsDAO.JobReportRow> rows, int page, int pages) {
        StringBuilder output = pdfHeader(title, period, summary);
        int top = 421;
        int[] positions = {36, 92, 155, 274, 382, 470, 560, 660};
        tableHeader(output, top, new String[]{"Date", "Job", "Client", "Category", "Gross", "Tax Reduction", "Net Total", "Expenses"}, positions);
        int y = top - 23;
        for (AnalyticsDAO.JobReportRow row : rows) {
            String[] values = {row.jobDate(), row.jobCode(), cut(row.clientName(), 19), cut(row.category(), 15), money(row.grossTotal()),
                    money(row.taxAmount()), money(row.netTotal()), money(row.expenseTotal())};
            for (int i = 0; i < values.length; i++) text(output, values[i], positions[i], y, 7, false);
            divider(output, y - 8);
            y -= 22;
        }
        text(output, "See the following Operating Expense Details schedule for the full expense type and description.", 42, 44, 8, false);
        footer(output, "Job revenue and expenses — page " + page + " of " + pages);
        return output.toString();
    }

    private String expensePage(String period, List<AnalyticsDAO.ExpenseReportRow> rows, int page, int pages) {
        StringBuilder output = pdfHeader("Operating Expense Details", period, "Each expense is shown separately for bookkeeping.");
        int top = 449;
        int[] positions = {42, 120, 185, 330, 680};
        tableHeader(output, top, new String[]{"Expense Date", "Job", "Client", "Expense Type and Description", "Amount"}, positions);
        int y = top - 23;
        for (AnalyticsDAO.ExpenseReportRow row : rows) {
            List<String> details = wrap(expenseDetail(row), 50);
            text(output, row.expenseDate(), positions[0], y, 8, false);
            text(output, row.jobCode(), positions[1], y, 8, false);
            text(output, cut(row.clientName(), 24), positions[2], y, 8, false);
            text(output, money(row.amount()), positions[4], y, 8, false);
            for (int line = 0; line < details.size(); line++) text(output, details.get(line), positions[3], y - line * 10, 8, false);
            int height = expenseHeight(row);
            divider(output, y - height + 7);
            y -= height;
        }
        footer(output, "Operating expense details — page " + page + " of " + pages);
        return output.toString();
    }

    private StringBuilder pdfHeader(String title, String period, String summary) {
        StringBuilder output = new StringBuilder();
        text(output, "Karhl Aircon & Refrigeration Services", 42, 590, 15, true);
        text(output, "806-A Marfori Street, DDF Village, Buhangin District, Davao City", 42, 573, 9, false);
        text(output, "Contact No. GLOBE: 0905396594", 42, 559, 9, false);
        text(output, title, 42, 522, 18, true);
        text(output, period.replace("Period: ", "Reporting period: "), 42, 503, 10, false);
        int y = 484;
        for (String item : summary.split(" \\| ")) { text(output, item, 42, y, 9, true); y -= 14; }
        return output;
    }

    private void tableHeader(StringBuilder output, int top, String[] labels, int[] positions) {
        output.append("0.92 g 32 ").append(top - 18).append(" 728 18 re f\n");
        for (int i = 0; i < labels.length; i++) text(output, labels[i], positions[i], top - 12, 7, true);
    }
    private void divider(StringBuilder output, int y) { output.append("0.75 G 32 ").append(y).append(" m 760 ").append(y).append(" l S\n"); }
    private void footer(StringBuilder output, String footer) { text(output, "Generated by Karhl Aircon & Refrigeration Services", 42, 28, 8, false); text(output, footer, 500, 28, 8, false); }

    private String jobTable(List<AnalyticsDAO.JobReportRow> jobs) {
        StringBuilder table = new StringBuilder(docTableStart());
        table.append(docRow(new String[]{"Date", "Job", "Client", "Category", "Gross Total", "Tax Reduction", "Net Total", "Expenses"}, true, 1600));
        for (AnalyticsDAO.JobReportRow row : jobs) table.append(docRow(new String[]{row.jobDate(), row.jobCode(), row.clientName(), row.category(), money(row.grossTotal()), money(row.taxAmount()), money(row.netTotal()), money(row.expenseTotal())}, false, 1600));
        return table.append("</w:tbl>").toString();
    }

    private String expenseTable(List<AnalyticsDAO.ExpenseReportRow> expenses) {
        StringBuilder table = new StringBuilder(docTableStart());
        table.append(docRow(new String[]{"Expense Date", "Job", "Client", "Expense Type and Description", "Amount"}, true, 2500));
        for (AnalyticsDAO.ExpenseReportRow row : expenses) table.append(docRow(new String[]{row.expenseDate(), row.jobCode(), row.clientName(), expenseDetail(row), money(row.amount())}, false, 2500));
        return table.append("</w:tbl>").toString();
    }

    private String docTableStart() { return "<w:tbl><w:tblPr><w:tblW w:w=\"0\" w:type=\"auto\"/><w:tblBorders><w:top w:val=\"single\" w:sz=\"4\"/><w:left w:val=\"single\" w:sz=\"4\"/><w:bottom w:val=\"single\" w:sz=\"4\"/><w:right w:val=\"single\" w:sz=\"4\"/><w:insideH w:val=\"single\" w:sz=\"2\"/><w:insideV w:val=\"single\" w:sz=\"2\"/></w:tblBorders></w:tblPr>"; }
    private String docRow(String[] cells, boolean bold, int width) { StringBuilder row = new StringBuilder("<w:tr>"); for (String cell : cells) row.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(width).append("\" w:type=\"dxa\"/></w:tcPr>").append(p(cell, bold)).append("</w:tc>"); return row.append("</w:tr>").toString(); }

    private void text(StringBuilder output, String value, int x, int y, int size, boolean bold) { output.append("0 0 0 rg BT /").append(bold ? "F2" : "F1").append(' ').append(size).append(" Tf ").append(x).append(' ').append(y).append(" Td (").append(pdfEscape(value)).append(") Tj ET\n"); }
    private String money(double value) { return String.format(Locale.ROOT, "PHP %,.2f", value); }
    private String blankAsDash(String value) { return value == null || value.isBlank() ? "-" : value; }
    private String cut(String value, int max) { value = blankAsDash(value); return value.length() > max ? value.substring(0, Math.max(0, max - 3)) + "..." : value; }
    private String expenseDetail(AnalyticsDAO.ExpenseReportRow row) { return row.expenseCategory() + (row.description() == null || row.description().isBlank() ? "" : " - " + row.description()); }
    private int expenseHeight(AnalyticsDAO.ExpenseReportRow row) { return Math.max(22, wrap(expenseDetail(row), 50).size() * 10 + 13); }
    private List<List<AnalyticsDAO.ExpenseReportRow>> paginateExpenses(List<AnalyticsDAO.ExpenseReportRow> expenses) {
        List<List<AnalyticsDAO.ExpenseReportRow>> pages = new ArrayList<>();
        List<AnalyticsDAO.ExpenseReportRow> current = new ArrayList<>();
        int remaining = 360;
        for (AnalyticsDAO.ExpenseReportRow row : expenses) {
            int height = expenseHeight(row);
            if (!current.isEmpty() && height > remaining) { pages.add(current); current = new ArrayList<>(); remaining = 360; }
            current.add(row); remaining -= height;
        }
        if (!current.isEmpty() || pages.isEmpty()) pages.add(current);
        return pages;
    }
    private List<String> wrap(String value, int width) {
        List<String> lines = new ArrayList<>(); String remaining = blankAsDash(value).trim();
        while (remaining.length() > width) {
            int split = remaining.lastIndexOf(' ', width);
            if (split < 1) split = width;
            lines.add(remaining.substring(0, split).trim()); remaining = remaining.substring(split).trim();
        }
        lines.add(remaining); return lines;
    }
    private String pdfEscape(String value) { return blankAsDash(value).replaceAll("[^\\x20-\\x7E]", " ").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)"); }

    private void writePdf(Path target, List<String> streams) throws IOException {
        List<String> objects = new ArrayList<>(); int pageCount = streams.size(); objects.add("<</Type/Catalog/Pages 2 0 R>>");
        StringBuilder kids = new StringBuilder("<</Type/Pages/Count ").append(pageCount).append("/Kids["); for (int i = 0; i < pageCount; i++) kids.append(3 + i * 2).append(" 0 R "); objects.add(kids.append("]>>").toString());
        for (int i = 0; i < pageCount; i++) { int page = 3 + i * 2, content = page + 1; objects.add("<</Type/Page/Parent 2 0 R/MediaBox[0 0 792 612]/Resources<</Font<</F1 " + (3 + pageCount * 2) + " 0 R/F2 " + (4 + pageCount * 2) + " 0 R>>>>/Contents " + content + " 0 R>>"); String data = streams.get(i); objects.add("<</Length " + data.getBytes(StandardCharsets.US_ASCII).length + ">>stream\n" + data + "endstream"); }
        objects.add("<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>"); objects.add("<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold>>");
        StringBuilder pdf = new StringBuilder("%PDF-1.4\n"); List<Integer> offsets = new ArrayList<>(); offsets.add(0); for (int i = 0; i < objects.size(); i++) { offsets.add(pdf.length()); pdf.append(i + 1).append(" 0 obj\n").append(objects.get(i)).append("\nendobj\n"); }
        int start = pdf.length(); pdf.append("xref\n0 ").append(objects.size() + 1).append("\n0000000000 65535 f \n"); for (int offset : offsets.subList(1, offsets.size())) pdf.append(String.format(Locale.ROOT, "%010d 00000 n \n", offset)); pdf.append("trailer<</Size ").append(objects.size() + 1).append("/Root 1 0 R>>\nstartxref\n").append(start).append("\n%%EOF");
        Files.writeString(target, pdf.toString(), StandardCharsets.US_ASCII);
    }

    private void put(ZipOutputStream zip, String name, String text) throws IOException { zip.putNextEntry(new ZipEntry(name)); zip.write(text.getBytes(StandardCharsets.UTF_8)); zip.closeEntry(); }
    private String p(String text, boolean bold) { return "<w:p><w:r>" + (bold ? "<w:rPr><w:b/></w:rPr>" : "") + "<w:t xml:space=\"preserve\">" + xml(blankAsDash(text)) + "</w:t></w:r></w:p>"; }
    private String xml(String value) { return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }
}
