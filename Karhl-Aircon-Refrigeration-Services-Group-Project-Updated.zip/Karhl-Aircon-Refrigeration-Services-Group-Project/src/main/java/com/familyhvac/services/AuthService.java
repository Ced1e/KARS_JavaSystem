package com.familyhvac.services;

import com.familyhvac.dao.ActivityLogDAO;
import com.familyhvac.dao.UserDAO;
import com.familyhvac.models.User;
import com.familyhvac.utils.PasswordUtil;
import com.familyhvac.utils.SessionManager;

import java.util.Optional;

/**
 * Business logic for authentication. Views/controllers never talk to
 * UserDAO or PasswordUtil directly for login purposes - they go through
 * this service, which is where rules like "account must be active" live.
 */
public class AuthService {

    private final UserDAO userDAO;
    private final ActivityLogDAO activityLogDAO;
    private final SessionManager sessionManager;

    public AuthService() {
        this.userDAO = new UserDAO();
        this.activityLogDAO = new ActivityLogDAO();
        this.sessionManager = SessionManager.getInstance();
    }

    /**
     * Result of a login attempt, including a human-readable reason on failure
     * so the UI can show something more useful than a generic error.
     */
    public static class LoginResult {
        private final boolean success;
        private final String message;
        private final User user;

        private LoginResult(boolean success, String message, User user) {
            this.success = success;
            this.message = message;
            this.user = user;
        }

        public static LoginResult success(User user) {
            return new LoginResult(true, "Login successful.", user);
        }

        public static LoginResult failure(String message) {
            return new LoginResult(false, message, null);
        }

        public boolean isSuccess() {
            return success;
        }

        public String getMessage() {
            return message;
        }

        public User getUser() {
            return user;
        }
    }

    public LoginResult login(String username, String plainTextPassword) {
        if (username == null || username.isBlank() || plainTextPassword == null || plainTextPassword.isBlank()) {
            return LoginResult.failure("Username and password are required.");
        }

        Optional<User> userOptional = userDAO.findByUsername(username.trim());
        if (userOptional.isEmpty()) {
            return LoginResult.failure("Invalid username or password.");
        }

        User user = userOptional.get();

        if (!user.isActive()) {
            return LoginResult.failure("This account has been disabled. Contact the administrator.");
        }

        if (!PasswordUtil.matches(plainTextPassword, user.getPasswordHash())) {
            activityLogDAO.log(user.getId(), "LOGIN_FAILED", "USER", user.getId(), "Incorrect password");
            return LoginResult.failure("Invalid username or password.");
        }

        sessionManager.startSession(user);
        activityLogDAO.log(user.getId(), "LOGIN", "USER", user.getId(), "User logged in successfully");

        return LoginResult.success(user);
    }

    public void logout() {
        User current = sessionManager.getCurrentUser();
        if (current != null) {
            activityLogDAO.log(current.getId(), "LOGOUT", "USER", current.getId(), "User logged out");
        }
        sessionManager.endSession();
    }

    /**
     * Creates the very first administrator account. Only intended to be
     * called by the startup bootstrap logic when the users table is empty.
     */
    public User createInitialAdmin(String username, String plainTextPassword, String fullName) {
        User user = new User();
        user.setUsername(username);
        user.setPasswordHash(PasswordUtil.hash(plainTextPassword));
        user.setFullName(fullName);
        user.setRole(User.Role.ADMIN);
        user.setActive(true);
        return userDAO.insert(user);
    }

    public boolean hasAnyUsers() {
        return userDAO.countUsers() > 0;
    }
}
