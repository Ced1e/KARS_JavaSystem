package com.familyhvac.services;

import com.familyhvac.dao.ActivityLogDAO;
import com.familyhvac.dao.JobLineItemDAO;
import com.familyhvac.models.JobLineItem;
import com.familyhvac.models.User;
import com.familyhvac.utils.SessionManager;

import java.util.List;
import java.util.Optional;

/**
 * Business logic for job line items. Views/controllers never talk to
 * JobLineItemDAO directly. Activity is logged against entity_type "JOB"
 * (with the parent job's id) rather than a line item's own id, so a
 * future Job Details "Activity" tab can show a single, coherent history
 * for the job without needing to know about line items specifically.
 */
public class JobLineItemService {

    private final JobLineItemDAO jobLineItemDAO;
    private final ActivityLogDAO activityLogDAO;
    private final SessionManager sessionManager;

    public JobLineItemService() {
        this.jobLineItemDAO = new JobLineItemDAO();
        this.activityLogDAO = new ActivityLogDAO();
        this.sessionManager = SessionManager.getInstance();
    }

    public List<JobLineItem> listLineItemsForJob(int jobId) {
        return jobLineItemDAO.findByJobId(jobId);
    }

    public Optional<JobLineItem> getLineItemById(int id) {
        return jobLineItemDAO.findById(id);
    }

    /** The job's total: SUM(quantity * unit_price) across its line items, computed in SQL. */
    public double calculateJobTotal(int jobId) {
        return jobLineItemDAO.calculateJobTotal(jobId);
    }

    public ServiceResult<JobLineItem> addLineItem(JobLineItem lineItem) {
        String validationError = validate(lineItem);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        JobLineItem saved = jobLineItemDAO.insert(lineItem);
        logActivity("ADD_LINE_ITEM", saved.getJobId(),
                "Added line item: " + saved.getDescription() + " (qty " + saved.getQuantity() +
                        " @ " + saved.getUnitPrice() + ")");
        return ServiceResult.success(saved, "Line item added.");
    }

    public ServiceResult<JobLineItem> updateLineItem(JobLineItem lineItem) {
        String validationError = validate(lineItem);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        boolean updated = jobLineItemDAO.update(lineItem);
        if (!updated) {
            return ServiceResult.failure("Line item not found, or no changes were saved.");
        }
        logActivity("UPDATE_LINE_ITEM", lineItem.getJobId(), "Updated line item: " + lineItem.getDescription());
        return ServiceResult.success(lineItem, "Line item updated.");
    }

    public ServiceResult<Void> removeLineItem(int lineItemId) {
        Optional<JobLineItem> existing = jobLineItemDAO.findById(lineItemId);
        if (existing.isEmpty()) {
            return ServiceResult.failure("Line item not found.");
        }

        boolean removed = jobLineItemDAO.deleteById(lineItemId);
        if (!removed) {
            return ServiceResult.failure("Line item not found.");
        }
        logActivity("REMOVE_LINE_ITEM", existing.get().getJobId(), "Removed line item: " + existing.get().getDescription());
        return ServiceResult.success(null, "Line item removed.");
    }

    private String validate(JobLineItem lineItem) {
        if (lineItem == null) {
            return "Line item data is missing.";
        }
        if (lineItem.getJobId() <= 0) {
            return "Line item must belong to a job.";
        }
        if (lineItem.getDescription() == null || lineItem.getDescription().isBlank()) {
            return "Description is required.";
        }
        if (lineItem.getQuantity() <= 0) {
            return "Quantity must be greater than zero.";
        }
        if (lineItem.getUnitPrice() < 0) {
            return "Unit price cannot be negative.";
        }
        return null;
    }

    private void logActivity(String action, Integer jobId, String details) {
        User currentUser = sessionManager.getCurrentUser();
        Integer userId = currentUser != null ? currentUser.getId() : null;
        activityLogDAO.log(userId, action, "JOB", jobId, details);
    }
}
