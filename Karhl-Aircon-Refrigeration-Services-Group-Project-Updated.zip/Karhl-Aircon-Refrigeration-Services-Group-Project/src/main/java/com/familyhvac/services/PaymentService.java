package com.familyhvac.services;

import com.familyhvac.dao.ActivityLogDAO;
import com.familyhvac.dao.PaymentDAO;
import com.familyhvac.models.Payment;
import com.familyhvac.models.Job;
import com.familyhvac.models.User;
import com.familyhvac.utils.SessionManager;

import java.util.List;
import java.util.Optional;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.regex.Pattern;

/**
 * Business logic for client payments against a job. Views/controllers
 * never talk to PaymentDAO directly. Activity is logged against
 * entity_type "JOB" (with the parent job's id), same as
 * {@link JobLineItemService}, so a future Job Details "Activity" tab
 * shows one coherent history.
 *
 * Client payments are cash flow, not revenue. This service only records
 * what was received; it never computes or stores job revenue, balance,
 * or payment status.
 */
public class PaymentService {

    private static final Pattern ISO_DATE_PATTERN = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");

    private final PaymentDAO paymentDAO;
    private final ActivityLogDAO activityLogDAO;
    private final SessionManager sessionManager;

    public PaymentService() {
        this.paymentDAO = new PaymentDAO();
        this.activityLogDAO = new ActivityLogDAO();
        this.sessionManager = SessionManager.getInstance();
    }

    public List<Payment> listPaymentsForJob(int jobId) {
        return paymentDAO.findByJobId(jobId);
    }

    public Optional<Payment> getPaymentById(int id) {
        return paymentDAO.findById(id);
    }

    /** Total received on a job: SUM(amount) across its payments, computed in SQL. */
    public double calculateTotalPaid(int jobId) {
        return paymentDAO.calculateTotalPaid(jobId);
    }

    /**
     * Amount a client is expected to pay after EWT.  Payment screens and
     * balance checks share this calculation so an EWT withholding never
     * becomes a false outstanding balance.
     */
    public static double calculateExpectedNetAmount(double grossAmount, double taxReductionPercent) {
        double percent = Math.max(0, Math.min(100, taxReductionPercent));
        return grossAmount * (1 - percent / 100.0);
    }

    /**
     * Age of an unpaid balance. Uses the actual billing date when present, then
     * completion date, and finally the scheduled job date so every unpaid job
     * has a visible, explainable age.
     */
    public Integer calculateDaysOutstanding(Job job, double expectedNetAmount, double paidAmount) {
        if (job == null || paidAmount >= expectedNetAmount) {
            return null;
        }
        try {
            String date = firstUsableDate(job.getBilledAt(), job.getCompletedAt(), job.getJobDate());
            if (date == null) return null;
            LocalDate outstandingSince = LocalDate.parse(date.substring(0, 10));
            return (int) Math.max(0, ChronoUnit.DAYS.between(outstandingSince, LocalDate.now()));
        } catch (RuntimeException invalidStoredDate) {
            return null;
        }
    }

    private String firstUsableDate(String... values) {
        for (String value : values) if (value != null && !value.isBlank()) return value.trim();
        return null;
    }

    public ServiceResult<Payment> addPayment(Payment payment) {
        String validationError = validate(payment);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        Payment saved = paymentDAO.insert(payment);
        logActivity("ADD_PAYMENT", saved.getJobId(),
                "Recorded payment of " + saved.getAmount() + " (" + saved.getPaymentType() + ")");
        return ServiceResult.success(saved, "Payment recorded.");
    }

    public ServiceResult<Payment> updatePayment(Payment payment) {
        String validationError = validate(payment);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        boolean updated = paymentDAO.update(payment);
        if (!updated) {
            return ServiceResult.failure("Payment not found, or no changes were saved.");
        }
        logActivity("UPDATE_PAYMENT", payment.getJobId(), "Updated payment id=" + payment.getId());
        return ServiceResult.success(payment, "Payment updated.");
    }

    private String validate(Payment payment) {
        if (payment == null) {
            return "Payment data is missing.";
        }
        if (payment.getJobId() <= 0) {
            return "Payment must belong to a job.";
        }
        if (payment.getPaymentDate() == null || payment.getPaymentDate().isBlank()) {
            return "Payment date is required.";
        }
        if (!ISO_DATE_PATTERN.matcher(payment.getPaymentDate().trim()).matches()) {
            return "Payment date must be in YYYY-MM-DD format.";
        }
        if (payment.getAmount() <= 0) {
            return "Payment amount must be greater than zero.";
        }
        if (payment.getPaymentType() == null) {
            return "Payment type is required.";
        }
        return null;
    }

    private void logActivity(String action, Integer jobId, String details) {
        User currentUser = sessionManager.getCurrentUser();
        Integer userId = currentUser != null ? currentUser.getId() : null;
        activityLogDAO.log(userId, action, "JOB", jobId, details);
    }
}
