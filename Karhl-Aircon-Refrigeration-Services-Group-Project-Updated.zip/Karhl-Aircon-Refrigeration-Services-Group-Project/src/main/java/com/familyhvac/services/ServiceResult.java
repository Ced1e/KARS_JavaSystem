package com.familyhvac.services;

/**
 * Generic outcome of a service-layer operation: either success (carrying
 * the resulting data, e.g. a saved entity) or failure (carrying a
 * human-readable message suitable for display directly in the UI).
 *
 * Introduced so every future service (Job, Payment, Expense,
 * Technician, ...) can report validation/duplicate/not-found failures the
 * same way {@link AuthService.LoginResult} already does for login,
 * without each service re-inventing its own result type.
 *
 * @param <T> the type of data returned on success (use {@code Void} for
 *            operations that don't return anything, e.g. a delete)
 */
public class ServiceResult<T> {

    private final boolean success;
    private final String message;
    private final T data;

    private ServiceResult(boolean success, String message, T data) {
        this.success = success;
        this.message = message;
        this.data = data;
    }

    public static <T> ServiceResult<T> success(T data, String message) {
        return new ServiceResult<>(true, message, data);
    }

    public static <T> ServiceResult<T> failure(String message) {
        return new ServiceResult<>(false, message, null);
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }
}
