package com.familyhvac.services;

import com.familyhvac.dao.ActivityLogDAO;
import com.familyhvac.dao.JobDAO;
import com.familyhvac.dao.ClientDAO;
import com.familyhvac.models.Client;
import com.familyhvac.models.Job;
import com.familyhvac.models.User;
import com.familyhvac.utils.SessionManager;

import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * Business logic for jobs. Views/controllers never talk to JobDAO
 * directly - they go through this service, which is where the
 * completed_at auto-management rule and job-header validation live.
 *
 * Jobs normally use {@link Job.JobStatus#CANCELLED} when work did not happen.
 * A separate permanent-delete action exists only for genuinely duplicate or
 * erroneous records and removes their linked records as one transaction.
 */
public class JobService {

    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final java.util.regex.Pattern ISO_DATE_PATTERN = java.util.regex.Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");

    private final JobDAO jobDAO;
    private final ActivityLogDAO activityLogDAO;
    private final SessionManager sessionManager;

    public JobService() {
        this.jobDAO = new JobDAO();
        this.activityLogDAO = new ActivityLogDAO();
        this.sessionManager = SessionManager.getInstance();
    }

    public List<Job> listAllJobs() {
        return jobDAO.findAll();
    }

    public List<Job> listJobsForClient(int clientId) {
        return jobDAO.findByClientId(clientId);
    }

    /**
     * Searches jobs by Job Code/client name/location/description with an
     * optional status filter. When both the query is blank and no status
     * filter is set, this is equivalent to {@link #listAllJobs()}.
     */
    public List<Job> searchJobs(String query, Job.JobStatus statusFilter) {
        boolean hasQuery = query != null && !query.isBlank();
        if (!hasQuery && statusFilter == null) {
            return listAllJobs();
        }
        return jobDAO.search(query, statusFilter);
    }

    /** Shared list-screen filtering; the DAO keeps all search work in SQLite. */
    public List<Job> searchJobs(String query, Job.JobStatus statusFilter, Integer categoryId,
                                LocalDate fromDate, LocalDate toDate) {
        return jobDAO.search(query, statusFilter, categoryId, fromDate, toDate);
    }

    public Optional<Job> getJobById(int id) {
        return jobDAO.findById(id);
    }

    /** Permanently removes a duplicate/erroneous job and all records linked to it. */
    public ServiceResult<Void> deleteJob(int jobId) {
        Optional<Job> existing = jobDAO.findById(jobId);
        if (existing.isEmpty()) return ServiceResult.failure("Job not found.");
        Job job = existing.get();
        if (!jobDAO.deleteWithRelatedRecords(jobId)) return ServiceResult.failure("Job could not be deleted.");
        logActivity("DELETE_JOB", jobId, "Permanently deleted " + job.getJobCode() + " and its linked expenses, payouts, payments, cash advances, and line items.");
        return ServiceResult.success(null, "Job deleted successfully.");
    }

    /**
     * Creates a new job. Status always starts SCHEDULED and completed_at/
     * billed_at always start unset, regardless of what the caller passed in
     * - a brand new job cannot already be completed or billed.
     */
    public ServiceResult<Job> createJob(Job job) {
        String validationError = validate(job);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        job.setJobStatus(Job.JobStatus.SCHEDULED);
        job.setCompletedAt(null);
        job.setBilledAt(null);

        Job saved = jobDAO.insert(job);
        logActivity("CREATE_JOB", saved.getId(), "Created job " + saved.getJobCode());
        return ServiceResult.success(saved, "Job created successfully.");
    }

    /**
     * Updates a job's header fields (client, category, date, location,
     * description, payment due date, notes). Deliberately does NOT accept
     * changes to job_status, completed_at, or billed_at through this
     * method - those are managed by {@link #updateJobStatus} and the
     * future billing action, never as a side effect of an unrelated edit.
     * Whatever the passed-in Job object has in those three fields is
     * overwritten with the current database values before saving.
     */
    public ServiceResult<Job> updateJob(Job job) {
        String validationError = validate(job);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        Optional<Job> existingOptional = jobDAO.findById(job.getId());
        if (existingOptional.isEmpty()) {
            return ServiceResult.failure("Job not found.");
        }
        Job existing = existingOptional.get();
        job.setJobStatus(existing.getJobStatus());
        job.setCompletedAt(existing.getCompletedAt());
        job.setBilledAt(existing.getBilledAt());

        boolean updated = jobDAO.update(job);
        if (!updated) {
            return ServiceResult.failure("Job not found, or no changes were saved.");
        }
        logActivity("UPDATE_JOB", job.getId(), "Updated job " + job.getJobCode());
        return ServiceResult.success(job, "Job updated successfully.");
    }

    /**
     * Changes a job's status, managing completed_at automatically:
     *   - transitioning INTO COMPLETED sets completed_at to now
     *   - transitioning OUT OF COMPLETED clears completed_at back to null,
     *     so a job moved back to IN_PROGRESS never carries a stale
     *     completion timestamp
     *   - re-saving COMPLETED while already COMPLETED leaves the original
     *     completed_at untouched
     * completed_at is never accepted as direct input - this is the only
     * path that can change it.
     */
    public ServiceResult<Job> updateJobStatus(int jobId, Job.JobStatus newStatus) {
        return updateJobStatus(jobId, newStatus, null);
    }

    /** Updates status and, when completing a job, records the user-selected actual completion date. */
    public ServiceResult<Job> updateJobStatus(int jobId, Job.JobStatus newStatus, LocalDate actualCompletionDate) {
        if (newStatus == null) {
            return ServiceResult.failure("A status is required.");
        }

        Optional<Job> existingOptional = jobDAO.findById(jobId);
        if (existingOptional.isEmpty()) {
            return ServiceResult.failure("Job not found.");
        }
        Job job = existingOptional.get();
        Job.JobStatus previousStatus = job.getJobStatus();

        if (newStatus == Job.JobStatus.COMPLETED && (previousStatus != Job.JobStatus.COMPLETED || actualCompletionDate != null)) {
            LocalDate date = actualCompletionDate == null ? LocalDate.now() : actualCompletionDate;
            job.setCompletedAt(LocalDateTime.of(date, LocalTime.NOON).format(TIMESTAMP_FORMAT));
        } else if (previousStatus == Job.JobStatus.COMPLETED && newStatus != Job.JobStatus.COMPLETED) {
            job.setCompletedAt(null);
        }
        job.setJobStatus(newStatus);

        boolean updated = jobDAO.update(job);
        if (!updated) {
            return ServiceResult.failure("Job not found, or no changes were saved.");
        }
        logActivity("UPDATE_JOB_STATUS", jobId,
                "Job " + job.getJobCode() + " status changed from " + previousStatus + " to " + newStatus);
        return ServiceResult.success(job, "Job status updated.");
    }

    /**
     * Marks a job as billed using its existing fields rather than a separate
     * invoice table. A due date already entered by the user wins; otherwise
     * it is calculated once from the client's payment terms and saved as the
     * agreed due date (not as a derived balance or payment status).
     */
    public ServiceResult<Job> markAsBilled(int jobId, String requestedDueDate) {
        Optional<Job> existingOptional = jobDAO.findById(jobId);
        if (existingOptional.isEmpty()) return ServiceResult.failure("Job not found.");
        Job job = existingOptional.get();
        if (job.getBilledAt() != null) return ServiceResult.failure("This job has already been marked as billed.");
        String dueDate = requestedDueDate == null || requestedDueDate.isBlank() ? null : requestedDueDate.trim();
        if (dueDate != null && !ISO_DATE_PATTERN.matcher(dueDate).matches()) return ServiceResult.failure("Payment due date must be in YYYY-MM-DD format.");
        if (dueDate == null) {
            Optional<Client> client = new ClientDAO().findById(job.getClientId());
            if (client.isEmpty()) return ServiceResult.failure("Client not found for this job.");
            dueDate = calculateDueDate(LocalDate.now(), client.get().getPaymentTerms()).toString();
        }
        job.setBilledAt(LocalDateTime.now().format(TIMESTAMP_FORMAT));
        job.setPaymentDueDate(dueDate);
        if (!jobDAO.update(job)) return ServiceResult.failure("Job could not be marked as billed.");
        logActivity("MARK_JOB_BILLED", jobId, "Marked " + job.getJobCode() + " as billed; due " + dueDate);
        return ServiceResult.success(job, "Job marked as billed. Payment due date: " + dueDate);
    }

    private LocalDate calculateDueDate(LocalDate billingDate, Client.PaymentTerms terms) {
        return switch (terms) {
            case NET_15 -> billingDate.plusDays(15); case NET_30 -> billingDate.plusDays(30);
            case NET_45 -> billingDate.plusDays(45); case NET_60 -> billingDate.plusDays(60);
            case COD -> billingDate;
        };
    }

    private String validate(Job job) {
        if (job == null) {
            return "Job data is missing.";
        }
        if (job.getClientId() <= 0) {
            return "A client is required.";
        }
        if (job.getJobDate() == null || job.getJobDate().isBlank()) {
            return "Job date is required.";
        }
        if (!ISO_DATE_PATTERN.matcher(job.getJobDate().trim()).matches()) {
            return "Job date must be in YYYY-MM-DD format.";
        }
        if (job.getPaymentDueDate() != null && !job.getPaymentDueDate().isBlank()
                && !ISO_DATE_PATTERN.matcher(job.getPaymentDueDate().trim()).matches()) {
            return "Payment due date must be in YYYY-MM-DD format.";
        }
        if (job.getTaxReductionPercent() < 0 || job.getTaxReductionPercent() > 100) {
            return "Tax reduction must be between 0 and 100 percent.";
        }
        return null;
    }

    private void logActivity(String action, Integer jobId, String details) {
        User currentUser = sessionManager.getCurrentUser();
        Integer userId = currentUser != null ? currentUser.getId() : null;
        activityLogDAO.log(userId, action, "JOB", jobId, details);
    }
}
