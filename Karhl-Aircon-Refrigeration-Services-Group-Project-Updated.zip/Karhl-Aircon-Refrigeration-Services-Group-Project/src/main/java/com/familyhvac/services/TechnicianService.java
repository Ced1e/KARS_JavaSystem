package com.familyhvac.services;

import com.familyhvac.dao.ActivityLogDAO;
import com.familyhvac.dao.TechnicianDAO;
import com.familyhvac.models.Technician;
import com.familyhvac.models.User;
import com.familyhvac.utils.SessionManager;

import java.util.List;
import java.util.Optional;

/**
 * Business logic for technician management. Views/controllers never talk
 * to TechnicianDAO directly - they go through this service, which is
 * where validation rules and audit logging live.
 */
public class TechnicianService {

    private final TechnicianDAO technicianDAO;
    private final ActivityLogDAO activityLogDAO;
    private final SessionManager sessionManager;

    public TechnicianService() {
        this.technicianDAO = new TechnicianDAO();
        this.activityLogDAO = new ActivityLogDAO();
        this.sessionManager = SessionManager.getInstance();
    }

    public List<Technician> listActiveTechnicians() {
        return technicianDAO.findAll();
    }

    public List<Technician> listAllTechnicians() {
        return technicianDAO.findAllIncludingInactive();
    }

    /**
     * Searches technicians by name or phone. A blank query simply returns
     * the full list (active-only, unless includeInactive).
     */
    public List<Technician> searchTechnicians(String query, boolean includeInactive) {
        if (query == null || query.isBlank()) {
            return includeInactive ? listAllTechnicians() : listActiveTechnicians();
        }
        return technicianDAO.search(query.trim(), includeInactive);
    }

    public Optional<Technician> getTechnicianById(int id) {
        return technicianDAO.findById(id);
    }

    /**
     * Returns active technicians with a name similar to the given name,
     * for a non-blocking "a similar technician may already exist" warning.
     * Callers (controllers) decide what to do with this - it never blocks
     * a save.
     */
    public List<Technician> findSimilarTechnicians(String name, Integer excludeId) {
        if (name == null || name.isBlank()) {
            return List.of();
        }
        return technicianDAO.findSimilarByName(name.trim(), excludeId);
    }

    public ServiceResult<Technician> createTechnician(Technician technician) {
        String validationError = validate(technician);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        technician.setActive(true);
        Technician saved = technicianDAO.insert(technician);
        logActivity("CREATE_TECHNICIAN", saved.getId(), "Created technician: " + saved.getName());
        return ServiceResult.success(saved, "Technician created successfully.");
    }

    public ServiceResult<Technician> updateTechnician(Technician technician) {
        String validationError = validate(technician);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        boolean updated = technicianDAO.update(technician);
        if (!updated) {
            return ServiceResult.failure("Technician not found, or no changes were saved.");
        }
        logActivity("UPDATE_TECHNICIAN", technician.getId(), "Updated technician: " + technician.getName());
        return ServiceResult.success(technician, "Technician updated successfully.");
    }

    /** Archives (soft-deletes) a technician. The row and job/payout history are never removed. */
    public ServiceResult<Void> archiveTechnician(int id) {
        boolean archived = technicianDAO.deleteById(id);
        if (!archived) {
            return ServiceResult.failure("Technician not found.");
        }
        logActivity("ARCHIVE_TECHNICIAN", id, "Technician archived");
        return ServiceResult.success(null, "Technician archived.");
    }

    /** Reverses an archive, making the technician active again. */
    public ServiceResult<Void> restoreTechnician(int id) {
        boolean restored = technicianDAO.restoreById(id);
        if (!restored) {
            return ServiceResult.failure("Technician not found.");
        }
        logActivity("RESTORE_TECHNICIAN", id, "Technician restored");
        return ServiceResult.success(null, "Technician restored.");
    }

    /**
     * Required-field validation. Duplicate-name checking is intentionally
     * NOT part of this method - per the design established for clients, a
     * similar name is a warning the UI surfaces via
     * {@link #findSimilarTechnicians}, never a save-blocking validation error.
     */
    private String validate(Technician technician) {
        if (technician == null) {
            return "Technician data is missing.";
        }
        if (technician.getName() == null || technician.getName().isBlank()) {
            return "Technician name is required.";
        }
        if (technician.getName().trim().length() < 2) {
            return "Technician name must be at least 2 characters.";
        }
        return null;
    }

    private void logActivity(String action, Integer entityId, String details) {
        User currentUser = sessionManager.getCurrentUser();
        Integer userId = currentUser != null ? currentUser.getId() : null;
        activityLogDAO.log(userId, action, "TECHNICIAN", entityId, details);
    }
}
