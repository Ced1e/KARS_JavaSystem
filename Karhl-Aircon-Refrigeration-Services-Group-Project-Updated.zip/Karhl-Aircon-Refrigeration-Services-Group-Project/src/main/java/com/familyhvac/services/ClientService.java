package com.familyhvac.services;

import com.familyhvac.dao.ActivityLogDAO;
import com.familyhvac.dao.ClientDAO;
import com.familyhvac.models.Client;
import com.familyhvac.models.User;
import com.familyhvac.utils.SessionManager;

import java.util.List;
import java.util.Optional;

/**
 * Business logic for client management. Views/controllers never talk to
 * ClientDAO directly - they go through this service, which is where
 * validation rules and audit logging live.
 */
public class ClientService {

    private final ClientDAO clientDAO;
    private final ActivityLogDAO activityLogDAO;
    private final SessionManager sessionManager;

    public ClientService() {
        this.clientDAO = new ClientDAO();
        this.activityLogDAO = new ActivityLogDAO();
        this.sessionManager = SessionManager.getInstance();
    }

    public List<Client> listActiveClients() {
        return clientDAO.findAll();
    }

    public List<Client> listAllClients() {
        return clientDAO.findAllIncludingInactive();
    }

    /**
     * Searches clients by name/contact person/phone/address. A blank query
     * simply returns the full list (active-only, unless includeInactive).
     */
    public List<Client> searchClients(String query, boolean includeInactive) {
        if (query == null || query.isBlank()) {
            return includeInactive ? listAllClients() : listActiveClients();
        }
        return clientDAO.search(query.trim(), includeInactive);
    }

    public Optional<Client> getClientById(int id) {
        return clientDAO.findById(id);
    }

    /**
     * Returns active clients with a name similar to the given name, for a
     * non-blocking "a similar client may already exist" warning. Callers
     * (controllers) decide what to do with this - it never blocks a save.
     */
    public List<Client> findSimilarClients(String name, Integer excludeId) {
        if (name == null || name.isBlank()) {
            return List.of();
        }
        return clientDAO.findSimilarByName(name.trim(), excludeId);
    }

    public ServiceResult<Client> createClient(Client client) {
        String validationError = validate(client);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        client.setActive(true);
        Client saved = clientDAO.insert(client);
        logActivity("CREATE_CLIENT", saved.getId(), "Created client: " + saved.getClientName());
        return ServiceResult.success(saved, "Client created successfully.");
    }

    public ServiceResult<Client> updateClient(Client client) {
        String validationError = validate(client);
        if (validationError != null) {
            return ServiceResult.failure(validationError);
        }

        boolean updated = clientDAO.update(client);
        if (!updated) {
            return ServiceResult.failure("Client not found, or no changes were saved.");
        }
        logActivity("UPDATE_CLIENT", client.getId(), "Updated client: " + client.getClientName());
        return ServiceResult.success(client, "Client updated successfully.");
    }

    /** Archives (soft-deletes) a client. The row and its job history are never removed. */
    public ServiceResult<Void> archiveClient(int id) {
        boolean archived = clientDAO.deleteById(id);
        if (!archived) {
            return ServiceResult.failure("Client not found.");
        }
        logActivity("ARCHIVE_CLIENT", id, "Client archived");
        return ServiceResult.success(null, "Client archived.");
    }

    /** Reverses an archive, making the client active again. */
    public ServiceResult<Void> restoreClient(int id) {
        boolean restored = clientDAO.restoreById(id);
        if (!restored) {
            return ServiceResult.failure("Client not found.");
        }
        logActivity("RESTORE_CLIENT", id, "Client restored");
        return ServiceResult.success(null, "Client restored.");
    }

    /**
     * Required-field and format validation. Duplicate-name checking is
     * intentionally NOT part of this method - per the design, a similar
     * name is a warning the UI surfaces via {@link #findSimilarClients},
     * never a save-blocking validation error.
     */
    private String validate(Client client) {
        if (client == null) {
            return "Client data is missing.";
        }
        if (client.getClientName() == null || client.getClientName().isBlank()) {
            return "Client name is required.";
        }
        if (client.getClientName().trim().length() < 2) {
            return "Client name must be at least 2 characters.";
        }
        if (client.getEmail() != null && !client.getEmail().isBlank() && !isValidEmail(client.getEmail())) {
            return "Please enter a valid email address.";
        }
        if (client.getPaymentTerms() == null) {
            return "Payment terms must be selected.";
        }
        if (client.getPreferredPaymentMethod() == null) {
            return "Preferred payment method must be selected.";
        }
        return null;
    }

    private boolean isValidEmail(String email) {
        // Supports regular and multi-part domains, e.g. gmail.com.ph.
        return email.matches("^[\\w.+-]+@[\\w-]+(?:\\.[\\w-]+)+$");
    }

    private void logActivity(String action, Integer entityId, String details) {
        User currentUser = sessionManager.getCurrentUser();
        Integer userId = currentUser != null ? currentUser.getId() : null;
        activityLogDAO.log(userId, action, "CLIENT", entityId, details);
    }
}
