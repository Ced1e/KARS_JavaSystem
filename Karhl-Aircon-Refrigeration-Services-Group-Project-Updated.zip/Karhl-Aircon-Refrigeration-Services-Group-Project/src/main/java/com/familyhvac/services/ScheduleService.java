package com.familyhvac.services;

import com.familyhvac.models.Job;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Builds calendar-ready daily job summaries without placing status rules in the view. */
public class ScheduleService {
    public enum DayStatus { NONE, COMPLETED, SCHEDULED, IN_PROGRESS, OVERDUE }
    public record DaySummary(int jobCount, DayStatus status) { }

    public Map<LocalDate, DaySummary> summarizeMonth(List<Job> jobs, YearMonth month, LocalDate today) {
        Map<LocalDate, DaySummary> summaries = new HashMap<>();
        for (Job job : jobs) {
            try {
                LocalDate date = LocalDate.parse(job.getJobDate());
                if (!YearMonth.from(date).equals(month)) continue;
                DaySummary previous = summaries.getOrDefault(date, new DaySummary(0, DayStatus.NONE));
                summaries.put(date, new DaySummary(previous.jobCount() + 1,
                        moreUrgent(previous.status(), statusFor(job, date, today))));
            } catch (RuntimeException ignored) { }
        }
        return summaries;
    }

    private DayStatus statusFor(Job job, LocalDate date, LocalDate today) {
        return switch (job.getJobStatus()) {
            case COMPLETED -> DayStatus.COMPLETED;
            case CANCELLED -> DayStatus.NONE;
            case SCHEDULED -> date.isBefore(today) ? DayStatus.OVERDUE : DayStatus.SCHEDULED;
            case IN_PROGRESS -> DayStatus.IN_PROGRESS;
        };
    }

    private DayStatus moreUrgent(DayStatus left, DayStatus right) {
        return priority(right) > priority(left) ? right : left;
    }

    private int priority(DayStatus status) {
        return switch (status) { case OVERDUE -> 4; case IN_PROGRESS -> 3; case SCHEDULED -> 2; case COMPLETED -> 1; case NONE -> 0; };
    }
}
