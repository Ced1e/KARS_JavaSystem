package com.familyhvac.utils;

import javax.swing.*;
import java.awt.*;

/** Lightweight rounded surface used for the app shell and dashboard cards. */
public class RoundedPanel extends JPanel {
    private final int radius;
    private final boolean shadow;
    public RoundedPanel(LayoutManager layout, int radius, boolean shadow) { super(layout); this.radius=radius; this.shadow=shadow; setOpaque(false); }
    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        int width = Math.max(0, getWidth() - (shadow ? 8 : 0));
        int height = Math.max(0, getHeight() - (shadow ? 8 : 0));
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (shadow) {
            g.setColor(new Color(20, 40, 80, 25));
            g.fillRoundRect(4, 5, width, height, radius, radius);
        }
        g.setColor(getBackground());
        g.fillRoundRect(0, 0, width, height, radius, radius);
        g.dispose();
    }
}
