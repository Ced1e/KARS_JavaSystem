package com.familyhvac.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/** Keeps the user-facing date format separate from the database's sortable ISO format. */
public final class DateSupport {
    public static final DateTimeFormatter DISPLAY = DateTimeFormatter.ofPattern("MMMM d, uuuu");
    private static final DateTimeFormatter LEGACY_DISPLAY = DateTimeFormatter.ofPattern("dd-MM-uuuu");
    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE;

    private DateSupport() { }

    public static LocalDate parseDisplay(String input) {
        if (input == null || input.isBlank()) return null;
        try { return LocalDate.parse(input.trim(), DISPLAY); }
        catch (DateTimeParseException ignored) { return LocalDate.parse(input.trim(), LEGACY_DISPLAY); }
    }
    public static String display(String storedDate) {
        if (storedDate == null || storedDate.isBlank()) return "";
        try { return LocalDate.parse(storedDate, ISO).format(DISPLAY); }
        catch (DateTimeParseException ignored) {
            try { return LocalDate.parse(storedDate, LEGACY_DISPLAY).format(DISPLAY); }
            catch (DateTimeParseException ignoredAgain) { return storedDate; }
        }
    }
    public static String toStorage(String input) {
        LocalDate value = parseDisplay(input);
        return value == null ? null : toStorage(value);
    }
    public static String toStorage(LocalDate value) { return value == null ? null : value.format(ISO); }
}
