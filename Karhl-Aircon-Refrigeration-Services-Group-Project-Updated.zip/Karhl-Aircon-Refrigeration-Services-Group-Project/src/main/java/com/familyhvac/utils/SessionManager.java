package com.familyhvac.utils;

import com.familyhvac.models.User;

/**
 * Holds the currently authenticated user for as long as the application is
 * running. Simple in-memory singleton - this is a single-machine desktop
 * app, so there is no need for anything more elaborate (tokens, etc.).
 */
public final class SessionManager {

    private static SessionManager instance;

    private User currentUser;

    private SessionManager() {
    }

    public static synchronized SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void startSession(User user) {
        this.currentUser = user;
    }

    public void endSession() {
        this.currentUser = null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }
}
