package com.familyhvac.utils;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Wraps bcrypt hashing so the rest of the codebase never touches a raw
 * password or a hashing algorithm directly. If the hashing strategy ever
 * changes, this is the only class that needs to change.
 */
public final class PasswordUtil {

    private static final int WORK_FACTOR = 12;

    private PasswordUtil() {
        // utility class - not instantiable
    }

    public static String hash(String plainTextPassword) {
        if (plainTextPassword == null || plainTextPassword.isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty.");
        }
        return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt(WORK_FACTOR));
    }

    public static boolean matches(String plainTextPassword, String hashedPassword) {
        if (plainTextPassword == null || hashedPassword == null) {
            return false;
        }
        try {
            return BCrypt.checkpw(plainTextPassword, hashedPassword);
        } catch (IllegalArgumentException e) {
            // Thrown by jBCrypt if hashedPassword is not a valid bcrypt hash
            return false;
        }
    }
}
