package com.familyhvac.utils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.prefs.Preferences;

/**
 * Single source of truth for the application's look and feel. Every view -
 * current and future - should pull its colors, fonts, and spacing from
 * here instead of hardcoding values, so the whole application stays
 * visually consistent as new modules are added.
 *
 * Palette intentionally stays muted/professional (no flashy colors),
 * per the project's UI requirements.
 */
public final class UITheme {

    public enum ThemeMode { LIGHT, GRAY, DARK }
    private static final Preferences PREFERENCES = Preferences.userNodeForPackage(UITheme.class);
    private static final String THEME_KEY = "theme_mode";

    private UITheme() {
    }

    // ---- Colors -----------------------------------------------------
    public static Color COLOR_SIDEBAR_BG, COLOR_SIDEBAR_TEXT, COLOR_SIDEBAR_ACTIVE, COLOR_BACKGROUND,
            COLOR_CARD_BG, COLOR_PRIMARY, COLOR_PRIMARY_HOVER, COLOR_TEXT_PRIMARY, COLOR_TEXT_SECONDARY,
            COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER, COLOR_BORDER, COLOR_TABLE_SELECTION, COLOR_SECONDARY;

    static { applySavedTheme(); }

    // ---- Fonts --------------------------------------------------------
    public static final Font FONT_TITLE    = new Font("Segoe UI", Font.BOLD, 23);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_LABEL    = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font FONT_BODY     = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_BUTTON   = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_CARD_VALUE = new Font("Segoe UI", Font.BOLD, 25);
    public static final Font FONT_SIDEBAR  = new Font("Segoe UI", Font.PLAIN, 14);

    // ---- Spacing --------------------------------------------------------
    public static final int SPACING_SM = 8;
    public static final int SPACING_MD = 16;
    public static final int SPACING_LG = 24;

    public static JButton createPrimaryButton(String text) {
        JButton button = new RoundedButton(text, 9);
        button.setFont(FONT_BUTTON);
        button.setBackground(COLOR_PRIMARY);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(10, 24, 10, 24));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    /** Neutral action for secondary actions such as refresh, edit, and details. */
    public static JButton createSecondaryButton(String text) {
        JButton button = new RoundedButton(text, 9);
        button.setFont(FONT_BODY);
        button.setBackground(COLOR_SECONDARY);
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(9, 15, 9, 15));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    public static JLabel createSectionTitle(String text) {
        JLabel label = new JLabel(text);
        label.setFont(FONT_TITLE);
        label.setForeground(COLOR_TEXT_PRIMARY);
        return label;
    }

    /** Applies a restrained, consistent baseline to stock Swing controls. */
    public static void applyGlobalDefaults() {
        UIManager.put("Label.font", FONT_BODY);
        UIManager.put("Button.font", FONT_BODY);
        UIManager.put("TextField.font", FONT_BODY);
        UIManager.put("TextArea.font", FONT_BODY);
        UIManager.put("ComboBox.font", FONT_BODY);
        UIManager.put("Table.font", FONT_BODY);
        UIManager.put("TableHeader.font", FONT_LABEL.deriveFont(Font.BOLD));
        UIManager.put("Table.rowHeight", 30);
        UIManager.put("Table.selectionBackground", COLOR_TABLE_SELECTION);
        UIManager.put("Table.selectionForeground", COLOR_TEXT_PRIMARY);
        UIManager.put("Table.gridColor", COLOR_BORDER);
        UIManager.put("TableHeader.background", COLOR_CARD_BG);
        UIManager.put("TableHeader.foreground", COLOR_TEXT_SECONDARY);
        UIManager.put("Panel.background", COLOR_CARD_BG);
        UIManager.put("TextField.background", COLOR_CARD_BG);
        UIManager.put("TextField.foreground", COLOR_TEXT_PRIMARY);
        UIManager.put("TextArea.background", COLOR_CARD_BG);
        UIManager.put("TextArea.foreground", COLOR_TEXT_PRIMARY);
        UIManager.put("ComboBox.background", COLOR_CARD_BG);
        UIManager.put("ComboBox.foreground", COLOR_TEXT_PRIMARY);
        UIManager.put("ScrollPane.background", COLOR_CARD_BG);
        UIManager.put("Viewport.background", COLOR_CARD_BG);
        UIManager.put("OptionPane.messageFont", FONT_BODY);
        UIManager.put("ToolTip.font", FONT_LABEL);
    }

    public static ThemeMode getThemeMode() {
        try { return ThemeMode.valueOf(PREFERENCES.get(THEME_KEY, ThemeMode.LIGHT.name())); }
        catch (IllegalArgumentException ignored) { return ThemeMode.LIGHT; }
    }

    /** Saves the preference. A restart applies the selected palette across all existing screens. */
    public static void setThemeMode(ThemeMode mode) { PREFERENCES.put(THEME_KEY, mode.name()); applyPalette(mode); }

    public static void applySavedTheme() { applyPalette(getThemeMode()); }

    private static void applyPalette(ThemeMode mode) {
        COLOR_PRIMARY = new Color(0x25, 0x6D, 0xD7); COLOR_PRIMARY_HOVER = new Color(0x1F, 0x57, 0xAF);
        COLOR_SUCCESS = new Color(0x18, 0x8A, 0x4C); COLOR_WARNING = new Color(0xB9, 0x6F, 0x08); COLOR_DANGER = new Color(0xC8, 0x32, 0x32);
        switch (mode) {
            case DARK -> { COLOR_SIDEBAR_BG = new Color(0x13,0x1C,0x2A); COLOR_SIDEBAR_TEXT = new Color(0xE8,0xEC,0xF2); COLOR_SIDEBAR_ACTIVE = new Color(0x25,0x6D,0xD7); COLOR_BACKGROUND = new Color(0x1B,0x24,0x32); COLOR_CARD_BG = new Color(0x25,0x2F,0x3D); COLOR_TEXT_PRIMARY = new Color(0xF6,0xF8,0xFB); COLOR_TEXT_SECONDARY = new Color(0xB6,0xC1,0xD0); COLOR_BORDER = new Color(0x42,0x4E,0x5F); COLOR_TABLE_SELECTION = new Color(0x30,0x49,0x69); COLOR_SECONDARY = new Color(0x34,0x40,0x51); }
            case GRAY -> { COLOR_SIDEBAR_BG = new Color(0x31,0x3B,0x48); COLOR_SIDEBAR_TEXT = new Color(0xF2,0xF4,0xF6); COLOR_SIDEBAR_ACTIVE = new Color(0x50,0x74,0xA7); COLOR_BACKGROUND = new Color(0xEE,0xF0,0xF3); COLOR_CARD_BG = new Color(0xFA,0xFB,0xFC); COLOR_TEXT_PRIMARY = new Color(0x20,0x29,0x33); COLOR_TEXT_SECONDARY = new Color(0x67,0x72,0x7E); COLOR_BORDER = new Color(0xD6,0xDB,0xE1); COLOR_TABLE_SELECTION = new Color(0xDF,0xE9,0xF5); COLOR_SECONDARY = new Color(0xE5,0xE9,0xEE); }
            default -> { COLOR_SIDEBAR_BG = new Color(0x16,0x2B,0x48); COLOR_SIDEBAR_TEXT = new Color(0xE9,0xEE,0xF5); COLOR_SIDEBAR_ACTIVE = new Color(0x25,0x6D,0xD7); COLOR_BACKGROUND = new Color(0xF4,0xF7,0xFB); COLOR_CARD_BG = new Color(0xFF,0xFF,0xFF); COLOR_TEXT_PRIMARY = new Color(0x14,0x1E,0x2B); COLOR_TEXT_SECONDARY = new Color(0x6A,0x75,0x84); COLOR_BORDER = new Color(0xE2,0xE7,0xEE); COLOR_TABLE_SELECTION = new Color(0xE4,0xEF,0xFC); COLOR_SECONDARY = new Color(0xEC,0xF2,0xF9); }
        }
    }
}
