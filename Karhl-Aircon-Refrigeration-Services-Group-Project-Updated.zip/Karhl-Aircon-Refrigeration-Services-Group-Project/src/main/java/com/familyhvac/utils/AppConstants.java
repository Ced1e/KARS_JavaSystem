package com.familyhvac.utils;

/**
 * Single source of truth for application-wide constants such as the
 * display name and database file naming. Any future rename or
 * white-labeling only needs to change values here.
 */
public final class AppConstants {

    private AppConstants() {
    }

    public static final String APP_NAME = "Karhl Aircon & Refrigeration Services";

    /** Shorter form used where space is tight, e.g. the sidebar header. */
    public static final String APP_SHORT_NAME = "Karhl A&R Services";

    public static final String DB_DIRECTORY = "data";
    public static final String DB_FILE_NAME = "karhl_aircon_refrigeration.db";

    /**
     * The database filename used by earlier builds of this project (back when
     * it was called "Family HVAC Business Manager"). Kept here only so
     * DatabaseManager can migrate anyone's existing data file to the new
     * name on first run after the rename - not used anywhere else.
     */
    public static final String LEGACY_DB_FILE_NAME = "hvac_business.db";
}
