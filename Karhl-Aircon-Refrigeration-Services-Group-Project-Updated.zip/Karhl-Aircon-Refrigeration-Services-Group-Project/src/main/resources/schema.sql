-- =====================================================================
-- Karhl Aircon & Refrigeration Services - Database Schema
-- SQLite. Designed as a normalized relational schema (not one flat table).
-- All statements are idempotent (safe to run every application start).
--
-- DESIGN PRINCIPLE - derived values are never stored:
--   line item subtotal  -> quantity * unit_price (computed at read time)
--   job total            -> SUM(quantity * unit_price) across a job's line items
--   amount paid          -> SUM(payments.amount) WHERE job_id = ?
--   remaining balance    -> job total - amount paid
--   payment status        -> derived from (amount paid vs job total): NOT_BILLED / UNPAID / PARTIAL / PAID / OVERPAID
--   technician disbursed  -> SUM(technician_payout_disbursements.amount) WHERE technician_payout_id = ?
--   technician remaining  -> approved_amount - technician disbursed
--   cash advance balance  -> SUM(RELEASE) - SUM(RETURN) WHERE job_id = ?
--   net profit per job   -> job total - SUM(technician_payouts.approved_amount) - SUM(related expenses)
-- These are computed in the service/DAO layer at query time (e.g. via SQL
-- SUM()/aggregate queries or in Java after fetching related rows), never
-- written to a column. This guarantees they can never drift out of sync
-- with the payments/payouts/disbursements/cash-advances/line-items that
-- back them.
-- =====================================================================

-- ---------------------------------------------------------------------
-- USERS (authentication, expandable to multiple roles/users)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name     TEXT,
    role          TEXT NOT NULL DEFAULT 'ADMIN',      -- ADMIN, STAFF, etc.
    is_active     INTEGER NOT NULL DEFAULT 1,          -- 1 = active, 0 = disabled
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------
-- CLIENTS
-- payment_terms and preferred_payment_method are constrained to fixed
-- sets (not user-editable lookup tables, unlike service/expense
-- categories) since these are small, stable business rules rather than
-- an open-ended list. "Client Code" (e.g. CLI-00001) is NOT stored here -
-- it's a display-only value derived from id in the application layer.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clients (
    id                        INTEGER PRIMARY KEY AUTOINCREMENT,
    client_name               TEXT NOT NULL,
    contact_person            TEXT,
    phone_number              TEXT,
    email                     TEXT,
    tin                       TEXT,                       -- Tax Identification Number
    address                   TEXT,
    payment_terms             TEXT NOT NULL DEFAULT 'COD'
                                  CHECK (payment_terms IN ('COD','NET_15','NET_30','NET_45','NET_60')),
    preferred_payment_method  TEXT NOT NULL DEFAULT 'CASH'
                                  CHECK (preferred_payment_method IN ('CASH','CHECK','BANK_TRANSFER')),
    notes                     TEXT,
    is_active                 INTEGER NOT NULL DEFAULT 1,  -- 1 = active, 0 = archived (soft delete)
    created_at                TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at                TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------
-- SERVICE CATEGORIES (editable lookup list)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS service_categories (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL UNIQUE,
    is_active INTEGER NOT NULL DEFAULT 1
);

-- ---------------------------------------------------------------------
-- TECHNICIANS (no fixed salary / no daily wage stored here)
-- Kept minimal by design: name, phone, notes, and an active/archived
-- status - same soft-delete pattern as clients. "Technician Code"
-- (e.g. TCH-00001) is NOT stored here - it's a display-only value
-- derived from id in the application layer, same as Client Code.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS technicians (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    phone_number TEXT,
    notes        TEXT,
    is_active    INTEGER NOT NULL DEFAULT 1,     -- 1 = active, 0 = archived (soft delete)
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------
-- JOBS (the core transactional entity - one row per service job)
-- NOTE: This table intentionally has NO total_amount, amount_paid,
-- remaining_balance, payment_status, or net_profit column. All of those
-- are DERIVED at query time from job_line_items, payments,
-- technician_payouts, and expenses, so they can never drift out of sync
-- with the records that back them. See job_line_items below for pricing.
--
-- "Job Code" (e.g. JOB-00001) is NOT stored here - it's a display-only
-- value derived from id in the application layer, same as Client Code
-- and Technician Code.
--
-- Technician assignment (including who is "lead") lives entirely in
-- technician_payouts.is_lead - there is deliberately no lead_technician_id
-- column here, since a job can have multiple technicians with
-- independently negotiated payouts.
--
-- completed_at is set automatically by the application when job_status
-- transitions to COMPLETED - it is not manually entered.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS jobs (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id             INTEGER NOT NULL,
    service_category_id   INTEGER,
    job_date              TEXT NOT NULL,                -- ISO date the job was performed/scheduled
    location              TEXT,
    description           TEXT,                          -- scope of work, separate from priced line items
    po_number             TEXT,                          -- optional client purchase-order reference
    job_status            TEXT NOT NULL DEFAULT 'SCHEDULED'
                              CHECK (job_status IN ('SCHEDULED','IN_PROGRESS','COMPLETED','CANCELLED')),
    completed_at          TEXT,                          -- auto-set when job_status becomes COMPLETED
    billed_at             TEXT,                          -- set when a billing statement is issued
    payment_due_date      TEXT,                          -- optional, may override the client's default terms
    tax_reduction_percent REAL NOT NULL DEFAULT 0 CHECK (tax_reduction_percent >= 0 AND tax_reduction_percent <= 100),
    ewt_2307_status       TEXT NOT NULL DEFAULT 'NOT_YET' CHECK (ewt_2307_status IN ('NOT_YET','RECEIVED')),
    notes                 TEXT,
    created_at            TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at            TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (client_id)           REFERENCES clients(id)             ON DELETE RESTRICT,
    FOREIGN KEY (service_category_id) REFERENCES service_categories(id)  ON DELETE SET NULL
);

-- ---------------------------------------------------------------------
-- JOB LINE ITEMS (a job's price breakdown - the job's total is the SUM
-- of these rows, never a single free-standing number). Unit price is
-- always manually entered per line, since pricing varies by client and
-- situation - nothing here is looked up from a fixed price list.
--
-- subtotal is NOT stored - it is quantity * unit_price, computed at read
-- time (in the DAO's row-mapping or in SQL). A single-row arithmetic
-- derivation has no cross-row staleness risk to guard against by storing
-- it, and computing it closes even the small window where a future bulk
-- edit or direct DB access could leave a stored subtotal inconsistent
-- with its own row.
--
-- Examples this supports:
--   "Window Cleaning" x1 @ 400.00  = 400.00
--   "Cleaning"         x5 @ 1250.00 = 6250.00
--   "Installation"     x1 @ 17500.00 = 17500.00
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS job_line_items (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id       INTEGER NOT NULL,
    description  TEXT NOT NULL,          -- e.g. "Window Cleaning", "Cleaning - 5 units"
    quantity     REAL NOT NULL DEFAULT 1,
    unit_price   REAL NOT NULL DEFAULT 0, -- manually entered, never derived from a price table
    sort_order   INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- PAYMENTS (a job may receive MANY payments - never a single column)
-- amount_paid / balance / payment_status are DERIVED from this table,
-- never stored redundantly on the jobs table.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id           INTEGER NOT NULL,
    payment_date     TEXT NOT NULL,
    amount           REAL NOT NULL,
    payment_type     TEXT NOT NULL,     -- CASH, CHECK, BANK_TRANSFER, GCASH, OTHERS
    reference_number TEXT,
    remarks          TEXT,
    created_at       TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- TECHNICIAN PAYOUTS (one row per technician assigned to a job - this
-- table doubles as "who's on the job" AND "what they're owed", since
-- every technician is paid per-job, never salaried).
--
-- approved_amount is nullable: a technician can be assigned to a job long
-- before payout is negotiated (often after the job is done), so this row
-- can exist purely as an assignment first. When negotiation happens, the
-- amount is manually typed in - approved_amount is the ONLY authoritative
-- payout figure. payout_method/percentage_value record what was
-- DISCUSSED for reference only and are NEVER used to calculate anything.
--
-- Only the amount paid to the assigned (lead) technician is recorded -
-- the business does not track how a lead technician splits money with an
-- assistant, per design.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS technician_payouts (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id            INTEGER NOT NULL,
    technician_id     INTEGER NOT NULL,
    is_lead           INTEGER NOT NULL DEFAULT 0,  -- 1 = lead technician on this job
    payout_method     TEXT
                          CHECK (payout_method IS NULL OR payout_method IN ('PERCENTAGE','FIXED_AMOUNT')),
    percentage_value  REAL,                         -- e.g. 50 for "50%" - documentary only, never calculated from
    approved_amount   REAL,                         -- the manually approved, authoritative payout - nullable until negotiated
    negotiated_at     TEXT,                         -- when the amount was agreed
    remarks           TEXT,                         -- e.g. "includes assistant's share"
    created_at        TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at        TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (job_id)        REFERENCES jobs(id)        ON DELETE CASCADE,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE RESTRICT
);

-- ---------------------------------------------------------------------
-- TECHNICIAN PAYOUT DISBURSEMENTS (append-only ledger of actual money
-- paid out against an approved technician payout). An advance is not a
-- separate payout - it is simply a partial disbursement against the
-- technician's approved_amount above.
--
-- Remaining payout is NOT stored - it is always:
--   approved_amount - SUM(disbursements.amount WHERE technician_payout_id = ?)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS technician_payout_disbursements (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    technician_payout_id  INTEGER NOT NULL,
    disbursement_type     TEXT NOT NULL
                              CHECK (disbursement_type IN ('ADVANCE','SETTLEMENT')),
    amount                REAL NOT NULL,
    disbursement_date     TEXT NOT NULL DEFAULT (date('now')),
    payment_method        TEXT NOT NULL
                              CHECK (payment_method IN ('CASH','CHECK','BANK_TRANSFER','GCASH','OTHERS')),
    reference_number      TEXT,
    remarks               TEXT,
    created_at            TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (technician_payout_id) REFERENCES technician_payouts(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- JOB CASH ADVANCE TRANSACTIONS (ledger-style float for job-related food/
-- gasoline/incidental money given to a technician - completely separate
-- from technician_payouts, which is labor pay, not a float). Chosen over
-- a single-row release/return design because multiple releases and
-- returns on the same job are a realistic, described part of the
-- workflow, not an edge case.
--
-- What was actually SPENT (food, gas) is recorded as ordinary expenses
-- rows, optionally linked to this job - never as a transaction type on
-- this ledger. This table only tracks money moving to/from the
-- technician, never what it was spent on.
--
-- Running balance is NOT stored - it is always:
--   SUM(amount WHERE transaction_type = 'RELEASE')
--   - SUM(amount WHERE transaction_type = 'RETURN')
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS job_cash_advance_transactions (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id            INTEGER NOT NULL,
    technician_id     INTEGER NOT NULL,
    transaction_type  TEXT NOT NULL
                          CHECK (transaction_type IN ('RELEASE','RETURN')),
    amount            REAL NOT NULL,
    transaction_date  TEXT NOT NULL DEFAULT (date('now')),
    remarks           TEXT,
    created_at        TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (job_id)        REFERENCES jobs(id)        ON DELETE CASCADE,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE RESTRICT
);

-- ---------------------------------------------------------------------
-- EXPENSE CATEGORIES (editable lookup list)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS expense_categories (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL UNIQUE,
    is_active INTEGER NOT NULL DEFAULT 1
);

-- ---------------------------------------------------------------------
-- EXPENSES (may or may not be linked to a specific job)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS expenses (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    expense_date    TEXT NOT NULL,
    category_id     INTEGER NOT NULL,
    description     TEXT,
    amount          REAL NOT NULL,
    related_job_id  INTEGER,           -- optional link to a job
    receipt_number  TEXT,
    remarks         TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (category_id)    REFERENCES expense_categories(id) ON DELETE RESTRICT,
    FOREIGN KEY (related_job_id) REFERENCES jobs(id)               ON DELETE SET NULL
);

-- ---------------------------------------------------------------------
-- ACTIVITY LOGS (audit trail - who did what, when)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activity_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER,
    action      TEXT NOT NULL,          -- e.g. LOGIN, CREATE_JOB, ADD_PAYMENT
    entity_type TEXT,                   -- e.g. JOB, CLIENT, PAYMENT
    entity_id   INTEGER,
    details     TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ---------------------------------------------------------------------
-- Indexes for common lookups/filters
-- ---------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_jobs_client        ON jobs(client_id);
CREATE INDEX IF NOT EXISTS idx_clients_active      ON clients(is_active);
CREATE INDEX IF NOT EXISTS idx_jobs_status         ON jobs(job_status);
CREATE INDEX IF NOT EXISTS idx_jobs_date           ON jobs(job_date);
CREATE INDEX IF NOT EXISTS idx_technicians_active  ON technicians(is_active);
CREATE INDEX IF NOT EXISTS idx_line_items_job       ON job_line_items(job_id);
CREATE INDEX IF NOT EXISTS idx_payments_job        ON payments(job_id);
CREATE INDEX IF NOT EXISTS idx_expenses_job        ON expenses(related_job_id);
CREATE INDEX IF NOT EXISTS idx_expenses_category   ON expenses(category_id);
CREATE INDEX IF NOT EXISTS idx_payouts_job         ON technician_payouts(job_id);
CREATE INDEX IF NOT EXISTS idx_payouts_technician  ON technician_payouts(technician_id);
CREATE INDEX IF NOT EXISTS idx_disbursements_payout ON technician_payout_disbursements(technician_payout_id);
CREATE INDEX IF NOT EXISTS idx_cash_advance_job    ON job_cash_advance_transactions(job_id);
CREATE INDEX IF NOT EXISTS idx_cash_advance_technician ON job_cash_advance_transactions(technician_id);
CREATE INDEX IF NOT EXISTS idx_activity_user       ON activity_logs(user_id);

-- ---------------------------------------------------------------------
-- Seed data for editable lookup lists (safe to re-run)
-- ---------------------------------------------------------------------
INSERT OR IGNORE INTO service_categories (name) VALUES
    ('Cleaning'),
    ('Installation'),
    ('Repair'),
    ('Relocation'),
    ('Preventive Maintenance'),
    ('Inspection'),
    ('Others');

INSERT OR IGNORE INTO expense_categories (name) VALUES
    ('Food'),
    ('Gasoline'),
    ('Materials'),
    ('Vehicle Maintenance'),
    ('Office Supplies'),
    ('Utilities'),
    ('Miscellaneous');
